import React from 'react';
import './maincategory.css';
import Header1 from '../Header/Header1';
import LeftCategory from '../LeftCategory/LeftCategory';
import Footer from '../../Jsx/Footer/Footer';

function MainCategory(props) {
    return (
        <>
            <Header1 />
            <LeftCategory />
            
            <div id='main' className='main'>
                {props.children}
            </div>

            <Footer />
        </>
    );
}
export default MainCategory;