import React from 'react';
import './leftcategory.css'
import { Link } from 'react-router-dom';

function LeftCategory() {
    return (
        <>
            <aside id="sidebar" className="sidebar">

                <ul className="sidebar-nav" id="sidebar-nav">

                    <li className="nav-item">
                        <Link className="nav-link " to="/">
                            <i className="bi bi-grid"></i>
                            <span>Dashboard</span>
                        </Link>
                    </li>
                    {/* -- End Dashboard Nav -- */}

                    {/* <li className="nav-item">
                        <Link className="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                            <i className="bi bi-menu-button-wide"></i><span>Product Add</span><i className="bi bi-chevron-down ms-auto"></i>
                        </Link>
                        <ul id="components-nav" className="nav-content collapse " data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to="/addmaincategory">
                                    <i className="bi bi-circle"></i><span>Main Category</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addsubcategory">
                                    <i className="bi bi-circle"></i><span>Sub Category</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addcolor">
                                    <i className="bi bi-circle"></i><span>Color</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addsize">
                                    <i className="bi bi-circle"></i><span>Size</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addbanner">
                                    <i className="bi bi-circle"></i><span>Banner</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addprice">
                                    <i className="bi bi-circle"></i><span>Price</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addreview">
                                    <i className="bi bi-circle"></i><span>Review</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/addrating">
                                    <i className="bi bi-circle"></i><span>Rating</span>
                                </Link>
                            </li>
                        </ul>
                    </li> */}
                    {/* -- End Components Nav -- */}
{/* 
                    <li className="nav-item">
                        <Link className="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" to="#">
                            <i className="bi bi-journal-text"></i><span>Product Edit</span><i className="bi bi-chevron-down ms-auto"></i>
                        </Link>
                        <ul id="forms-nav" className="nav-content collapse " data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to="/editmaincategory">
                                    <i className="bi bi-circle"></i><span>Main Category</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editsubcategory">
                                    <i className="bi bi-circle"></i><span>Sub Category</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editcolor">
                                    <i className="bi bi-circle"></i><span>Color</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editsize">
                                    <i className="bi bi-circle"></i><span>Size</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editbanner">
                                    <i className="bi bi-circle"></i><span>Banner</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editprice">
                                    <i className="bi bi-circle"></i><span>Price</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editreview">
                                    <i className="bi bi-circle"></i><span>Review</span>
                                </Link>
                            </li>
                            <li>
                                <Link to="/editrating">
                                    <i className="bi bi-circle"></i><span>Rating</span>
                                </Link>
                            </li>
                        </ul>
                    </li> */}
                    {/* -- End Forms Nav -- */}




                    <li className="nav-item">
                        <a className="nav-link collapsed" href="#">
                            <i className="bi bi-person-badge-fill"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                    {/* -- End Profile Page Nav -- */}

                    <li className="nav-item">
                        <a className="nav-link collapsed" href="#">
                            <i className="bi bi-people-fill"></i>
                            <span>Company</span>
                        </a>
                    </li>
                    {/* -- End F.A.Q Page Nav -- */}

                    <li className="nav-item">
                        <a className="nav-link collapsed" href="#">
                            <i className="bi bi-person"></i>
                            <span>Users</span>
                        </a>
                    </li>
                    {/* -- End Contact Page Nav -- */}

                    {/* <li className="nav-item">
                        <a className="nav-link collapsed" href="pages-register.html">
                            <i className="bi bi-card-list"></i>
                            <span>Register</span>
                        </a>
                    </li> */}
                    {/* -- End Register Page Nav -- */}

                    {/* <li className="nav-item">
                        <a className="nav-link collapsed" href="pages-login.html">
                            <i className="bi bi-box-arrow-in-right"></i>
                            <span>Login</span>
                        </a>
                    </li> */}
                    {/* -- End Login Page Nav -- */}

                    {/* <li className="nav-item">
                        <a className="nav-link collapsed" href="pages-error-404.html">
                            <i className="bi bi-dash-circle"></i>
                            <span>Error 404</span>
                        </a>
                    </li> */}
                    {/* -- End Error 404 Page Nav -- */}

                    {/* <li className="nav-item">
                        <a className="nav-link collapsed" href="pages-blank.html">
                            <i className="bi bi-file-earmark"></i>
                            <span>Blank</span>
                        </a>
                    </li> */}
                    {/* -- End Blank Page Nav -- */}

                </ul>

            </aside>
            {/* -- End Sidebar-- */}

        </>
    );
}

export default LeftCategory;