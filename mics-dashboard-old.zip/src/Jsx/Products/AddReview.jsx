import React from 'react';
import MainCategory from '../../Dashboard/MainCategory/MainCategory';
import { Link } from 'react-router-dom';

function AddReview() {
    return (
        <>
            <MainCategory>

                <div className="pagetitle">
                    <h1>Add Review</h1>
                    <nav>
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                            <li className="breadcrumb-item active">Add Review</li>
                        </ol>
                    </nav>
                </div>

            </MainCategory>
        </>
    );
}

export default AddReview;