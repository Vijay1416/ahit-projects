function AddProduct() {
    return ( 
        <h2>Add Product</h2>
     );
}

export default AddProduct;