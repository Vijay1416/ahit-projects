import React from 'react';
import MainCategory from '../../Dashboard/MainCategory/MainCategory';
import { Link } from 'react-router-dom';
function AddColor() {
    return (
        <>
            <MainCategory>

                <div className="pagetitle">
                    <h1>Add Color</h1>
                    <nav>
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                            <li className="breadcrumb-item active">Add Color</li>
                        </ol>
                    </nav>
                </div>

            </MainCategory>
        </>
    );
}

export default AddColor;