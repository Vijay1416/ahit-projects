import React from 'react';
import './footer.css'
function Footer() {
    return (
        <>
            {/* ======= Footer ======= */}
            <footer id="footer" className="footer">
                <div className="copyright">
                    &copy; Copyright <strong><span>MICS</span></strong>. All Rights Reserved
                </div>
                {/* <div className="credits">
                    Designed by <a href="#"></a>
                </div> */}
            </footer>
            {/* -- End Footer -- */}

            <a href="#" className="back-to-top d-flex align-items-center justify-content-center"><i className="bi bi-arrow-up-short"></i></a>
        </>
    );
}

export default Footer;