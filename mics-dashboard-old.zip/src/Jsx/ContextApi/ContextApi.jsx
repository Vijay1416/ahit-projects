import { createContext } from "react";

export const LoginContextApi = createContext(null);