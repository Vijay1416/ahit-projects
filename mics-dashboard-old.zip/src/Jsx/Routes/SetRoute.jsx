import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Home from '../Home/Home';
import { LoginContextApi } from '../ContextApi/ContextApi';
import Login from '../Login/Login';

function SetRoute() {
    const [loginName, setLoginName] = useState(localStorage.getItem('username'));

    return (
        <LoginContextApi.Provider value={{ loginName, setLoginName }}>
            <Routes>
                {loginName ? (
                    <>
                        <Route path='/' element={<Home />} />
                        <Route path='/login' element={<Navigate to='/' replace />} />
                    </>
                ) : (
                    <>
                        <Route path='/login' element={<Login />} />
                        <Route path='/' element={<Navigate to='/login' replace />} />
                    </>
                )}
            </Routes>
        </LoginContextApi.Provider>
    );
}

export default SetRoute;
