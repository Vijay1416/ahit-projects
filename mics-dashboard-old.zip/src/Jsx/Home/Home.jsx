import React from 'react';
import MainCategory from '../../Dashboard/MainCategory/MainCategory';
import MainContent from '../../Dashboard/MainCategory/MainContent';

function Home() {
    return ( 
        <>
        <MainCategory>
            <MainContent />
        </MainCategory>
        </>
     );
}
export default Home;