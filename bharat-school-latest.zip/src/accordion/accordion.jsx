
import React from 'react'


function Accordion() {
    return (
        <>
            <div className="accordion" id="accordionExample">
                <div className="accordion-item">
                    <h2 className="accordion-header">
                        <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Expert Industry Knowledge
                        </button>
                    </h2>
                    <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                        Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus .
                        </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Tailored Solutions
                        </button>
                    </h2>
                    <div id="collapseTwo" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                        Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus .
                        </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        Proven Success
                        </button>
                    </h2>
                    <div id="collapseThree" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                        Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus .
                        </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                        Clear Communication
                        </button>
                    </h2>
                    <div id="collapseFour" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                        Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus .
                        </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header">
                        <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapsFive">
                        Cutting-Edge Technology
                        </button>
                    </h2>
                    <div id="collapseFive" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                        Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus .
                        </div>
                    </div>
                </div>
            </div>
        </>
    )

}
export { Accordion };


