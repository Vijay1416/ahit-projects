import React,{useEffect} from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import Vactor_1 from '../images/vactor/vactor-1.svg'
import Texture_1 from '../images/vactor/texture-1.svg'
import Hero_bg from '../images/background/hero-bg.svg'
import Vactor_2 from '../images/vactor/vactor-2.svg'
import Texture_2 from '../images/vactor/texture-2.svg'
import Line_img from '../images/icons/lines.svg' 
import Star_img from '../images/icons/star.svg'  
import Star1_img from '../images/icons/star2.svg'  
import Rounds_img from '../images/icons/rounds.svg'  
import Search from '../images/icons/search.svg'
import see_student from '../images/vactor/see_student.svg'
import { fastdata, hero_area, recschool_area, school_boxes } from '../data/data'
import { Sc_slider } from './sc_slider'

function Section1() {
  useEffect(() => {
    AOS.init();
  }, [])
  return (
    <>
      <section className="hero_area">
        <div className="hero_area-inner">
          <img src={Vactor_1} alt="" className='vactor-1' data-aos="fade-up"  data-aos-duration="1500"/>
          <img src={Texture_1} alt="" className='texture-1' />
          <div className="school-vac">
            <img src={Vactor_2} alt="" className='vactor-2'data-aos="fade-up"  data-aos-duration="1500" />
            <img src={Texture_2} alt="" className='texture-1' />

          </div>

        </div>
        <div className="container z-11">
          <div className="row">
            {hero_area.map((hero_area_1, herokey1) => (
              <div className="col-xl-8 mx-auto" key={herokey1}>
                <div className="hero_area-inner-1">
                  <h1 data-aos="flip-left" data-aos-duration="1200">{hero_area_1.h1} <span>{hero_area_1.span} </span> </h1>

                  <p data-aos="fade-up"  data-aos-duration="1200">{hero_area_1.p1}</p>
                  <div className="form-box" data-aos="fade-zoom-in"  data-aos-duration="1900">
                    <input type="text" placeholder="Search By Pin-Code" />
                    <button>
                      <img src={Search} alt="" />   Search
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <img src={Hero_bg} alt="" className='hero-bg' />
      </section>

    </>
  )
}

export { Section1 };


function Section2() {
  return (
    <>
      <section className="recschool-area">
        <div className="container z-11">
          <div className="row">
            <div className="col-xl-12 text-center">
              {recschool_area.map((recschool_area_1,herokey2) => (
                <div className="recschool-inner" key={herokey2}>
                  <h1 data-aos="fade-up"  data-aos-duration="1200">{recschool_area_1.h1} <span>{recschool_area_1.span}</span> </h1>
                  <p className=' m-auto'>{recschool_area_1.p1}</p>
                </div>
              ))

              }

            </div>
            <div className="col-xl-12">
              <div className="recschool-inner-1">
                <div className="row pt-5 d-xl-flex d-none">
                  {school_boxes.map((school_boxes_1,herokey3) => (
                    <div className="col-xxl-3 col-xl-4 col-lg-6 my-3  " data-aos="fade-up"  data-aos-duration="1200" key={herokey3}>
                      <div className="school-box">
                        <div className="sechool-box-inner">
                          <div className="image_box">
                            <img src={school_boxes_1.bigimg} alt="" />
                          </div>
                          <div className="content">
                            <span>{school_boxes_1.span}</span>
                            <h3>{school_boxes_1.headding}</h3>
                            <span className='address_span'>
                              <img src={school_boxes_1.icon} alt="" />
                              <span>{school_boxes_1.address}</span>
                            </span>
                            <div className="start-box">
                              <span>
                                <i className="fa-solid fa-star"></i>
                                <i className="fa-solid fa-star"></i>
                                <i className="fa-solid fa-star"></i>
                                <i className="fa-solid fa-star"></i>
                                <i className="fa-solid fa-star"></i>5
                              </span>
                              <a href="">
                              Starts On : 18 Sep
                              </a>

                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                  }

                          <div className="col-xl-12 text-center">
                                <a className="border-btn mt-md-5 mt-2">
                                  View More
                                  <i className="fa-solid fa-arrow-up"></i>
                                </a>
                          </div>
                </div>
                <div className="row  d-xl-none d-flex">
                  <div className="col-xl-12 overflow-hidden  ">
                      <Sc_slider  />  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="overlay-icons">
           <img src={Line_img} alt="" />
           <img src={Star_img} alt="" /> 
           <img src={Star1_img} alt="" />

        </div>
      </section>
    </>
  )
}

export { Section2 };


function Section3() {
  return(
  <>
   <section className="fast-area">
    <div className="container z-11">
 
      <div className="row">
        <div className="col-xl-7">
            <div className="fast-area-inner">
              {fastdata.map((fastdata_1,herokey4) => (
                <> 
                  <span  data-aos="fade-right"  data-aos-duration="1200">{fastdata_1.span}</span>
                 <h3 data-aos="fade-right"  data-aos-duration="1200">{fastdata_1.h3}</h3>
                 <p data-aos="fade-right"  data-aos-duration="1200">{fastdata_1.p1}</p> 
                 <div className="fast-area-box-1 pt-4 d-flex  " data-aos="fade-up"  data-aos-duration="1200">
                    <span><img src={fastdata_1.fast.image} alt="" /></span>
                    <div className="content">
                      <h3>{fastdata_1.fast.h3}</h3>
                      <span>{fastdata_1.fast.span}</span>
                    </div>
                 </div>
                 <div className="fast-area-box-1  pt-4 d-flex " data-aos="fade-up"  data-aos-duration="1200">
                    <span className='color-code-2'><img src={fastdata_1.near.image} alt="" /></span>
                    <div className="content">
                      <h3>{fastdata_1.near.h3}</h3>
                      <span>{fastdata_1.near.span}</span>
                    </div>
                 </div>
                 <div className="fast-area-box-1  pt-4 d-flex " data-aos="fade-up"  data-aos-duration="1200">
                    <span className='color-code-3'><img src={fastdata_1.best.image} alt="" /></span>
                    <div className="content">
                      <h3>{fastdata_1.best.h3}</h3>
                      <span>{fastdata_1.best.span}</span>
                    </div>
                 </div>
                 <a href="" className='mt-5'>
                 {fastdata_1.a.span}
                 <img src={fastdata_1.a.img} alt="" />

                 </a>
                 <img src={fastdata_1.img}alt="" className='student-img' data-aos="fade-up"    />
                </>
               
                ))
              }
              
            </div>
        </div>
        <div className="col-xl-5">
        <div className="fast-area-inner-2">
          <img src={see_student} alt="" className='img-fluid' />
        </div>
        </div>
      </div>
    </div>
    <div className="overlay-icons">
           <img src={Line_img} alt="" />
           <img src={Star_img} alt="" /> 
           <img src={Rounds_img} alt="" />

        </div>
   </section>
  </>
)

}
export { Section3 };

 
 