import React,{useEffect} from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { articlesdata } from '../data/data';
import icon1 from '../images/icons/icon1.svg'
import icon2 from '../images/icons/icon2.svg' 
import icon3 from '../images/icons/icon3.svg'
import Headcap1 from '../images/icons/headcap1.svg'
 

function Articles() {
    return (
        <>
    <section className="articles-area">
        <div className="container z-11">
            <div className="row">
                {articlesdata.map((articlesdata_1 ,art) =>(
                    <>  
                       <div className="col-xl-3 col-md-5 mx-auto text-center pb-sm-4">
                        <div className="articles_inner">
                            <img src={Headcap1} alt="" />
                            <h3>{articlesdata_1.h2}</h3>
                        </div>
                       </div>  
                       <div className="row mx-auto w-100 ">
                          <div className="col-xl-4 mb-xl-0 mb-4">
                               <div className="artical_box">
                                <div className="image">
                                      <img src={articlesdata_1.artical1.img} alt="" className='' /></div>
                                      <div className="content">
                                        <span>{articlesdata_1.artical1.span}</span>
                                        <h2>{articlesdata_1.artical1.h2}</h2>
                                        <p>{articlesdata_1.artical1.p}</p>
                                        <span>{articlesdata_1.artical1.span1}</span>
                                         <div className="box">
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                         </div>

                                      </div>
                                
                               </div>
                          </div>
                          <div className="col-xl-4 mb-xl-0 mb-4">
                               <div className="artical_box">
                                <div className="image">
                                      <img src={articlesdata_1.artical1.img} alt="" className='' /></div>
                                      <div className="content">
                                        <span>{articlesdata_1.artical1.span}</span>
                                        <h2>{articlesdata_1.artical1.h2}</h2>
                                        <p>{articlesdata_1.artical1.p}</p>
                                        <span>{articlesdata_1.artical1.span1}</span>
                                         <div className="box">
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                         </div>

                                      </div>
                                
                               </div>
                          </div>
                          <div className="col-xl-4 mb-xl-0 mb-4">
                               <div className="artical_box">
                                <div className="image">
                                      <img src={articlesdata_1.artical1.img} alt="" className='' /></div>
                                      <div className="content">
                                        <span>{articlesdata_1.artical1.span}</span>
                                        <h2>{articlesdata_1.artical1.h2}</h2>
                                        <p>{articlesdata_1.artical1.p}</p>
                                        <span>{articlesdata_1.artical1.span1}</span>
                                         <div className="box">
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                            <a href=""><img src={articlesdata_1.artical1.icon1} alt="" /><span>{articlesdata_1.artical1.text1}</span></a>
                                         </div>

                                      </div>
                                
                               </div>
                          </div>
                          <div className="col-xl-12 text-center"><a className="border-btn1 mt-md-5 mt-2"  >View More<i className="fa-solid fa-arrow-up"></i></a></div>
                       </div>
                    </>
                ))}

            </div>
        </div>
        <div className="overlay-icons">
                    <img src={icon1} alt="" />
                    <img src={icon2} alt="" />
                    <img src={icon3} alt="" />

                </div>
    </section>
        </>
    )

}
export { Articles };


