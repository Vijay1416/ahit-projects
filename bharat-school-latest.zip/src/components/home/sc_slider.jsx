import React, { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Pagination, Navigation } from 'swiper/modules';
import { school_boxes, sliderdata } from '../data/data';
import Line_img from '../images/icons/lines.svg'
import Star_img from '../images/icons/star.svg'
import Star1_img from '../images/icons/star2.svg'
import Rounds_img from '../images/icons/rounds.svg'
import Ring from '../images/icons/ring.svg'
import Headcap from '../images/icons/headcap.svg'

function Sc_slider() {
  useEffect(() => {
    AOS.init();
  }, [])
  return (
    <>
      <Swiper slidesPerView={3} spaceBetween={30} loop={true} pagination={{ clickable: true, }}
        navigation={true}
        modules={[Pagination, Navigation]}
        breakpoints={{
          300: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          1250: {
            slidesPerView: 2,
            spaceBetween: 40,
          },
          1450: {
            slidesPerView: 3,
            spaceBetween: 50,
          },
          2000: {
            slidesPerView: 5,
            spaceBetween: 50,
          },
        }}
        className="mySwiper"
      >

        {school_boxes.map((school_boxes_1, herokey3) => (
          <SwiperSlide >
             <div className=" w-100 my-3  " data-aos="fade-up" data-aos-duration="1200" key={herokey3}>
            <div className="school-box">
              <div className="sechool-box-inner w-100">
                <div className="image_box">
                  <img src={school_boxes_1.bigimg} alt="" />
                </div>
                <div className="content">
                  <span>{school_boxes_1.span}</span>
                  <h3>{school_boxes_1.headding}</h3>
                  <span className='address_span'>
                    <img src={school_boxes_1.icon} alt="" />
                    <span>{school_boxes_1.address}</span>
                  </span>
                  <div className="start-box">
                    <span>
                      <i className="fa-solid fa-star"></i>
                      <i className="fa-solid fa-star"></i>
                      <i className="fa-solid fa-star"></i>
                      <i className="fa-solid fa-star"></i>
                      <i className="fa-solid fa-star"></i>5
                    </span>
                    <a href="">
                      Starts On : 18 Sep
                    </a>

                  </div>
                </div>
              </div>
            </div>
          </div></SwiperSlide>
         
        ))
        }
       

      </Swiper>
    </>
  )

}
export { Sc_slider };


