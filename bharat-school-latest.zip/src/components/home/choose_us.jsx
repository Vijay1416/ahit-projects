 
import { whyusdata } from '../data/data';
import { Accordion } from '../../accordion/accordion';
import Line_img from '../images/icons/lines.svg' 
import Star_img from '../images/icons/star.svg'  
import Star1_img from '../images/icons/star2.svg'  
import Rounds_img from '../images/icons/rounds.svg'  
import React,{useEffect} from "react";
import AOS from "aos";
import "aos/dist/aos.css";

function Choose_us() {
    useEffect(() => {
        AOS.init();
      }, [])
    return (
        <>
        <section className='why_us_area'>
         <div className="container z-11">
              <div className="row">
                <div className="col-xxl-3 col-xl-4 mb-xl-0 mb-5">
                       {whyusdata.map((whyusdata_1,why) =>(
                        <>
                           <div className="why_us_area_inner" key={why}>
                            <h3 data-aos="fade-right"  data-aos-duration="1200">{whyusdata_1.h3}</h3>
                            <p data-aos="fade-right"  data-aos-duration="1200">{whyusdata_1.p}</p>


                            <div className="why_us_box" data-aos="fade-up"  data-aos-duration="1200">
                                  <div className="image">
                                    <img src={whyusdata_1.support.img} alt="" />
                                    </div> 
                                    <div className="content">
                                          <h2>{whyusdata_1.support.h2}|</h2>
                                           <p>{whyusdata_1.support.p}</p>
                                           <div className="box">
                                            <div className="box_inner">
                                                  <img src={whyusdata_1.support.box.img}  alt="" />
                                                  <span>{whyusdata_1.support.box.span}</span>
                                            </div>
                                            <div className="box_inner">
                                                  <img src={whyusdata_1.support.box1.img}  alt="" />
                                                  <span>{whyusdata_1.support.box1.span}</span>
                                            </div>
                                           </div>
                                  </div>
                            </div>
                           </div>
                        </>
                       ))}
                </div>
                <div className="col-xxl-9 col-xl-8">
                    <div className="why_us_inner_1">
                        <Accordion />
                    </div>
                </div>
              </div>
         </div>
         <div className="overlay-icons">
           <img src={Line_img} alt="" />
           <img src={Star_img} alt="" /> 
           <img src={Star1_img} alt="" />

        </div>
        </section>
        </>
    )

}
export { Choose_us };


