import React from 'react'
import { Section1, Section2, Section3 } from './home-sections'
import { Dig_plat } from './dig_plat'
import { Choose_us } from './choose_us'
import { Review } from './review'
import { Articles } from './articles'
 
 
 

function Home() {
  return (
    <>
  <Section1 />
  <Section2 />
  <Section3 />
  <Dig_plat />
  <Choose_us />
  <Review />
  <Articles />
    </>
  )
}

export default Home
