 
import {dig_plat_data,dig_plat_data2 } from '../data/data'
import React,{useEffect} from "react";
import AOS from "aos";
import "aos/dist/aos.css";

function Dig_plat() {
    useEffect(() => {
        AOS.init();
      }, [])
    return (
        <>
            <section className="digit_plat_area">
                <div className="container">
                    <div className="row">
                        <div className="col-xxl-6 col-xl-7">

                            {dig_plat_data.map((dig_plat_data_1,digkey) => (
                                <>
                                    <div className="digit_plat_area_inner" key={digkey}>
                                        <span data-aos="fade-right"  data-aos-duration="1200">{dig_plat_data_1.span}</span>
                                        <h2 data-aos="fade-right"  data-aos-duration="1200">{dig_plat_data_1.h2}</h2>
                                        <p data-aos="fade-in"  data-aos-duration="1200">{dig_plat_data_1.p}</p>
                                        <a href="">{dig_plat_data_1.a}
                                            <img src={dig_plat_data_1.img} alt="" />
                                        </a>
                                    </div>
                                </>    
                            ))}

                        </div>
                        <div className="col-xxl-4 col-xl-5 mx-auto mt-xl-0 mt-5 pt-xl-5">
                            <div className="digit_plat_area_inner_1">
                                  {dig_plat_data2.map((dig_plat_data_2 ,digkey1) => (
                                    <>
                                    <div className="digit_plat-box mb-4"  data-aos="fade-left"  key={digkey1} data-aos-duration="2000" data-aos-delay="100">
                                           <span >{dig_plat_data_2.box_1.span}</span>
                                           <h3>{dig_plat_data_2.box_1.h3}</h3>
                                           <p>{dig_plat_data_2.box_1.p}</p>
                                    </div>
                                    <div className="digit_plat-box mb-4 ms-auto" data-aos="fade-left"  data-aos-duration="2000" data-aos-delay="400">
                                           <span>{dig_plat_data_2.box_2.span}</span>
                                           <h3>{dig_plat_data_2.box_2.h3}</h3>
                                           <p>{dig_plat_data_2.box_2.p}</p>
                                    </div>
                                    <div className="digit_plat-box mb-4" data-aos="fade-left"  data-aos-duration="2000" data-aos-delay="80">
                                           <span>{dig_plat_data_2.box_3.span}</span>
                                           <h3>{dig_plat_data_2.box_3.h3}</h3>
                                           <p>{dig_plat_data_2.box_3.p}</p>
                                    </div>
                                    </>   
                                  ))}   
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )

}
export { Dig_plat };


