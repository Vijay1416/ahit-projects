import React,{useEffect} from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { Pagination, Navigation } from 'swiper/modules';
import { sliderdata } from '../data/data';
import Line_img from '../images/icons/lines.svg'
import Star_img from '../images/icons/star.svg'
import Star1_img from '../images/icons/star2.svg'
import Rounds_img from '../images/icons/rounds.svg'
import Ring from '../images/icons/ring.svg'
import Headcap from '../images/icons/headcap.svg'

function Review() {
    useEffect(() => {
        AOS.init();
      }, [])
    return (
        <>
            <section className="review-area">
                <div className="container z-11">
                    <div className="row">
                        <div className="col-xl-3 col-md-4 mx-auto text-center pb-sm-4">
                            <div className="review-area-inner">
                                <img src={Headcap} alt="" />       
                                  <h2 data-aos="fade-up"  data-aos-duration="1200">Testimonials</h2>
                                <p data-aos="fade-up"  data-aos-duration="1200">What clients are saying for our work</p>
                            </div>

                        </div>
                        <div className="col-xl-12 pt-5 slider_pd ">
                            <Swiper slidesPerView={3} spaceBetween={30} loop={true} pagination={{ clickable: true, }}
                                navigation={true}
                                modules={[Pagination, Navigation]}
                                breakpoints={{
                                    300: {
                                        slidesPerView: 1,
                                        spaceBetween: 20,
                                    },
                                    640: {
                                        slidesPerView: 2,
                                        spaceBetween: 20,
                                    },
                                    1250: {
                                        slidesPerView: 2,
                                        spaceBetween: 40,
                                    },
                                    1450: {
                                        slidesPerView: 3,
                                        spaceBetween: 50,
                                    },
                                    2000: {
                                        slidesPerView: 5,
                                        spaceBetween: 50,
                                    },
                                }}
                                className="mySwiper"
                            >
                                {sliderdata.map((slider_data, sld) => (

                                    <SwiperSlide >{slider_data.h3}
                                        <div className="review-box text-center" data-aos="fade-up"  data-aos-duration="1200">
                                            <img src={slider_data.img} alt="" />
                                            <p>{slider_data.p}</p>
                                        </div>
                                    </SwiperSlide>

                                ))}

                            </Swiper>
                        </div>
                    </div>
                </div>
                <div className="overlay-icons">
                    <img src={Line_img} alt="" />
                    <img src={Star_img} alt="" />
                    <img src={Ring} alt="" />

                </div>
            </section>
        </>
    )

}
export { Review };


