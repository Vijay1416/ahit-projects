import React from "react";
import { footerdata, socialdata } from "../data/data";
import { Links_box } from "./links_box";
 
 
 

function Footer() {
    return (
        <>
        <footer>
            <div className="container">
                {footerdata.map((footerdata_1 ,foot) => (
                    <>
                       <div className="row mb-xl-5">
                           <div className="col-xxl-5 col-xl-6 mb-xl-0 mb-5">
                            <div className="footer_inner_1">
                                <img src={footerdata_1.logo} alt="" />
                            <p>{footerdata_1.p}</p>
                            <div className="co_detail_box">
                                <div className="con-details">
                                <img src={footerdata_1.details.call} alt="" />
                                <div className="content">
                                       <span>{footerdata_1.details.sapn}</span>
                                       <h5>{footerdata_1.details.h5}</h5>
                                </div>
                            </div>
                            <div className="con-details">
                                <img src={footerdata_1.details1.call} alt="" />
                                <div className="content">
                                       <span>{footerdata_1.details1.sapn}</span>
                                       <h5>{footerdata_1.details1.h5}</h5>
                                </div>
                            </div>
                            </div>
                            
                            </div>
                            
                           </div>
                           <Links_box />
                    </div>
                    <hr className="mt-5" />
                    <div className="row">
                        <div className="col-xl-12">
                                  <div className="footer-bootom">
                                    <h6>Copyright © 2023 BharatSchoolsOrg. All rights reserved.</h6>
                                    <ul>
                                     <Social />
                                    </ul>
                                  </div>
                        </div>
                    </div>
                    </>
                ))}
                 
            </div>
        </footer>
        </>
    )

}
export { Footer };


function Social() {
    return(
  <>
    {socialdata.map((socialdata_1 ,socl) =>(
        <>
        <li><img src={socialdata_1.img} alt="" /></li>
        </>
    ))}
 </>
    )
}

export {Social}