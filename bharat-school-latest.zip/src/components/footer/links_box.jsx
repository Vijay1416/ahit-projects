import React from "react";
import { linksdata } from "../data/data";


function Links_box() {
    return (
        <>
            {linksdata.map((linksdata_1, link) => (
                <>
                    <div className="col-xl-2" key={link}>
                        <div className="linksbox">
                             <h5>{linksdata_1.h5}</h5>
                             <a href={linksdata_1.ln1.link}>{linksdata_1.ln1.text}</a>
                             <a href={linksdata_1.ln2.link}>{linksdata_1.ln2.text}</a>
                             <a href={linksdata_1.ln3.link}>{linksdata_1.ln3.text}</a>
                             <a href={linksdata_1.ln4.link}>{linksdata_1.ln4.text}</a>
                        </div>
                    </div>
                </>
            ))}


        </>
    )

}
export { Links_box };


