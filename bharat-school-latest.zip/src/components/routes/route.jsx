import { BrowserRouter as Router, Routes, Route, Link, Switch, browserHistory } from 'react-router-dom';
  
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../node_modules/bootstrap/dist/js/bootstrap.min.js'
 

 

function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Switch> 
          <Route exact path="/" component={Home} />
 
        </Switch>
        <ScrollButton />
      </Router>
    </>

  );
};  

export default App;
