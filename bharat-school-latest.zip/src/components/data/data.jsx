import image_1 from '../images/schools_images/school_1.png'
import location_icon from '../images/icons/location_icon.svg'
import fast from '../images/icons/fast.svg'
import near from '../images/icons/near.svg'
import best from '../images/icons/best.svg'
import right from '../images/icons/right.svg'
import student from '../images/vactor/student.svg'
import supportimg from '../images/vactor/support.svg'
import message from '../images/icons/message.svg'
import call from '../images/icons/call.svg'
import review_1 from '../images/review/review-1.svg'
import review_2 from '../images/review/review-2.svg'
import review_3 from '../images/review/review-3.svg'
import artical_1 from '../images/artical/artical_1.png'
import clorck from '../images/icons/clorck.svg'
import logo from '../images/logo/logo_footer.png'
import call_con from '../images/icons/call_con.png'
import email from '../images/icons/email.png'
import social1 from '../images/social/instra.png'
import social2 from '../images/social/fasebook.png'
import social3 from '../images/social/teligram.png'
import social4 from '../images/social/linkdin.png'
import social5 from '../images/social/youtube.png'

 




export const hero_area = [
    {
        h1: "Find Over 500+ In India",
        span: "Schools ,Collages",
        p1: "Urna duis convallis convallis tellus id interdum velit laoreet id. Sollicitudin nibh sit amet  commodo nulla. Amet venenatis urna cursus eget nunc. Aliquam faucibus purus in massa tempor nec feugiat. Pharetra vel turpis nunc eget.",

    }

]
export const recschool_area = [
    {
        h1: "Recommanded",
        span: "School’s",
        p1: "Urna duis convallis convallis tellus id interdum velit laoreet id. Sollicitudin nibh sit amet commodo nulla. Amet venenatis urna cursus eget nunc",

    }

]

export const school_boxes = [

    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },
    {
        bigimg: image_1,
        span: 'School',
        headding: 'Veer Balika',
        icon: location_icon,
        address: 'No. 4655, Beri Ka Bas, 3rd Cross, Johari Bazaar, K G B Ka Rasta, Adarsh Nagar, Jaipur - 302003',

    },

]


export const fastdata = [
    {
        span: "WHY US",
        h3: "Who are we and why us?",
        p1: "Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.",

        fast: {
            image: fast,
            h3: "Fast Finding",
            span: "Arcu non odio euismod lacinia at quis risus. Fusce ut placerat orci."
        },
        near: {
            image: near,
            h3: "Near By Finding",
            span: "Arcu non odio euismod lacinia at quis risus. Fusce ut placerat orci."
        },
        best: {
            image: best,
            h3: "Best Finding",
            span: "Arcu non odio euismod lacinia at quis risus. Fusce ut placerat orci."
        },
        a: {
            span: "More About us",
            img: right,
        },
        img: student,

    }

]

export const dig_plat_data = [
    {

        span: "ABOUT US",
        h2: "Innovative Digital Platform For Creative Persons",
        p: "Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE schools in Kolkata, CBSE schools in Kolkata, Best schools in Kolkata according to the area of your choice with a focus on education as a priority, infrastructure & nature, like extra-curricular activities, programs, etc.Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving you the best ICSE  "
        ,
        a: "More About us",
        img: right,
    }
]



export const dig_plat_data2 = [
    {
        box_1: {
            span: "SCHOOLS",
            h3: "240+",
            p: "Donec sit amet turpis tincidunt eros, nam  porttitor massa leo porta maecenas reque."


        },
        box_2: {
            span: "RATING",
            h3: "300+",
            p: "Donec sit amet turpis tincidunt eros, nam  porttitor massa leo porta maecenas reque."


        },
        box_3: {
            span: "USER",
            h3: "624+",
            p: "Donec sit amet turpis tincidunt eros, nam  porttitor massa leo porta maecenas reque."


        }
    }]


export const whyusdata = [
    {
        h3: "Why Choose Us?",
        p: "Welcome to School Dekho, Best School near me, Kolkata. India’s first search engine for school admissions. We're dedicated to giving",
        support: {
            img: supportimg,
            h2: "Need Support?",
            p: "Feugiat sed lectus vestibulum mattis fusce ut placerat orci ullamcorper velit.",
            box: {
                img: message,
                span: "Contact Us"
            },
            box1: {
                img: call,
                span: "Call Us"
            }
        }

    }]
export const sliderdata = [
    {
        img: review_1,
        p: "I discovered Bharat School while searching for schools, and it saved me time and confusion.",

    },
    {
        img: review_2,
        p: "I discovered Bharat School while searching for schools, and it saved me time and confusion.",

    },
    {
        img: review_3,
        p: "I discovered Bharat School while searching for schools, and it saved me time and confusion.",

    },
    {
        img: review_1,
        p: "I discovered Bharat School while searching for schools, and it saved me time and confusion.",

    },
    {
        img: review_2,
        p: "I discovered Bharat School while searching for schools, and it saved me time and confusion.",

    },
]

export const articlesdata = [
    {
        h2: "Recent Articles",
        artical1: { 
            img: artical_1,
            span:"Science and Nature",
            h2:"Exploring the Wonders of Deep Sea Biodiversity",
            p:"Dive into the mysterious realm of the deep sea and uncover the astounding biodiversity that thrives...",
             span1:"February 29th, 2024 11:32 AM IST",
             icon1:clorck,
             text1:"11:42 am",
        }
    }
]


export const footerdata = [
    {
     logo:logo,
   p:"Massa sapien faucibus et molestie ac feugiat sed lectus odio morbi. vehicula in. Pellentesque condimentum ntum vehicula.Nulla convallis enim eu velit.",
   details:{
     call:call_con,
     sapn:"Call Us Anytime",
      h5:"+91-92148-59550"
   },
   details1:{
    call:email,
    sapn:"Email Us Anytime",
     h5:"baratschoolsworld@gmail.com"
  }
    }
]


export const linksdata =[
    {
        h5:"Information",
        ln1:{
            link:"./AboutUs",
            text:"About Us"
        },
        ln2:{
            link:"./terms",
            text:" Terms & Conditions"
        },
        ln3:{
            link:"./privacy",
            text:" Privacy Policy"
        },ln4:{
            link:"./contactus",
            text:" Contact Us"
        } 
    },
    {
        h5:"Quick Links",
        ln1:{
            link:"./AboutUs",
            text:" Top 10 Schools"
        },
        ln2:{
            link:"./terms",
            text:"  Trending Schools"
        },
        ln3:{
            link:"./privacy",
            text:" FAQs"
        },ln4:{
            link:"./contactus",
            text:"  About"
        } 
    },
    {
        h5:"Top Schools in India",
        ln1:{
            link:"./AboutUs",
            text:" Top Schools in Jaipur"
        },
        ln2:{
            link:"./terms",
            text:" Top Schools in Delhi"
        },
        ln3:{
            link:"./privacy",
            text:"  Top Schools in Haryana"
        },ln4:{
            link:"./contactus",
            text:" Top Schools in Rajasthan"
        } 
    },
]


export const socialdata =[
    {
        img:social1,
    },
    {
        img:social2,
    },
    {
        img:social3,
    },
    {
        img:social4,
    },
    {
        img:social5,
    },
]