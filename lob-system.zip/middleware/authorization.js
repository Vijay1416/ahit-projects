const Access = require("../models/role.access.model");
const Roles = require('../models/user_roles_model')
const Menu = require('../models/sidebar_model')

const checkAccess = (resource, method) => {
    return async (req, res, next) => {
        try {
            const access = await Access.findOne({
                role_id: req.user.user_role._id,
                resource: resource,
                method: method
            });

            if (access && access.can_access) {
                next();
            } else {
                return res.redirect(`/access-denied?message=Access denied for ${resource}`);
            }
        } catch (error) {
            console.error(error);
            return res.redirect(`/access-denied?message=Server Error`);
        }
    };
};

const roleChecker = (allowedRoles) => {
    return async (req, res, next) => {
      try {
        const userRole = req.user?.user_role?.role_name;
  
        if (!userRole) {
          return res.redirect(`admin/dashboard/login?error=Unauthorized. Please log in.`);
        }
  
        if (allowedRoles.includes(userRole)) {
          return next(); 
        }
  
        return res.redirect(`/admin/dashboard/error?error=Access denied`);
      } catch (error) {
        console.error(error);
        return res.redirect(`/admin/dashboard/error?error=Server Error: ${error.message}`);
      }
    };
  };



module.exports = roleChecker;
