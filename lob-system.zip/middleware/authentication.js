const jwt = require('jsonwebtoken');
const User = require('../models/user_model');
const Roles = require('../models/user_roles_model');
const { JSONWEBKEY } = process.env
const auths = async (req, res, next) => {
    const token = req.cookies['__token'];
    if (!token) {
        return res.status(401).render('login', { data: { error: 'Your session has expired or you are not logged in.' } });
    }
    try {
        const tokenChecker = jwt.verify(token,  `${JSONWEBKEY}`)
        if (!tokenChecker) return res.render('login', { data: { error: 'Token expired. Please log in to renew your session.' } });
        req.user = await User.findById({ _id: tokenChecker.userId }).populate("user_role", "role_name")
        // let userRoleChecker = await Roles.findById({_id:req.user.user_role._id})
        // console.log(userRoleChecker)
        // if(!userRoleChecker) {
        //     res.send("token expire")
        // }
        if (!req.user) {
            return res.status(401).render('login', { data: { error: 'User not found. Please log in again.' } });
        }
        res.cookie('User', req.user, { maxAge: 1000 * 60 * 60 * 24, httpOnly: true });
        next()
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).render('login', { data: { error: 'Token expired. Please log in to renew your session.' } });
        } else {
            console.error('JWT error:', error.message);
            return res.status(400).render('login', { data: { error: 'Invalid session. Please log in again.' } });
        }
    }
}
module.exports = auths

