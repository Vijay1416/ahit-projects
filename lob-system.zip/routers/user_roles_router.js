const express = require("express");
const user_roles_router = express.Router();
const roleController = require("../controllers/user_roles_controller");

user_roles_router.post("/", roleController.createRole);
user_roles_router.get("/", roleController.getAllRoles);
user_roles_router.get("/:id", roleController.getRoleById);
user_roles_router.put("/:id", roleController.updateRole);
user_roles_router.delete("/:id", roleController.deleteRole);

module.exports = user_roles_router;
