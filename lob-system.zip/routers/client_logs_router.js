const express = require('express');
const { client_logs } = require('../controllers/client_logs_controller');
const client_logs_router = express.Router();

client_logs_router.get('/:id' ,client_logs);

module.exports = client_logs_router;
