const express = require('express');
const {
    getUsers, getUserById,
    createUser, updateUser,
    deleteUser, applyDynamicFields,
    login, logout
} = require('../controllers/user_controller');
const user_router = express.Router();

user_router.get('/', getUsers);
user_router.post('/login', login);
user_router.get('/:id', getUserById);
user_router.post('/', createUser);
user_router.post('/logout', logout);
user_router.put('/:id', updateUser);
user_router.delete('/:id', deleteUser);
user_router.post('/dynamic-field', applyDynamicFields);

module.exports = user_router;
