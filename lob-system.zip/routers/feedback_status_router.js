const express = require('express');
const feedbackStatusRouter = express.Router();
const feedbackStatusController = require('../controllers/feedback_status_controller');

feedbackStatusRouter.post('/', feedbackStatusController.createFeedbackStatus);
feedbackStatusRouter.get('/', feedbackStatusController.getAllFeedbackStatuses);
feedbackStatusRouter.get('/:id', feedbackStatusController.getFeedbackStatusById);
feedbackStatusRouter.put('/:id', feedbackStatusController.updateFeedbackStatus);
feedbackStatusRouter.delete('/:id', feedbackStatusController.deleteFeedbackStatus);

module.exports = feedbackStatusRouter;
