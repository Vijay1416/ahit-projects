const express = require('express');
const user_router = require('./user_router');
const venture_router = require('./ventures_router');
const team_router = require('./team_router');
const user_roles_router = require('./user_roles_router');
const client_router = require('./client_router');
const class_router = require('./class_router');
const stream_router = require('./Stream_router');
const clientTypeRouter = require('./client_type_router');
const institution_router = require('./Institution_router');
const feedbackStatusRouter = require('./feedback_status_router');
const sidebar_router = require('./sidebar_router');
const client_logs_router = require('./client_logs_router');
const Router = express()

Router.use('/users',user_router)
Router.use('/venture',venture_router)
Router.use('/teams',team_router)
Router.use('/roles',user_roles_router)
Router.use('/client',client_router)
Router.use("/class",class_router)
Router.use("/stream",stream_router)
Router.use("/client-type",clientTypeRouter)
Router.use("/institution",institution_router)
Router.use("/feedback-status",feedbackStatusRouter)
Router.use("/menu",sidebar_router)
Router.use("/client-log",client_logs_router)

module.exports = Router