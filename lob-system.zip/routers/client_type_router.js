const express = require('express');
const clientTypeRouter = express.Router();
const clientTypeController = require('../controllers/client_type_controller'); 

clientTypeRouter.post('/', clientTypeController.createClientType);
clientTypeRouter.get('/', clientTypeController.getAllClientTypes);
clientTypeRouter.get('/:id', clientTypeController.getClientTypeById);
clientTypeRouter.put('/:id', clientTypeController.updateClientType);
clientTypeRouter.delete('/:id', clientTypeController.deleteClientType);

module.exports = clientTypeRouter;
