const express = require('express');
const stream_router = express.Router();
const streamController = require('../controllers/Stream_controller');

stream_router.post('/', streamController.createStream);
stream_router.get('/', streamController.getAllStreams);
stream_router.get('/:id', streamController.getStreamById);
stream_router.put('/:id', streamController.updateStream);
stream_router.delete('/:id', streamController.deleteStream);

module.exports = stream_router;
