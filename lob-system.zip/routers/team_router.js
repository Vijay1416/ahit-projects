const express = require("express");
const team_router = express.Router();
const teamController = require("../controllers/team_controller");

team_router.post("/", teamController.createTeam);
team_router.get("/", teamController.getAllTeams);
team_router.get("/:id", teamController.getTeamById);
team_router.put("/update/:id", teamController.updateTeam);
team_router.delete("/delete/:id", teamController.deleteTeam);

module.exports = team_router;