const express = require('express');
const sidebar_router = express.Router();
const menuController = require('../controllers/sidebar_controller');

sidebar_router.get('/', menuController.getAllMenus);
sidebar_router.get('/new', menuController.renderNewMenuForm);
sidebar_router.post('/', menuController.createMenu);
sidebar_router.get('/:id/edit', menuController.renderEditMenuForm);
sidebar_router.post('/:id', menuController.updateMenu);
sidebar_router.post('/:id/delete', menuController.deleteMenu);

module.exports = sidebar_router;
