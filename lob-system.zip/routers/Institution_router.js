const express = require('express');
const institution_router = express.Router();
const institutionController = require('../controllers/Institution_controller');

institution_router.post('/', institutionController.createInstitution);
institution_router.get('/', institutionController.getAllInstitutions);
institution_router.get('/:id', institutionController.getInstitutionById);
institution_router.put('/:id', institutionController.updateInstitution);
institution_router.delete('/:id', institutionController.deleteInstitution);

module.exports = institution_router;
