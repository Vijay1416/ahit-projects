const Clients  = require('../controllers/client_controller')
const upload = require('../service/file_service')

const client_router = require('express').Router()

client_router.post('/',Clients.create_client)
client_router.get('/dwd',Clients.clientCsvDownload)
client_router.get('/:id',Clients.client_byId)
client_router.get('/',Clients.client_list)
client_router.delete('/delete/:id',Clients.delete_client)
client_router.post('/update/:id',Clients.update_client)
client_router.post('/bulk-stored',upload.single('file'),Clients.uploadAndInsertData)

module.exports  = client_router