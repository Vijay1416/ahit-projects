const express = require('express')
const auths = require('../middleware/authentication')
const Class = require('../models/class_model')
const Stream = require('../models/Stream_model')
const ClientType = require('../models/client_type_model')
const Institution = require('../models/Institution_model')
const feedbackStatus = require('../models/feedback_status_model')
const Client = require('../models/client_model')
const Menu = require('../models/sidebar_model')
const venture = require('../models/ventures_model')
const teams = require('../models/team_model')
const User = require('../models/user_model')
const Roles = require('../models/user_roles_model')
const LocalAccess = require('../middleware/authorization')
const app = express.Router()

async function dynamic_sidebar(role) {
    try {
        let menu = await Menu.find({}).sort({ startIn: 1 })
        return menu.filter(item => item.roles.includes(role));
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
}
let adminRole = 'Admin'
let userRoles = 'Agents'
app.get('/home', auths, LocalAccess([adminRole, userRoles]), async (req, res) => {
    try {
        let client
        let clients
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        if (req.user.user_role.role_name == 'Admin') {
            client = await Client.find().countDocuments()
            clients = await Client.find()
            .sort({ createdAt: -1 })
            .populate('userId', 'name')
            .populate('client_type', 'client_type color')
            .limit(500)
        } else {
            client = await Client.find({ alocaket: req.user._id }).countDocuments()
            clients = await Client.find({ alocaket: req.user._id })
            .populate('client_type', 'client_type color');
        }
        let team = await teams.find({}, { name: 1 }).countDocuments()
        let users = await User.find().countDocuments()
        let agents = await User.find({name:{$ne:'Admin'}}).sort({name:1})
        let ventureCounte = await venture.find({}).countDocuments()
        res.render("index", {
            user: req.user,
            data: {
                sidebar: menuItems,
                client,
                users,
                clients,
                team,
                ventureCounte,
                agents
            },
        })
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
})
app.get('/profile', auths, async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        res.render("profile", { data: { sidebar: menuItems }, user: req.user })
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
})
app.get('/login', (req, res) => {
    try {
        const token = req.cookies['__token'];
        if (token) {
            return res.redirect("home")
        }
        res.render("login", { data: {} })
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
})
app.get('/datatable', auths, LocalAccess([adminRole, userRoles]), async (req, res) => {
    try {
        let client;
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        const classes = await Class.find().sort({ createdAt: -1 });
        const streams = await Stream.find().sort({ createdAt: -1 });
        const clientTypes = await ClientType.find().sort({ createdAt: -1 });
        const institutions = await Institution.find().sort({ createdAt: -1 });
        const feedbackStatuses = await feedbackStatus.find().sort({ createdAt: -1 });
        let users = await User.find({ _id: { $ne: req.user._id } }, { password: 0 })
        if (req.user.user_role.role_name == 'Admin') {
            client = await Client.find()
                .populate('userId', 'name')
                .populate('alocaket', 'name')
                .populate('client_type', 'client_type color');
        } else {
            client = await Client.find({ alocaket: req.user._id })
                .populate('userId', 'name')
                .populate('alocaket', 'name')
                .populate('client_type', 'client_type color');
        }
        res.render("datatable", {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                classes, streams,
                clientTypes, institutions,
                feedbackStatuses,
                client,
                sidebar: menuItems,
                users
            }
        })
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
})
app.get('/calendar', auths, async (req, res) => {
    const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
    res.render("calendar", { data: { sidebar: menuItems }, user: req.user })
})
app.get('/access', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)

        res.render('access-manager', {
            title: 'Access Manager',
            formAction: 'list',
            accessList: [],
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/users', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        let users = await User.find({ _id: { $ne: req.user._id } }, { password: 0 })
            .populate('user_role', "role_name")
            .populate('team_id', "name")
        let team = await teams.find({}, { name: 1 })
        let roles = await Roles.find({ role_name: { $ne: "Admin" } })
        res.render('users', {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
                teams: team,
                users,
                roles
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/ventures', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        const AllData = await venture.find({})
        res.render('ventures', {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
                ventures: AllData
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/teams', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        const AllData = await venture.find({})
        let teamsData = await teams.find({}, { name: 1 }).populate('vId', 'name');
        res.render('teams', {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
                ventures: AllData,
                teams: teamsData
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/role', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        let roles = await Roles.find({ role_name: { $ne: "Admin" } })
        res.render('role', {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
                roles
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/colors', auths, LocalAccess([adminRole]), async (req, res) => {
    try {
        const menuItems = await dynamic_sidebar(req.user.user_role.role_name)
        const clientTypes = await ClientType.find({ client_type: { $ne: '-' } }).sort({ client_type: 1 });
        res.render('colors', {
            user: req.user,
            data: {
                message: '',
                error: req.query.error,
                sidebar: menuItems,
                clientTypes
            }
        });
    } catch (error) {
        res.redirect('/admin/dashboard/error?error=' + error.message)
    }
});
app.get('/error', auths, async (req, res) => {
    res.render('error', {
        user: req.user,
        data: {
            status: 400,
            message: 'An unexpected error occurred. Please try again later or contact support if the issue persists.',
            error: req.query.error,
        }
    });
});
app.get('*', (req, res) => {
    res.render("404")
})
module.exports = app