const express = require('express');
const classController = require('../controllers/class_controller')
const class_router = express.Router();

class_router.post('/', classController.createClass);
class_router.get('/', classController.getAllClasses);
class_router.get('/:id', classController.getClassById);
class_router.put('/:id', classController.updateClass);
class_router.delete('/:id', classController.deleteClass);

module.exports = class_router;
