const express = require("express");
const { ventureCreates, updateVenture, deleteVenture, findAllVenture } = require("../controllers/ventures_controller");

const venture_router = express.Router();

venture_router.post("/", ventureCreates);
venture_router.put("/update/:id", updateVenture);
venture_router.delete("/delete/:id", deleteVenture);
venture_router.get("/", findAllVenture);

module.exports = venture_router;
