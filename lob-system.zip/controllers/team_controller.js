const  Teams  = require("../models/team_model");

exports.createTeam = async (req, res) => {
    try {
        const { name,  vId } = req.body;
        const newTeam = new Teams(req.body );
        await newTeam.save();
        res.redirect("/admin/dashboard/teams")
    } catch (error) {
        res.redirect(`/admin/dashboard/teams?error=${error.message}`)
    }
};

exports.getAllTeams = async (req, res) => {
    try {
        const teams = await Teams.find().populate('vId');
        res.status(200).send({ status: true, data: teams });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error retrieving teams", error: error.message });
    }
};

exports.getTeamById = async (req, res) => {
    try {
        const team = await Teams.findById(req.params.id).populate('vId');
        if (!team) return res.status(404).send({ status: false, message: "Team not found" });
        res.status(200).send({ status: true, data: team });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error retrieving team", error: error.message });
    }
};

exports.updateTeam = async (req, res) => {
    try {
        console.log("update api ")
        const updatedTeam = await Teams.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedTeam) return res.status(404).send({ status: false, message: "Team not found" });
        res.status(200).send({ status: true, message: "Team updated successfully", data: updatedTeam });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error updating team", error: error.message });
    }
};

exports.deleteTeam = async (req, res) => {
    try {
        const deletedTeam = await Teams.findByIdAndDelete(req.params.id);
        if (!deletedTeam) return res.status(404).send({ status: false, message: "Team not found" });
        res.status(200).send({ status: true, message: "Team deleted successfully", data: deletedTeam });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error deleting team", error: error.message });
    }
};
