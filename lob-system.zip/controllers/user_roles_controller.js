const Roles = require("../models/user_roles_model");

exports.createRole = async (req, res) => {
    try {
        const { role_name } = req.body;
        if(!role_name) return  res.redirect('/admin/dashboard/role?error=Role Name Is Required')
        const newRole = new Roles({ role_name });
        await newRole.save();
        res.redirect('/admin/dashboard/role')
    } catch (error) {
        console.log(error)
        res.redirect('/admin/dashboard/role?error='+error.message)
    }
};
exports.getAllRoles = async (req, res) => {
    try {
        const roles = await Roles.find();
        res.status(200).send({ status: true, data: roles });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error retrieving roles", error: error.message });
    }
};

exports.getRoleById = async (req, res) => {
    try {
        const role = await Roles.findById(req.params.id);
        if (!role) return res.status(404).send({ status: false, message: "Role not found" });
        res.status(200).send({ status: true, data: role });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error retrieving role", error: error.message });
    }
};

exports.updateRole = async (req, res) => {
    try {
        const updatedRole = await Roles.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedRole) return res.status(404).send({ status: false, message: "Role not found" });
        res.status(200).send({ status: true, message: "Role updated successfully", data: updatedRole });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error updating role", error: error.message });
    }
};

exports.deleteRole = async (req, res) => {
    try {
        const deletedRole = await Roles.findByIdAndDelete(req.params.id);
        if (!deletedRole) return res.status(404).send({ status: false, message: "Role not found" });
        res.status(200).send({ status: true, message: "Role deleted successfully", data: deletedRole });
    } catch (error) {
        res.status(500).send({ status: false, message: "Error deleting role", error: error.message });
    }
};
