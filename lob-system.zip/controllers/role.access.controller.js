const Access = require('../models/role.access.model');

exports.create = async (req, res) => {
  try {
    const { role_id, resource, method, can_access } = req.body;
    const newAccess = new Access({ role_id, resource, method, can_access });
    await newAccess.save();
    res.redirect('/access');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// List
exports.list = async (req, res) => {
  try {
    const accessList = await Access.find().populate('role_id');
    res.render('access-list', { accessList });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Edit Form
exports.editForm = async (req, res) => {
  try {
    const access = await Access.findById(req.params.id).populate('role_id');
    res.render('access-edit', { access });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Update
exports.update = async (req, res) => {
  try {
    const { role_id, resource, method, can_access } = req.body;
    await Access.findByIdAndUpdate(req.params.id, { role_id, resource, method, can_access });
    res.redirect('/access');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Delete
exports.delete = async (req, res) => {
  try {
    await Access.findByIdAndDelete(req.params.id);
    res.redirect('/access');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};
