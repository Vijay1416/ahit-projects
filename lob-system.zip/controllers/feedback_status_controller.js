const feedbackStatus = require("../models/feedback_status_model");

// CREATE: Add a new feedback status
exports.createFeedbackStatus = async (req, res) => {
    const { feedback_status, status } = req.body;

    if (!feedback_status) {
        return res.status(400).json({ status: 'error', message: 'Feedback status is required' });
    }

    try {
        const existingFeedbackStatus = await feedbackStatus.findOne({ feedback_status });
        if (existingFeedbackStatus) {
            return res.status(400).json({ status: 'error', message: 'Feedback status already exists' });
        }

        const newFeedbackStatus = new feedbackStatus({ feedback_status, status });
        await newFeedbackStatus.save();

        res.status(201).json({ status: 'success', message: 'Feedback status created successfully', data: newFeedbackStatus });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
};

// READ: Get all feedback statuses
exports.getAllFeedbackStatuses = async (req, res) => {
    try {
        const feedbackStatuses = await feedbackStatus.find();
        res.status(200).json({ status: 'success', data: feedbackStatuses });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching feedback statuses: ' + err.message });
    }
};

// READ: Get a single feedback status by ID
exports.getFeedbackStatusById = async (req, res) => {
    try {
        const FeedbackStatus = await feedbackStatus.findById(req.params.id);
        if (!FeedbackStatus) {
            return res.status(404).json({ status: 'error', message: 'Feedback status not found' });
        }
        res.status(200).json({ status: 'success', data: FeedbackStatus });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching feedback status: ' + err.message });
    }
};

// UPDATE: Update a feedback status by ID
exports.updateFeedbackStatus = async (req, res) => {
    const { feedback_status, status } = req.body;

    if (!feedback_status) {
        return res.status(400).json({ status: 'error', message: 'Feedback status is required' });
    }

    try {
        const updatedFeedbackStatus = await feedbackStatus.findByIdAndUpdate(
            req.params.id,
            { feedback_status, status },
            { new: true, runValidators: true }
        );

        if (!updatedFeedbackStatus) {
            return res.status(404).json({ status: 'error', message: 'Feedback status not found' });
        }

        res.status(200).json({ status: 'success', message: 'Feedback status updated successfully', data: updatedFeedbackStatus });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error updating feedback status: ' + err.message });
    }
};

// DELETE: Delete a feedback status by ID
exports.deleteFeedbackStatus = async (req, res) => {
    try {
        const deletedFeedbackStatus = await feedbackStatus.findByIdAndDelete(req.params.id);
        if (!deletedFeedbackStatus) {
            return res.status(404).json({ status: 'error', message: 'Feedback status not found' });
        }
        res.status(200).json({ status: 'success', message: 'Feedback status deleted successfully' });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error deleting feedback status: ' + err.message });
    }
};
