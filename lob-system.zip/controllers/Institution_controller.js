const Institution = require("../models/Institution_model");

// CREATE: Add a new institution
exports.createInstitution = async (req, res) => {
    const { institution_name } = req.body;

    if (!institution_name) {
        return res.status(400).json({ status: 'error', message: 'Institution name is required' });
    }

    try {
        const existingInstitution = await Institution.findOne({ institution_name });
        if (existingInstitution) {
            return res.status(400).json({ status: 'error', message: 'Institution already exists' });
        }

        const newInstitution = new Institution({ institution_name });
        await newInstitution.save();

        res.status(201).json({ status: 'success', message: 'Institution created successfully', data: newInstitution });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
};

// READ: Get all institutions
exports.getAllInstitutions = async (req, res) => {
    try {
        const institutions = await Institution.find();
        res.status(200).json({ status: 'success', data: institutions });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching institutions: ' + err.message });
    }
};

// READ: Get a single institution by ID
exports.getInstitutionById = async (req, res) => {
    try {
        const institution = await Institution.findById(req.params.id);
        if (!institution) {
            return res.status(404).json({ status: 'error', message: 'Institution not found' });
        }
        res.status(200).json({ status: 'success', data: institution });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching institution: ' + err.message });
    }
};

// UPDATE: Update an institution by ID
exports.updateInstitution = async (req, res) => {
    const { institution_name, type } = req.body;

    if (!institution_name) {
        return res.status(400).json({ status: 'error', message: 'Institution name is required' });
    }

    try {
        const updatedInstitution = await Institution.findByIdAndUpdate(
            req.params.id,
            { institution_name, type },
            { new: true, runValidators: true }
        );

        if (!updatedInstitution) {
            return res.status(404).json({ status: 'error', message: 'Institution not found' });
        }

        res.status(200).json({ status: 'success', message: 'Institution updated successfully', data: updatedInstitution });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error updating institution: ' + err.message });
    }
};

// DELETE: Delete an institution by ID
exports.deleteInstitution = async (req, res) => {
    try {
        const deletedInstitution = await Institution.findByIdAndDelete(req.params.id);
        if (!deletedInstitution) {
            return res.status(404).json({ status: 'error', message: 'Institution not found' });
        }
        res.status(200).json({ status: 'success', message: 'Institution deleted successfully' });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error deleting institution: ' + err.message });
    }
};
