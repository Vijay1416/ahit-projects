const Stream = require("../models/Stream_model");

exports.createStream = async (req, res) => {
    const { stream_name, type } = req.body;

    if (!stream_name) {
        return res.status(400).json({ status: 'error', message: 'Stream name is required' });
    }

    try {
        const existingStream = await Stream.findOne({ stream_name });
        if (existingStream) {
            return res.status(400).json({ status: 'error', message: 'Stream already exists' });
        }

        const newStream = new Stream({ stream_name, type });
        await newStream.save();

        res.status(201).json({ status: 'success', message: 'Stream created successfully', data: newStream });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
};

exports.getAllStreams = async (req, res) => {
    try {
        const streams = await Stream.find();
        res.status(200).json({ status: 'success', data: streams });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching streams: ' + err.message });
    }
};

exports.getStreamById = async (req, res) => {
    try {
        const streamData = await Stream.findById(req.params.id);
        if (!streamData) {
            return res.status(404).json({ status: 'error', message: 'Stream not found' });
        }
        res.status(200).json({ status: 'success', data: streamData });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching stream: ' + err.message });
    }
};

exports.updateStream = async (req, res) => {
    const { stream_name, type } = req.body;

    if (!stream_name) {
        return res.status(400).json({ status: 'error', message: 'Stream name is required' });
    }

    try {
        const updatedStream = await Stream.findByIdAndUpdate(
            req.params.id,
            { stream_name, type },
            { new: true, runValidators: true }
        );

        if (!updatedStream) {
            return res.status(404).json({ status: 'error', message: 'Stream not found' });
        }

        res.status(200).json({ status: 'success', message: 'Stream updated successfully', data: updatedStream });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error updating stream: ' + err.message });
    }
};

exports.deleteStream = async (req, res) => {
    try {
        const deletedStream = await Stream.findByIdAndDelete(req.params.id);
        if (!deletedStream) {
            return res.status(404).json({ status: 'error', message: 'Stream not found' });
        }
        res.status(200).json({ status: 'success', message: 'Stream deleted successfully' });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error deleting stream: ' + err.message });
    }
};
