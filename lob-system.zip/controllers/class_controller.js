const Class = require("../models/class_model");

exports.createClass = async (req, res) => {
    const { class_name, type } = req.body;

    if (!class_name) {
        return res.status(400).json({ status: 'error', message: 'Class name is required' });
    }

    try {
        const existingClass = await Class.findOne({ class_name });
        if (existingClass) {
            return res.status(400).json({ status: 'error', message: 'Class already exists' });
        }

        const newClass = new Class({ class_name, type });
        await newClass.save();

        res.status(201).json({ status: 'success', message: 'Class created successfully', data: newClass });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
};

exports.getAllClasses = async (req, res) => {
    try {
        const classes = await Class.find();
        res.status(200).json({ status: 'success', data: classes });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching classes: ' + err.message });
    }
};

exports.getClassById = async (req, res) => {
    try {
        const classData = await Class.findById(req.params.id);
        if (!classData) {
            return res.status(404).json({ status: 'error', message: 'Class not found' });
        }
        res.status(200).json({ status: 'success', data: classData });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching class: ' + err.message });
    }
};

exports.updateClass = async (req, res) => {
    const { class_name, type } = req.body;

    if (!class_name) {
        return res.status(400).json({ status: 'error', message: 'Class name is required' });
    }

    try {
        const updatedClass = await Class.findByIdAndUpdate(
            req.params.id,
            { class_name, type },
            { new: true, runValidators: true }
        );

        if (!updatedClass) {
            return res.status(404).json({ status: 'error', message: 'Class not found' });
        }

        res.status(200).json({ status: 'success', message: 'Class updated successfully', data: updatedClass });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error updating class: ' + err.message });
    }
};

exports.deleteClass = async (req, res) => {
    try {
        const deletedClass = await Class.findByIdAndDelete(req.params.id);
        if (!deletedClass) {
            return res.status(404).json({ status: 'error', message: 'Class not found' });
        }
        res.status(200).json({ status: 'success', message: 'Class deleted successfully' });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error deleting class: ' + err.message });
    }
};
