const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user_model');
const { JSONWEBKEY } = process.env

exports.getUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json({ data: users });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });
        res.status(200).json({ data: user });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.createUser = async (req, res) => {
    try {
        let user = await User.findOne({ email: req.body.email, number: req.body.number });
        if (user) return res.redirect('/admin/dashboard/users?error=User already exists');
        await User.create([req.body], { writeConcern: { w: 0, j: true, wtimeout: 1000 } });
        res.redirect('/admin/dashboard/users')
    } catch (err) {
        res.redirect('/admin/dashboard/users?error=' + err.message)
    }
};

exports.updateUser = async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body);
        if (!user) return res.status(404).json({ error: 'User not found' });
        res.status(200).json({ status: ok });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Delete a user
exports.deleteUser = async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });

        res.status(200).json({ message: 'User deleted successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Apply dynamic fields
exports.applyDynamicFields = async (req, res) => {
    const { fieldName, fieldType } = req.body;

    try {
        userSchema.add({ [fieldName]: { type: fieldType, default: null } });
        await User.syncIndexes();
        res.status(200).json({ message: 'Dynamic field added successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

//login
exports.login = async (req, res) => {
    let { email, number, password } = req.body
    try {
        const user = await User.findOne({ $or: [{ email }, { number }] })
        if (!user) {
            res.status(404)
            return res.render('login', { data: { error: 'Login failed. Please check your credentials!' } })
        }

        if (!await bcrypt.compare(password, user.password)) {
            res.status(401)
            return res.render('login', { data: { error: 'Login failed. Please check your credentials!' } });
        }
        req.session.token = jwt.sign({ userId: user._id, Date: Date.now() }, `${JSONWEBKEY}`)
        res.cookie('__token', req.session.token, { maxAge: 1000 * 60 * 60 * 24, httpOnly: true });
        res.redirect('/admin/dashboard/home')
    } catch (error) {
        res.render('login', { data: { error: error.message } })
    }
}
exports.logout = async (req, res) => {
    try {
        console.log('data s')
        await req.session.destroy()
        res.clearCookie('User');
        res.clearCookie('__token');
        return res.status(200).send({ success: true, message: 'Logged out successfully' });
    } catch (error) {
        console.error('Error during logout:', error);
        res.status(500).send({ success: false, message: 'An error occurred during logout' });
    }
}