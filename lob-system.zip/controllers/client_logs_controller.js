const clientLog = require("../models/client_logs_model")

exports.client_logs = async(req,res)=>{
    const {id} = req.params
    if(!id) return res.status(400).send({success:false,message:'Please Enter MongoDb Id !'})
    try {
        const logs = await clientLog.find({client_id:id}).sort({date:1})
        if(!logs || logs.length == 0) return res.status(404).send({success:false,message:'data not foun!'})
        console.log(logs)
    res.send({success:true,data:logs})
    } catch (error) {
        res.status(400).send({success:false,message:error.message})
    }
}