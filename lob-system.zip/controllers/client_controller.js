const Client = require('../models/client_model');
const fs = require('fs');
const csvParser = require('csv-parser');
const xlsx = require('xlsx');
const path = require('path')
const moment = require('moment-timezone');
const clientLog = require('../models/client_logs_model');
const { Parser } = require('json2csv');

var dateTimeUtil = {
    timeZone: moment.tz("Asia/Kolkata"),

    Date: function () {
        return this.timeZone.format('L');
    },

    Time: function () {
        return this.timeZone.format('LT');;
    }
};

exports.client_list = async (req, res) => {
    try {
        const client = await Client.find();
        res.status(200).json({ data: client });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.client_byId = async (req, res) => {
    try {
        const clinetcheck = await Client.findById(req.params.id);
        if (!clinetcheck) return res.status(404).json({ error: 'client not found' });
        res.status(200).json({ data: clinetcheck });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.create_client = async (req, res) => {
    try {
        req.body.date = dateTimeUtil.Date();
        req.body.time = dateTimeUtil.Time();
        await Client.create({ userId: req.body.createBy, ...req.body })
        res.redirect('/admin/dashboard/datatable')
    } catch (err) {
        console.log(err)
        res.redirect(`/admin/dashboard/datatable?error=${err.message}`)
    }
};

exports.update_client = async (req, res) => {
    const User = req.cookies['User']
    try {
        req.body.time = dateTimeUtil.Time();
        req.body.date = dateTimeUtil.Date();
        const Clients = await Client.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!Clients) return res.status(404).json({ error: 'Client not found' });
        let update_logs = new clientLog({
            user_id: User?._id,
            client_id: Clients?._id,
            updatedTime: Clients?.time,
            updatedDate: Clients?.date,
        })
        await update_logs.save()
        res.status(200).send({ success: true, message: "updateSuccess!" })
    } catch (err) {
        res.status(400).send({ success: false, message: err.message })
    }
};

// Delete a user
exports.delete_client = async (req, res) => {
    try {
        const client = await Client.findByIdAndDelete(req.params.id);
        if (!client) return res.status(404).json({ error: 'Client not found' });

        res.status(200).json({ message: 'Client  deleted successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Apply dynamic fields
exports.applyDynamicFields = async (req, res) => {
    const { fieldName, fieldType } = req.body;
    try {
        userSchema.add({ [fieldName]: { type: fieldType, default: null } });
        await User.syncIndexes();
        res.status(200).json({ message: 'Dynamic field added successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};


exports.uploadAndInsertData = async (req, res) => {
    const file = req.file;
    const userId = req.body['alocaket'];
    const createBy = req.body.createBy

    if (!file) {
        return res.redirect("/admin/dashboard/datatable?error=file is required!");
    }

    const userIdArray = userId ? (Array.isArray(userId) ? userId : [userId]) : [];

    if (userIdArray.length === 0) {
        return res.status(400).json({ message: 'No users selected' });
    }

    try {
        const fileType = file.mimetype;

        if (fileType === 'text/csv' || fileType === 'application/csv') {
            const results = [];
            const successData = [];
            const errorData = [];
            const filePath = path.join(__dirname, '../', file.path);
            if (!fs.existsSync(filePath)) {
                return res.redirect("/admin/dashboard/datatable?error=File not found");
            }

            fs.createReadStream(filePath)
                .pipe(csvParser())
                .on('data', (data) => {
                    const mappedData = {
                        date: dateTimeUtil.Date(),
                        time: dateTimeUtil.Time(),
                        village: data['Village'] || data['VILLAGE'],
                        student_name: data['Student Name'] || data['STUDENT NAME'],
                        father_name: data['Father Name'] || data['FATHER NAME'],
                        number: data['Mobile'] || data['MOBILE'] || data['Contact No.']||data['Mobile Number'],
                        second_number: data['Second Number'] || data['SECOND NUMBER'],
                        feedback_status: data['Feedback Status'] || data['FEEDBACK STATUS'],
                        class: data['Class'] || data['CLASS'],
                        stream: data['Stream/Subject']||data['Stream'],
                        Second_Fup_Date: data['Second Fup Date'] || data['SECOND FUP DATE']||data['Second Follow-Up Date'],
                        institution_name: data['Institution Name'] || data['INSTITUTION NAME'],
                        notes: data['Notes'] || data['NOTES'],
                        added_to_broadcast: data['Added to Broadcast'] || data['ADDED TO BROADCAST'],
                        alocaket: userIdArray,
                        userId: createBy
                    };
                    results.push(mappedData);
                })
                .on('end', async () => {
                    try {
                        for (const record of results) {
                            try {
                                await Client.create(record);
                                successData.push(record);
                            } catch (err) {
                                errorData.push({ record, error: err.message });
                            }
                        }
            
                        const successCount = successData.length;
                        const errorCount = errorData.length;
            
                        res.redirect(`/admin/dashboard/datatable?success=${successCount}&failed=${errorCount}`);
            
                        console.log('Failed records:', errorData);
                    } catch (err) {
                        console.log('Unexpected error:', err.stack);
                        res.redirect("/admin/dashboard/datatable?error=" + err.message);
                    } finally {
                        fs.unlinkSync(filePath);
                    }
                });
        } else if (fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
            fileType === 'application/vnd.ms-excel') {
            const filePath = path.join(__dirname, '../', file.path);
            if (!fs.existsSync(filePath)) {
                return res.redirect("/admin/dashboard/datatable?error=File not found");
            }

            const workbook = xlsx.readFile(filePath);
            const worksheet = workbook.Sheets[workbook.SheetNames[0]];
            const data = xlsx.utils.sheet_to_json(worksheet);

            const dataWithUserIds = data.map(item => ({
                date: dateTimeUtil.Date(),
                time: dateTimeUtil.Time(),
                village: data['Village'] || data['VILLAGE'],
                student_name: data['Student Name'] || data['STUDENT NAME'],
                father_name: data['Father Name'] || data['FATHER NAME'],
                number: data['Mobile'] || data['MOBILE'] || data['Contact No.']||data['Mobile Number'],
                second_number: data['Second Number'] || data['SECOND NUMBER'],
                feedback_status: data['Feedback Status'] || data['FEEDBACK STATUS'],
                class: data['Class'] || data['CLASS'],
                stream: data['Stream/Subject']||data['Stream'],
                Second_Fup_Date: data['Second Fup Date'] || data['SECOND FUP DATE']||data['Second Follow-Up Date'],
                institution_name: data['Institution Name'] || data['INSTITUTION NAME'],
                notes: data['Notes'] || data['NOTES'],
                added_to_broadcast: data['Added to Broadcast'] || data['ADDED TO BROADCAST'],
                alocaket: userIdArray,
                userId: createBy
            }));

            await Client.insertMany(dataWithUserIds);
            res.redirect("/admin/dashboard/datatable");

            fs.unlinkSync(filePath);
        } else {
            return res.redirect("/admin/dashboard/datatable?error=Unsupported file type. Please upload a CSV or Excel file.");
        }
    } catch (err) {
        console.log('error-- > ' , err.stack)
        res.redirect("/admin/dashboard/datatable?error=" + err.message);
    }
};

exports.client_filter = async (req, res) => {
    let filterObj = {};
    try {

        const query = req.query;

        if (query.startDate && query.endDate) {
            filterObj.createdAt = { $gte: new Date(query.startDate), $lte: new Date(query.endDate) };
        }
        if(query.startDate){
            filterObj.createdAt = { $gte: new Date(query.startDate)}
        }

        let sortObj = {};

        if (query.sortBy) {
            const sortFields = query.sortBy.split(',');
            sortFields.forEach(field => {
                const [key, order] = field.split(':');
                sortObj[key] = order === 'desc' ? -1 : 1;
            });
        }

      const clients = await Client.find(filterObj).sort(sortObj);
    } catch (error) {
        res.status(400).send({ success: false, message: error.message })
    }
}

exports.clientCsvDownload = async(req,res)=>{
    try {
        const { userId, startDate, endDate } = req.query;

        let filter = {};

        if (userId) {
            filter.alocaket = userId;
        }
        
        if (startDate && endDate) {
            filter.date = {
                $gte: startDate,
                $lte: endDate
            };
        }else{
           return res.status(400).send({status:false,message: 'start date or end date id not selected!'})
        }

        const clients = await Client.find(filter)
        .populate('userId', 'name')
        .populate('client_type', 'client_type')
        .populate('alocaket', 'name')
        .exec();
        if(!clients||clients.length == 0) return res.status(404).send({status:false,message:'Data Not Found!'})
        const fields = [
            { label: 'Student Name', value: 'student_name' },
            { label: 'Father Name', value: 'father_name' },
            { label: 'Mobile Number', value: 'number' },
            { label: 'Second Number', value: 'second_number' },
            { label: 'Village', value: 'village' },
            { label: 'Stream', value: 'stream' },
            { label: 'Feedback Status', value: 'feedback_status' },
            { label: 'Client Type', value: 'client_type.client_type' },
            { label: 'Second Follow-Up Date', value: 'Second_Fup_Date' },
            { label: 'Institution Name', value: 'institution_name' },
            { label: 'Notes', value: 'notes' },
            { label: 'Added to Broadcast', value: 'added_to_broadcast' },
            { label: 'Class', value: 'class' },
            { label: 'Date', value: 'date' },
            { label: 'Time', value: 'time' },
            { label: 'CreatedBy', value: 'userId.name' },
            { 
                label: 'Allocated', 
                value: (row) => row.alocaket.map(user => user.name).join(',')
            },
        ];

        const json2csvParser = new Parser({ fields });

        const csv = json2csvParser.parse(clients);

        const fileName = `clients_${Date.now()}.csv`;

        const filePath = path.join(__dirname, '../', 'uploads', fileName);

        fs.writeFileSync(filePath, csv);

        res.download(filePath, fileName, (err) => {
            if (err) {
                console.error('Error downloading the file:', err);
                res.status(400).send({status:false,error:err.message,data:'Error downloading the file'});
            }
            fs.unlinkSync(filePath);
        });
    } catch (err) {
        console.error('Error generating CSV:', err);
        res.status(400).send({status:false,error:err.message,data:'Error downloading the file'});
    }
}
