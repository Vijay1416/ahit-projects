const venture = require("../models/ventures_model")

exports.ventureCreates = async (req, res) => {
    try {
        const checkVentures = await venture.findOne({ name: req.body.name })
        if (checkVentures) return res.redirect('/admin/dashboard/ventures?error=Venture name alredy exist!')
        await venture.create(req.body)
        return res.redirect('/admin/dashboard/ventures')
    } catch (error) {
        return res.redirect('/admin/dashboard/ventures?error=' + error.message)
    }
}
exports.updateVenture = async (req, res) => {
    const id = req.params.id;
    try {
        const updatedData = await venture.findByIdAndUpdate(id, req.body, { new: true });
        if (!updatedData) return res.status(404).send({ status: false, message: 'data not found!' })
        return res.status(200).send({ status: true, data: updatedData });
    } catch (error) {
        res.status(400).send({ data: error.message })
    }
}
exports.deleteVenture = async (req, res) => {
  try {
    const id = req.params.id
    const findToDelete = await venture.findByIdAndDelete(id)
    if (!findToDelete) return res.status(404).send({ data: null })
    res.status(200).send({ status: true, data: findToDelete })
  } catch (error) {
    res.status(400).send({ status: false, message: error.message })
  }
}
exports.findAllVenture = async (req, res) => {
    try {
        let { name } = req.query
        const AllData = await venture.find({}).sort({ name: 1 })
        if (!AllData) return res.status(404).send({ data: null })
        res.status(200).send({ status: true, data: AllData })
    } catch (error) {
        res.status(400).send({ status: false, message: error.message })
    }
}
