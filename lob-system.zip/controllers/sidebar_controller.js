const Menu = require('../models/sidebar_model');

// Get all menus
exports.getAllMenus = async (req, res) => {
    try {
        const menus = await Menu.find();
        res.render('menu/index', { menus });
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// Render form for creating a new menu
exports.renderNewMenuForm = (req, res) => {
    res.render('menu/new');
};

// Create a new menu
exports.createMenu = async (req, res) => {
    try {
        let {startIn} =   await Menu.findOne({},{startIn:1,_id:0}).sort({startIn:-1})
            
        const { text, href, icon, roles, submenus } = req.body;
        const newMenu = new Menu({
            text,
            href,
            icon,
            roles: roles ? roles.split(',') : [],
            submenus: submenus ? JSON.parse(submenus) : [],
            startIn: ++startIn
        });
        await newMenu.save();
        res.redirect('/menu');
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// Render form for editing a menu
exports.renderEditMenuForm = async (req, res) => {
    try {
        const menu = await Menu.findById(req.params.id);
        if (!menu) {
            return res.status(404).send('Menu not found');
        }
        res.render('menu/edit', { menu });
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// Update a menu
exports.updateMenu = async (req, res) => {
    try {
        const { text, href, icon, roles, submenus } = req.body;
        await Menu.findByIdAndUpdate(req.params.id, {
            text,
            href,
            icon,
            roles: roles ? roles.split(',') : [],
            submenus: submenus ? JSON.parse(submenus) : []
        });
        res.redirect('/menu');
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// Delete a menu
exports.deleteMenu = async (req, res) => {
    try {
        await Menu.findByIdAndDelete(req.params.id);
        res.redirect('/menu');
    } catch (err) {
        res.status(500).send(err.message);
    }
};
