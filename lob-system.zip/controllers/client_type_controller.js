const ClientType = require("../models/client_type_model");

// CREATE: Add a new client type
exports.createClientType = async (req, res) => {
    let { client_type, color } = req.body;
    client_type = client_type.trim();
    if (!client_type || !color) {
        return res.redirect('/admin/dashboard/color?error=Client Type Or Color Is Required!')
    }

    try {
        const existingClientType = await ClientType.findOne({ client_type });
        if (existingClientType) {
            return res.redirect('/admin/dashboard/colors?error=Client type already exists!');
        }

        const newClientType = new ClientType({ client_type, color });
        await newClientType.save();

        res.redirect('/admin/dashboard/colors');
    } catch (err) {
        console.log(err.stack)
        res.redirect('/admin/dashboard/colors?error=' + err.message)
    }
};

// READ: Get all client types
exports.getAllClientTypes = async (req, res) => {
    try {
        const clientTypes = await ClientType.find();
        res.status(200).json({ status: 'success', data: clientTypes });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching client types: ' + err.message });
    }
};

// READ: Get a single client type by ID
exports.getClientTypeById = async (req, res) => {
    try {
        const clientTypeData = await ClientType.findById(req.params.id);
        if (!clientTypeData) {
            return res.status(404).json({ status: 'error', message: 'Client type not found' });
        }
        res.status(200).json({ status: 'success', data: clientTypeData });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error fetching client type: ' + err.message });
    }
};

// UPDATE: Update a client type by ID
exports.updateClientType = async (req, res) => {
    const { client_type, color } = req.body;

    if (!client_type) {
        return res.status(400).json({ status: 'error', message: 'Client type is required' });
    }

    try {
        const updatedClientType = await ClientType.findByIdAndUpdate(
            req.params.id,
            { client_type, color },
            { new: true, runValidators: true }
        );

        if (!updatedClientType) {
            return res.status(404).json({ status: 'error', message: 'Client type not found' });
        }

        res.status(200).json({ status: 'success', message: 'Client type updated successfully' });
    } catch (err) {
        console.log(err.stack)
        res.status(400).json({ status: 'error', message: 'Error updating client type: ' + err.message });
    }
};

// DELETE: Delete a client type by ID
exports.deleteClientType = async (req, res) => {
    try {
        const deletedClientType = await ClientType.findByIdAndDelete(req.params.id);
        if (!deletedClientType) {
            return res.status(404).json({ status: 'error', message: 'Client type not found' });
        }
        res.status(200).json({ status: 'success', message: 'Client type deleted successfully' });
    } catch (err) {
        res.status(500).json({ status: 'error', message: 'Error deleting client type: ' + err.message });
    }
};
