const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    feedback_status:{type:String,required:true},
    status:{type:Boolean,default:true},
},{timestamps:true})
const feedbackStatus = mongoose.model('feedback_status',Schema)
module.exports = feedbackStatus