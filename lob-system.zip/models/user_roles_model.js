const mongoose = require("mongoose");

const roleSchema = new mongoose.Schema({
    role_name: { type: String, required: true , unique:[true,"Role Name Is Unique!"] },
    status: { type: Boolean, default: true },
}, { timestamps: true });

const Roles = mongoose.model('roles', roleSchema);
module.exports = Roles;
