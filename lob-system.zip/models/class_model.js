const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    class_name:{type:String,required:true},
    type:{type:String,required:false},
},{timestamps:true})
const Class = mongoose.model('class',Schema)
module.exports = Class