const mongoose = require('mongoose');

const submenuSchema = new mongoose.Schema({
    text: { type: String, required: true },
    href: { type: String, required: true },
    icon: { type: String },
    roles: [String], 
    submenus: [this] 
}, { _id: false });

const menuSchema = new mongoose.Schema({
    text: { type: String, required: true ,unique:true},
    href: { type: String },
    icon: { type: String },
    roles: [String],
    submenus: [submenuSchema],
    startIn:{type:Number}
});

const Menu = mongoose.model('sidebare_menu', menuSchema);

module.exports = Menu;
