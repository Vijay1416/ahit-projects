const mongoose = require('mongoose');

const accessSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  permissions: [
    {
      permission_name:String,
      permission_value:[Number],
    }
  ],
}, { timestamps: true });

const Access = mongoose.model('role_access', accessSchema);
module.exports = Access;
