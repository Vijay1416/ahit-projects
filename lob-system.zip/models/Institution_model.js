const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    institution_name:{type:String,required:true},
    type:{type:String,required:false},
},{timestamps:true})
const Institution = mongoose.model('Institution',Schema)
module.exports = Institution