const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    name:{type:String,required:true},
    type:{type:String,required:false},
    status:{type:String,default:true},
},{timestamps:true})
const venture = mongoose.model('venture',Schema)
module.exports = venture
