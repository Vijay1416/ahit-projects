const { Schema, model } = require('mongoose');

const logSchema = new Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    client_id: { type: Schema.Types.ObjectId, ref: 'client', required: true },
    // updatedfields: [{ type: String, required: true }],
    updatedTime: { type: String },
    updatedDate: { type: String },
})

const clientLog = model('client_log',logSchema)
module.exports = clientLog
