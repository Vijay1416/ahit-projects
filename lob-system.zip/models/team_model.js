const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    name:{type:String,required:true , unique:[true,"Team Name Is Qnique!"]},
    type:{type:String,required:false},
    vId:{type:mongoose.Schema.Types.ObjectId,ref:'venture'}
},{timestamps:true})
const teams = mongoose.model('team',Schema)
module.exports = teams