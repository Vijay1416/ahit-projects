const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
   client_type:{type:String,required:true},
   color:{type:String,required:true},
   status:{type:Boolean,default:true},
},{timestamps:true})
const ClientType = mongoose.model('client_type',Schema)
module.exports = ClientType