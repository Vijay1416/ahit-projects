const { Schema, model } = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const clientSchema = new Schema({
    student_name: { type: String, required: true },
    father_name: { type: String, required: false },
    number: { type: String, required: true },
    second_number: { type: String, required: false },
    email: {
        type: String, unique: false, trime: true, validate: {
            validator: function (v) {
                return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
            },
            message: "Please enter a valid email"
        }, required: false
    },
    village: { type: String, required: false },
    stream: { type: String, required: false },
    client_type: { type: Schema.Types.ObjectId,ref:'client_type', required: false },
    Second_Fup_Date: { type: String, required: false },
    institution_name: { type: String, required: false },
    notes: { type: String, required: false },
    added_to_broadcast: { type: String, required: false },
    class: { type: String, required: false },
    date: { type: String, required: false },
    time: { type: String, required: false },
    feedback_status: { type: String, required: false },
    is_delete: { type: Boolean, default: 0 },
    token: { type: String, required: false },
    status: { type: Boolean, default: false },
    alocaket:[{type:Schema.Types.ObjectId,ref:'User'}],
    userId:{type:Schema.Types.ObjectId,ref:'User'}, 
},{timestamps:true})

// clientSchema.pre('save', function (next) {
//     var isUser = this;
//     bcrypt.genSalt(10, function (err, salt) {
//         if(err)return err;
//         bcrypt.hash(isUser.password, salt, function (err, hash) {
//             if(err)return err;
//             isUser.password = hash
//             console.log(hash);
//             next()
//         })
//     })
// }).0

const Client = model('client',clientSchema)

const applyDynamicFields = async () => {
    userSchema.add({ [field.fieldName]: { type: fieldType, default: null } });
    User = model("User", userSchema);
};

module.exports = Client