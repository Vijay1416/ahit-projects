const { Schema, model } = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const userSchema = new Schema({
    name: { type: String, required: true },
    number: { type: String, required: true },
    email: {
        type: String, unique: true, trime: true, validate: {
            validator: function (v) {
                return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
            },
            message: "Please enter a valid email"
        }, required: true
    },
    password: { type: String, required: true },
    image: { type: String, required: false },
    is_delete: { type: Boolean, default: 0 },
    token: { type: String, required: false },
    // isVerify:{type:Boolean,default:false},
    status: { type: Boolean, default: false },
    user_role:{type:Schema.Types.ObjectId,ref:'roles'},
    team_id:{type:Schema.Types.ObjectId,ref:'team'}
})

userSchema.pre('save', function (next) {
    var isUser = this;
    bcrypt.genSalt(10, function (err, salt) {
        if(err)return err;
        bcrypt.hash(isUser.password, salt, function (err, hash) {
            if(err)return err;
            isUser.password = hash
            console.log(hash);
            next()
        })
    })
})
userSchema.methods.getSignedJwtToken = function(){
    return jwt.sign({ id: this._id}, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE
    })
}

const User = model('User',userSchema)

const applyDynamicFields = async () => {
    userSchema.add({ [field.fieldName]: { type: fieldType, default: null } });
    User = model("User", userSchema);
};

module.exports = User