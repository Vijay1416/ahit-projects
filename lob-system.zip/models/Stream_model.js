const mongoose= require("mongoose");

const Schema = new mongoose.Schema({
    stream_name:{type:String,required:true},
    type:{type:String,required:false},
},{timestamps:true})
const Stream = mongoose.model('Stream',Schema)
module.exports = Stream