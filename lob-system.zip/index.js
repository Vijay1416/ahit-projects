const express = require('express')
const database = require('./config/db')
var createError = require('http-errors');
var cookieParser = require('cookie-parser');
const session = require('express-session')
var logger = require('morgan')
var path = require('path');
const ejs = require('ejs')
const Router = require('./routers/Router');
const cors = require('cors')
const views_router = require('./routers/ejs_router');

const app = express()
const port = process.env.PORT || 8080

//middleware
// app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cors())
app.use(session({
    secret: 'WWE01EFGE09#NE',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 1000 * 60 * 60 * 24 }
}))
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));


//MongoDb Connection
database()

//env setup
const env = require('dotenv');
env.config()

//Routers
// app.use('/',(req,res)=>res.send('Api Runs'))
app.use('/api', Router)
app.use('/admin/dashboard', views_router)
app.get('/', (req, res) => {
    res.redirect('/admin/dashboard/home')
})
app.use(express.static(path.join(__dirname, 'uploads')));


app.listen(port, () => console.log('http://localhost:' + port))