const editLinks = document.querySelectorAll('.edit-action');
editLinks.forEach(link => {
    link.addEventListener('click', function () {
        const ventureId = this.getAttribute('data-id');
        const ventureName = this.getAttribute('data-name');
        console.log(ventureName);

        const modalInput = document.querySelector('#exampleModal .form-control');
        modalInput.value = ventureName;
        modalInput.setAttribute('data-id', ventureId);


        const updateForm = document.querySelector('#updateForm');
        updateForm.action = `/api/venture/update/${ventureId}`;
    });
});

document.querySelector('#updateForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const ventureId = document.querySelector('#ventureName').getAttribute('data-id');
    const updatedName = document.querySelector('#ventureName').value;

    fetch(`/api/venture/update/${ventureId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: updatedName })
    })
        .then(response => response.json())
        .then(data => {
            console.log('Update successful:', data);
            $('#exampleModal').modal('hide');
            alert("Venture Name Update Successfully!")
            window.location.reload()
        })
        .catch(error => {
            console.error('Error updating venture:', error);
        });
});

document.querySelectorAll('.delete-action').forEach(link => {
    link.addEventListener('click', function (event) {
        event.preventDefault();

        const ventureId = this.getAttribute('data-id');

        if (confirm('Are you sure you want to delete this venture?')) {
            fetch(`/api/venture/delete/${ventureId}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(data => {
                    console.log('Delete successful:', data);
                    alert("Venture Delete Successfully")
                    window.location.reload()
                })
                .catch(error => {
                    console.error('Error deleting venture:', error);
                });
        }
    });
});


// client deletes
function clientDelete(clientId) {
    if (confirm('Are you sure you want to delete this client?')) {
        fetch('/api/client/delete/' + clientId, {
        method: 'DELETE'
    })
        .then(response => response.json())
        .then(data => {
            console.log('Delete successful:', data);
            alert("Client Delete Successfully")
            window.location.reload()
        })
        .catch(error => {
            console.error('Error deleting venture:', error);
        });
    }
}


  