const urlParams = new URLSearchParams(window.location.search);
const errorMessage = urlParams.get('error');

if (errorMessage) {
    const errorDiv = document.getElementById('error-message');
    errorDiv.textContent = errorMessage;
    errorDiv.style.display = 'block';

    setTimeout(function () {
        errorDiv.style.display = 'none';

        const newUrl = window.location.origin + window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
    }, 4000);
}