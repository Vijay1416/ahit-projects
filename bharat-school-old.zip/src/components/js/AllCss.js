import '../css/aboutschool.css';
import '../css/animatedCard.css';
import '../css/article.css';
import '../css/banner.css';
import '../css/cardetail.css';
import '../css/counter.css';
import '../css/enquiry.css';
import '../css/error.css';
import '../css/filter.css';

import '../css/filterSchool.scss';
import '../css/filterschool.css';
import '../css/footer.css';
import '../css/gallery.scss';
import '../css/home.css';
import '../css/login.css';
import '../css/nav.css';
import '../css/newpass.css';
import '../css/news.css';
import '../css/notification.scss';

import '../css/profile.css';
import '../css/register.css';
import '../css/resetPass.css';
import '../css/schoolcard.css';
import '../css/schoolcarddetails.css';
import '../css/testimonial.css';
import '../css/todo.css';

import '../css/loading.css';
import '../css/recentArticleCraousel.css';
import '../css/newNav.css';
import '../css/simpleLoader.css';