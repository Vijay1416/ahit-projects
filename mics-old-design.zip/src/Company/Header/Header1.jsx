import React, { useState, useEffect, useContext } from 'react';
import './header1.css';
import micsLogo from '/src/assets/images/milogo.png';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import baseUrl from '../../js/api';
import axios from 'axios';


function Header1() {

    const [loginName, setLoginName] = useState('')
    const [menuOpen, setMenuOpen] = useState(false);
    const companyId = localStorage.getItem('companyId')
    const endpoint = `company/data/${companyId}`
    const navigate = useNavigate();
    const location = useLocation()

    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };

    const closeMenu = () => {
        setMenuOpen(false);
    };

    function loginCheck() {
        axios.get(baseUrl+endpoint).then((response)=>{
            setLoginName(response?.data?.data[0]?.companyName);
        })
    }
    function handelLogOut() {
        localStorage.clear()
        if (location.pathname === '/Company/HomePage') {
            window.location.reload()
        }
        navigate('/Company/HomePage')
    }

    useEffect(() => {
        const handleScroll = () => {
            const header = document.querySelector('.navbar-company');
            if (window.scrollY > 0) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }
        };

        window.addEventListener('scroll', handleScroll);
        loginCheck()
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    return (
        <>

            <header className={`navbar-company ${menuOpen ? 'open' : ''}`}>
                <NavLink to="/Company/HomePage" className="logo">
                    <img src={micsLogo} alt="logo" className="img-fluid logo-img" />
                </NavLink>
                <div className="menu-btn" onClick={toggleMenu}>
                    {menuOpen ? (
                        <div className="fs-1 text-danger fw-bold"><i className="bi bi-x-lg"></i></div>
                    ) : (
                        <div className="menu-btn__lines"></div>
                    )}
                </div>
                <ul className={`menu-items ${menuOpen ? 'open' : ''}`}>
                    <li>
                        <NavLink to="/Company/HomePage" className="menu-item first-item" onClick={closeMenu}>
                            Home
                        </NavLink>
                    </li>

                    <li>
                        <NavLink to="/recruit/hire-page" className="menu-item first-item">
                            Hiring
                        </NavLink>
                    </li>

                    <li>
                        <NavLink to="/company/contact-us" className="menu-item first-item">
                            Contact Us
                        </NavLink>
                    </li>

                   

                    {/* <li className='register-header'>
                        <NavLink to="/recruit/client-registration-form" className="menu-item first-item">
                            Register
                        </NavLink>
                    </li> */}

                    {
                        loginName ? (
                    <li className='ms-3'>
                                <div className="company-dropdown-profile">
                                    <i className="bi bi-person-circle company-user-profile"></i>
                                    <>
                                        <span className='company-user-title'>Hi, {loginName}</span>
                                        <div className="dropdown-options">
                                            <NavLink to='/company/profile'> <span className='option-title'>Profile</span> </NavLink>
                                            <span onClick={() => handelLogOut()} className='option-title'>Logout</span>
                                        </div>
                                    </>
                                </div>
                            </li>
                            
                        ) : (
                            <li className='ms-3'>
                                <div className="company-dropdown-profile">
                                    <i className="bi bi-person-circle company-user-profile"></i>
                                    <>
                                        <span className='company-user-title'>Hi, Hello</span>
                                        <div className="dropdown-options">
                                            <NavLink to='/recruit/login'> <span className='option-title'>Login</span> </NavLink>
                                            <NavLink to='/recruit/client-registration-form'> <span className='option-title'>Signup</span> </NavLink>
                                        </div>
                                    </>
                                </div>
                            </li>
                        )
                    }

                </ul>
            </header>

        </>
    );
}

export default Header1;