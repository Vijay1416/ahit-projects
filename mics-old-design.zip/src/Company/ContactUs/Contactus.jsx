import React, { useState } from 'react';
import './contactus.css';
import Header1 from '../Header/Header1';
import Footer from '../Footer/Footer';
import axios from 'axios';
import baseUrl from '../../js/api';

function Contactus() {
    const [contact, setContact] = useState({
        name: '',
        number: '',
        email: '',
        message: ''
    })
    function haldelChange(e) {
        const { name, value } = e.target
        setContact({
            ...contact,
            [name]: value
        })
    }
    function handelSubmit(e) {
        e.preventDefault();
        const endPoint = 'contant/create'
        axios.post(baseUrl + endPoint, contact).then((response) => {
            console.log(response.data.data);
            
        }).catch((error) => {
            console.log(error);
        })
    }
    return (
        <>
            <Header1 />
            <div className="container-fuild contact">
                <h2 className='Contactu-us-title'>Contact us</h2>
                <div className="content mt-4 mb-5">
                    <div className="left-side">
                        <div className="address details">
                            <i className="fas fa-map-marker-alt"></i>
                            <div className="topic">Address</div>
                            <div className="text-one">Gurukripa Enclave, Near IndusInd Bank, </div>
                            <div className="text-one">Besides Raas Mahal Hotel, </div>
                            <div className="text-one">Old Ramgadhmod Bus stand, </div>
                            <div className="text-two">Jaipur (302002).</div>
                        </div>
                        <div className="phone details">
                            <i className="fas fa-phone-alt"></i>
                            <div className="topic">Phone</div>
                            <a href="tel:+91-96640 83783"> <div className="text-one">+91-96640 83783</div> </a>
                            <a href="tel:+91-80057 79031"> <div className="text-two">+91-80057 79031</div> </a>
                        </div>
                        <div className="email details">
                            <i className="fas fa-envelope"></i>
                            <div className="topic">Email</div>
                            <a href="mailto:"><div className="text-one">info@a2groups.org</div></a>
                            {/* <div className="text-two">info.codinglab@gmail.com</div> */}
                        </div>
                    </div>
                    <div className="right-side">
                        <div className="topic-text">Send us a message</div>
                        <p>If you have any work from me or any types of quries related to my tutorial, you can send me message from here. It's my pleasure to help you.</p>
                        <form onSubmit={handelSubmit}>
                            <div className="input-box">
                                <input name='name' type="text" placeholder="Enter your name" value={contact.name} onChange={haldelChange} />
                            </div>
                            <div className="input-box">
                                <input name='email' type="email" placeholder="Enter your email" value={contact.email} onChange={haldelChange} />
                            </div>
                            <div className="input-box">
                                <input name='number' type="number" placeholder="Enter your number" value={contact.number} onChange={haldelChange} />
                            </div>
                            <div className="input-box message-box">
                                <textarea name="message" id="" placeholder="Enter your message" value={contact.message} onChange={haldelChange} />
                            </div>
                            <div className="button">
                                <input type="submit" value="Send Now" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Contactus;