import React, { useEffect, useState } from "react";
import "./hirepage.css";
import Header1 from "../Header/Header1";
import Footer from "../Footer/Footer";
import Select from 'react-select';
import makeAnimated from 'react-select/animated';
import JoditEditor from 'jodit-react';
import axios from "axios";
import baseUrl from "../../js/api";



function HirePage() {
  const [profile, setProfile] = useState({});
  const companyId = localStorage.getItem('companyId');
  const endpoint = `company/data/${companyId}`;

  useEffect(() => {
    const profileApi = async () => {
      try {
        const response = await axios.get(baseUrl + endpoint);
        setProfile(response.data.data[0]);
      } catch (error) {
        console.error("Error fetching profile data:", error);
      }
    };
    profileApi();
    window.scrollTo(0, 0);
  }, []);

  const initialValues = {
    jobTitle: "",
    openingJob: "",
    jobLocation: "",
    workType: "",
    experienceRequired: "",
    salary: {
      salaryFrom: "",
      salaryTo: "",
    },
    requiredSkill: [],
    responsibility: [],
    jobTiming: "",
    description: "",
    workingDay: "",
    jobRole: "",
    industryType: "",
    education: "",
    employmentType: "",
    keySkill: [],
    contactPersonName: "",
    companyPhone: "",
    personProfile: "",
    jobAddress: "",
    vacancy: "",
  };

  const [hireJob, setHireJob] = useState(initialValues);

  function handleInputField(e) {
    const { name, value } = e.target;
    if (name === "salaryFrom" || name === "salaryTo") {
      setHireJob(prevState => ({
        ...prevState,
        salary: {
          ...prevState.salary,
          [name]: value,
        },
      }));
    } else {
      setHireJob(prevState => ({
        ...prevState,
        [name]: value,
      }));
    }
  }

  function handleHiringJob(e) {
    e.preventDefault();
    const formData = new FormData();
    const keySkillArray = hireJob.keySkill.map(skill => skill.label);
    formData.append('who_post', companyId);
    formData.append('titel', hireJob.jobTitle);
    formData.append('required_skill', hireJob.requiredSkill);
    formData.append('description', hireJob.description);
    formData.append('skill', keySkillArray);
    formData.append('vacancy', hireJob.openingJob);
    formData.append('experience', hireJob.experienceRequired);
    formData.append('location', hireJob.jobLocation);
    formData.append('salary', `${hireJob.salary.salaryTo} to ${hireJob.salary.salaryFrom}`);
    formData.append('job_type', hireJob.workType);
    formData.append('employe', hireJob.employmentType);
    formData.append('role', hireJob.jobRole);
    formData.append('jobTime', hireJob.jobTiming);
    formData.append('graduation', hireJob.education);
    formData.append('duration', hireJob.jobTitle);
    formData.append('industryType', hireJob.industryType);
    formData.append('workingDay', hireJob.workingDay);
    formData.append('contactPersonName', hireJob.contactPersonName);
    formData.append('responsibility', hireJob.responsibility);
    formData.append('jobAddress', hireJob.jobAddress);
    formData.append('companyPhone', hireJob.companyPhone);

    const jobEndPoint = 'Company/post'
    axios.post(baseUrl + jobEndPoint, formData).then((response) => {
      localStorage.setItem('jobId',response.data.data._id)
      
    })
  }

  const animatedComponents = makeAnimated();

  const cityOptions = [
    { name: 'selected ' },
    { name: 'Jaipur' },
    { name: 'Delhi' },
    { name: 'Kanpur' },
    { name: 'Hyerabad' },
  ];

  const workTypeOptions = [
    { name: 'selected ' },
    { name: 'Work From Office' },
    { name: 'Work From Home' },
    { name: 'Hybrid' },
  ];

  const experienceOptions = [
    { name: 'selected ' },
    { name: '6 Months - 1 Year' },
    { name: '0 Year - 1 Year' },
    { name: '1 Year - 2 Year' },
    { name: '2 Year - 4 Year' },
    { name: '4 Year - 6 Year' },
    { name: '6 Year - 8 Year' },
    { name: '8 Year - 10 Year' },
  ];

  const jobTimeOptions = [
    { name: 'selected ' },
    { name: '9:00 AM - 06:00 PM' },
    { name: '9:30 AM - 06:30 PM' },
    { name: '10:00 AM - 07:00 PM' },
    { name: '10:30 AM - 07:30 PM' },
    { name: '11:00 AM - 08:00 PM' },
    { name: '11:30 AM - 08:30 PM' },
    { name: '12:00 PM - 09:00 PM' },
  ];

  const workingDayOptions = [
    { name: 'selected ' },
    { name: 'Monday to Friday (5 Day)' },
    { name: 'Monday to Saturday (6 Day)' },
  ];
  const keySkillOptions = [
    { value: 'React JS', label: 'React JS' },
    { value: 'Node JS', label: 'Node JS' },
    { value: 'Express JS', label: 'Express JS' },
    { value: 'Mongodb', label: 'Mongodb' },
    { value: 'HTML', label: 'HTML' },
    { value: 'CSS3', label: 'CSS3' },
    { value: 'Boostrap', label: 'Boostrap' },
    { value: 'RestAPI', label: 'RestAPI' },
    { value: 'SQL', label: 'SQL' },
    { value: 'MYSQL', label: 'MYSQL' },
    { value: 'Oracle', label: 'Oracle' }
    // Add other options as needed
  ];

  const roleDesignationOptions = [
    { name: 'Full Stack Developer' },
    { name: 'Flutter Developer' },
    { name: 'Java Developer' },
    { name: 'Python Developer' },
    { name: 'ReactJS Developer' },
    { name: 'NodeJS Developer' },
    { name: 'PHP Developer' },
    { name: 'Laravel Developer' },
  ]

  const industryTypeOptions = [
    { name: 'selected ' },
    { name: 'Account & Auditing' },
    { name: 'Advertising & Marketing' },
    { name: 'E-Learning / EdTech' },
    { name: 'IT Services & Consulting' },
    { name: 'Software Product' },
  ]

  const educationOptions = [
    { name: 'selected ' },
    { name: 'UG' },
    { name: 'PG' },
  ]

  const employmentTypeOptions = [
    { name: 'selected ' },
    { name: 'Full Time' },
    { name: 'Part Time' },
    { name: 'Permanent' },
  ];

  const personProfileOptions = [
    { name: 'selected ' },
    { name: 'HR/Owner' },
    { name: 'Owner/Partner' },
    { name: 'HR/Recruiter' },
    { name: 'Manager' },
  ]

  return (
    <>
      <Header1 />

      <div className="hire-bg p-2">
        <h2 className='jobhire-title'><u>Job Application and Hiring Form </u></h2>
        <div className="container">
          <div className="row">
            <div className="col-md-12">

              <form onSubmit={handleHiringJob}>

                <div className="box-border shadow">
                  <h5 className="text-primary">Basic Job Details</h5>
                  <label
                    htmlFor="job-title"
                    className="form-label mt-3 jb-del-label"
                  >
                    Job Title <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    id="job-title"
                    className="form-control jb-del-control"
                    placeholder="Eg: Web Designer"
                    name="jobTitle"
                    value={hireJob.jobTitle}
                    onChange={handleInputField}
                  />

                  <label
                    htmlFor="job-opening"
                    className="form-label mt-3 jb-del-label"
                  >
                    No. of Openings <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    id="job-opening"
                    className="form-control jb-del-control"
                    placeholder="Eg: 5"
                    name="openingJob"
                    value={hireJob.openingJob}
                    onChange={handleInputField}
                  />

                  <label
                    htmlFor="job-locatin"
                    className="form-label mt-3 jb-del-label"
                  >
                    Job Location <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="jobLocation"
                    value={hireJob.jobLocation}
                    onChange={handleInputField}
                  >
                    {cityOptions.map((city, index) => (
                      <option key={index} value={city.name}>{city.name}</option>
                    ))}
                  </select>


                  <label
                    htmlFor="job-work-type"
                    className="form-label mt-3 jb-del-label"
                  >
                    Work Type <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="workType"
                    value={hireJob.workType}
                    onChange={handleInputField}
                  >
                    {workTypeOptions.map((workType, index) => (
                      <option key={index} value={workType.name}>{workType.name}</option>
                    ))}
                  </select>

                  <label
                    htmlFor="job-experience"
                    className="form-label mt-3 jb-del-label"
                  >
                    Experience Requird <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="experienceRequired"
                    value={hireJob.experienceRequired}
                    onChange={handleInputField}
                  >
                    {experienceOptions.map((experience, index) => (
                      <option key={index} value={experience.name}>{experience.name}</option>
                    ))}
                  </select>

                </div>

                <div className="box-border shadow mt-5">
                  <h5 className="text-primary">Additional Job Details</h5>
                  <label className="form-label mt-3 jb-del-label">
                    Salary
                  </label>
                  <div className="d-flex">
                    <input
                      type="number"
                      className="form-control jb-del-control"
                      placeholder="Eg: 1,00,000"
                      name="salaryFrom"
                      value={hireJob.salary.salaryFrom}
                      onChange={handleInputField}
                    />
                    <span className="ms-2 mt-1">To</span>
                    <input
                      type="number"
                      className="form-control ms-2 jb-del-control"
                      placeholder="Eg: 1,50,000"
                      name="salaryTo"
                      value={hireJob.salary.salaryTo}
                      onChange={handleInputField}
                    />
                  </div>
                  <label className="form-label mt-5 jb-del-label fs-5 fw-bold">
                    Job Description <span className="text-danger"></span>
                  </label>
                  <div className="d-flex">
                    <textarea
                      type="text"
                      className="form-control ms-2 jb-del-control"
                      placeholder="Job Description"
                      name="description"
                      value={hireJob.description}
                      onChange={handleInputField}
                    />
                  </div>

                  <label className="form-label mt-1  jb-del-label">
                    Required Skill <span className="text-danger">*</span>
                  </label>

                  <JoditEditor
                    onChange={(content) => setHireJob({ ...hireJob, requiredSkill: content })}
                  />

                  <label className="form-label mt-5 jb-del-label">
                    Role & Responsibility <span className="text-danger">*</span>
                  </label>

                  <JoditEditor
                    onChange={(content) => setHireJob({ ...hireJob, responsibility: content })}
                  />

                  <label className="form-label mt-3 jb-del-label">
                    Job Timings <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="jobTiming"
                    value={hireJob.jobTiming}
                    onChange={handleInputField}
                  >
                    {jobTimeOptions.map((jobTiming, index) => (
                      <option key={index} value={jobTiming.name}>{jobTiming.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Working Days <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="workingDay"
                    value={hireJob.workingDay}
                    onChange={handleInputField}
                  >
                    {workTypeOptions.map((workingDay, index) => (
                      <option key={index} value={workingDay.name}>{workingDay.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Role <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="jobRole"
                    value={hireJob.jobRole}
                    onChange={handleInputField}
                  >
                    {roleDesignationOptions.map((role, index) => (
                      <option key={index} value={role.name}>{role.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Industry Type <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="industryType"
                    value={hireJob.industryType}
                    onChange={handleInputField}
                  >
                    {industryTypeOptions.map((industry, index) => (
                      <option key={index} value={industry.name}>{industry.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Education <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="education"
                    value={hireJob.education}
                    onChange={handleInputField}
                  >
                    {educationOptions.map((education, index) => (
                      <option key={index} value={education.name}>{education.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Employment Type <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="employmentType"
                    value={hireJob.employmentType}
                    onChange={handleInputField}
                  >
                    {employmentTypeOptions.map((employment, index) => (
                      <option key={index} value={employment.name}>{employment.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Key Skills <span className="text-danger">*</span>
                  </label>

                  <Select
                    closeMenuOnSelect={false}
                    components={animatedComponents}
                    isMulti
                    options={keySkillOptions}
                    value={hireJob.keySkill}
                    onChange={(selectedOption) => setHireJob({ ...hireJob, keySkill: selectedOption })}
                  />

                </div>

                <div className="box-border shadow mt-5">
                  <h5 className="text-primary">About Your Company</h5>
                  <label className="form-label mt-3 jb-del-label">
                    Company Name <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control jb-del-control"
                    placeholder={"Eg: " + profile?.companyName}
                    disabled
                    value={profile?.companyName}
                  />
                  <label className="form-label mt-3 jb-del-label">
                    Contact Person <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control jb-del-control"
                    placeholder="Eg: Person Name"
                    name="contactPersonName"
                    value={hireJob.contactPersonName}
                    onChange={handleInputField}
                  />
                  <label className="form-label mt-3 jb-del-label">
                    Email ID <span className="text-danger">*</span>
                  </label>
                  <input
                    type="tel"
                    className="form-control jb-del-control"
                    placeholder={"Eg: " + profile?.email}
                    disabled
                    value={profile?.email}
                  />
                  <label className="form-label mt-3 jb-del-label">
                    Phone Number <span className="text-danger">*</span>
                  </label>
                  <input
                    type="tel"
                    className="form-control jb-del-control"
                    placeholder="Eg: 9876543210"
                    name="companyPhone"
                    value={hireJob.companyPhone}
                    onChange={handleInputField}
                  />
                  <label className="form-label mt-3 jb-del-label">
                    Contact Person Profile <span className="text-danger">*</span>
                  </label>

                  <select
                    className="form-select jb-del-control"
                    name="personProfile"
                    value={hireJob.personProfile}
                    onChange={handleInputField}
                  >
                    {personProfileOptions.map((person, index) => (
                      <option key={index} value={person.name}>{person.name}</option>
                    ))}
                  </select>

                  <label className="form-label mt-3 jb-del-label">
                    Job Address <span className="text-danger">*</span>
                  </label>
                  <textarea
                    col="8"
                    rows="3"
                    className="form-control jb-del-control"
                    name="jobAddress"
                    value={hireJob.jobAddress}
                    onChange={handleInputField}
                  />
                </div>

                <div className="mb-3 form-check mt-5">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="exampleCheck1"
                  />
                  <label className="form-check-label" htmlFor="exampleCheck1">
                    I Accept Terms And Conditions and Privacy Policy.
                  </label>
                </div>
                <div>
                  <button type="submit" className="px-5 py-2 shadow rounded bg-success text-white border-0 mt-3">
                    Submit
                  </button>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default HirePage;
