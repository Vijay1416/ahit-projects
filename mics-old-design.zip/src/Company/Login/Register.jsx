import React, { useEffect, useState } from "react";
import './register.css';
import { NavLink, Navigate, useNavigate } from 'react-router-dom';
import Header1 from "../Header/Header1";
import Footer from "../Footer/Footer";
import axios from "axios";
import baseUrl from "../../js/api";



function Register() {
    const [responseMessage,setResponseMessage] = useState('')
    const Navigate = useNavigate()
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const initialValues = {
        fullname: "",
        email: "",
        phone: "",
        password: "",
        employees: "",
        CompanyName: "",
        industry: "",
        designation: "",
        address: "",
        pincode: "",
        profile:null
    };

    const [register, setRegister] = useState(initialValues);
    const [showPassword, setShowPassword] = useState(true);


    function handleInputField(e) {
        if (e.target.type === 'file') {
            setRegister({ ...register, [e.target.name]: e.target.files[0] });
        } else {
            setRegister({ ...register, [e.target.name]: e.target.value });
        }
    }

   function handleRegister(e) {
    e.preventDefault();
    const endPoint = 'company/account'
    const formData = new FormData()
    formData.append('name', register.fullname);
    formData.append('email', register.email);
    formData.append('number', register.phone);
    formData.append('password', register.password);
    formData.append('companyName', register.CompanyName);
    formData.append('industry', register.industry);
    formData.append('designation', register.designation);
    formData.append('address', register.address);
    formData.append('pincode', register.pincode);
    formData.append('profilePic', register.profile);
    formData.append('numberOfEmployees', register.employees);

    axios.post(baseUrl + endPoint, formData).then((response) => {
        const details = response.data.data
        console.log(details);
        console.log(details.companyName);
        localStorage.setItem('companyId',details._id)
        localStorage.setItem('companyName',details.companyName)
        Navigate('/Company/HomePage')
    }).catch((error) => {
        if (error.response) {
            if (error.response.data.status == 409) {
                setResponseMessage('Kindly Change these Company details :- Email or Number  ')
            }
        }
        console.error(error);
    });
}


    return (
        <>
            <Header1 />
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            <h6 className="sign-heading mt-5">
                                Sign-up and apply in less than 2 minutes
                            </h6>
                            <p className="text-muted">1,50,000+ companies hiring on MICS</p>
                        </div>

                        <div className="bg-white box-bg mt-4">
                            <div className="col-md-12">
                                <form onSubmit={(e) => handleRegister(e)}>

                                    {/* FullName */}
                                    <label className="form-label label-heading mt-3">
                                        Your Name <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="fullname"
                                        className="form-control form-holder"
                                        placeholder="What is your name?"
                                        // required
                                        value={register.fullname}
                                        onChange={handleInputField}
                                    />


                                    {/* Email */}
                                    <label className="form-label label-heading mt-3">
                                        Your Official Email <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="email"
                                        name="email"
                                        className="form-control form-holder"
                                        placeholder="Tell us your Email ID"
                                        // required
                                        value={register.email}
                                        onChange={handleInputField}
                                    />


                                    {/* Mobile Number */}
                                    <label className="form-label label-heading mt-3">
                                        Your Mobile number <span className="text-danger">*</span>
                                    </label>
                                    <div className="input-group">
                                        <span className="input-group-text" id="basic-addon1">+91</span>
                                        <input
                                            type="tel"
                                            name="phone"
                                            className="form-control form-holder"
                                            placeholder="Mobile Number"
                                            // required
                                            maxLength={10}
                                            value={register.phone}
                                            onChange={handleInputField}
                                        />
                                    </div>


                                    {/* Create Password */}
                                    <label className="form-label mt-3 label-heading">
                                        Password <span className="text-danger">*</span>
                                    </label>
                                    <div style={{ position: 'relative' }}>
                                        <input
                                            type={showPassword ? 'password' : 'text'}
                                            name="password"
                                            className="form-control form-holder"
                                            placeholder="Create a password"
                                            // required
                                            value={register.password}
                                            onChange={handleInputField}
                                        />
                                        {showPassword ? (
                                            <div
                                                className="bi bi-eye-slash-fill"
                                                onClick={() => setShowPassword(!showPassword)}
                                                style={{
                                                    position: 'absolute',
                                                    right: '30px',
                                                    top: '50%',
                                                    transform: 'translateY(-50%)',
                                                    cursor: 'pointer',
                                                }}
                                            ></div>
                                        ) : (
                                            <div
                                                className="bi bi-eye-fill"
                                                onClick={() => setShowPassword(!showPassword)}
                                                style={{
                                                    position: 'absolute',
                                                    right: '30px',
                                                    top: '50%',
                                                    transform: 'translateY(-50%)',
                                                    cursor: 'pointer',
                                                }}
                                            ></div>
                                        )}
                                    </div>


                                    {/* No. of Employees */}
                                    <label className="form-label label-heading mt-3">
                                        No. of Employees <span className="text-danger">*</span>
                                    </label>
                                    <select className="form-select form-holder"
                                        name="employees"
                                        value={register.employees}
                                        onChange={handleInputField}
                                    >
                                        <option >Select range</option>
                                        <option value="0 - 10">0 - 10</option>
                                        <option value="10 - 50">10 - 50</option>
                                        <option value="50 - 100">50 - 100</option>
                                        <option value="100 - 200">100 - 200</option>
                                        <option value="200 - 500">200 - 500</option>
                                        <option value="500 - 1000">500 - 1000</option>
                                    </select>


                                    {/* Company Name */}
                                    <label className="form-label label-heading mt-3">
                                        Your Comapny Name <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control form-holder"
                                        placeholder="What is your Company name?"
                                        name="CompanyName"
                                        value={register.CompanyName}
                                        onChange={handleInputField}
                                    />

                                      {/* Company image */}
                                      <label className="form-label label-heading mt-3">
                                        Your Profile Image <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="file"
                                        className="form-control form-holder"
                                        placeholder="What is your Company name?"
                                        name="profile"
                                        // value={register.profile}
                                        onChange={handleInputField}
                                    />

                                    {/* Select industry */}
                                    <label className="form-label label-heading mt-3">
                                        Select industry <span className="text-danger">*</span>
                                    </label>
                                    <select className="form-select form-holder"
                                        name="industry"
                                        value={register.industry}
                                        onChange={handleInputField}
                                    >
                                        <option >Select</option>
                                        <option value="Account & Auditing">Account & Auditing</option>
                                        <option value="Advertising & Marketing">Advertising & Marketing</option>
                                        <option value="E-Learning / EdTech">E-Learning / EdTech</option>   
                                        <option value="IT Services & Consulting">IT Services & Consulting</option>
                                        <option value="Software Product">Software Product</option>
                                    </select>


                                    {/* Your designation */}
                                    <label className="form-label label-heading mt-3">
                                        Your designation <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control form-holder"
                                        placeholder="What is your designation name?"
                                        name="designation"
                                        value={register.designation}
                                        onChange={handleInputField}
                                    />

                                    {/* Your Street address */}
                                    <label className="form-label label-heading mt-3">
                                        Street address <span className="text-danger">*</span>
                                    </label>
                                    <textarea
                                        className="form-control form-holder"
                                        name="address"
                                        value={register.address}
                                        onChange={handleInputField}
                                    />

                                    {/* Your Pincode */}
                                    <label className="form-label label-heading mt-3">
                                        Pincode <span className="text-danger">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control form-holder"
                                        name="pincode"
                                        value={register.pincode}
                                        onChange={handleInputField}
                                    />
                                    {/* response */}
                                    <p>{responseMessage?responseMessage:''}</p>
                                    {/* Term & Conditions */}
                                    <p className="term-text mt-4 text-muted">
                                        <input className="form-check-input me-2 fs-6" type="checkbox" id="flexCheckChecked" required />
                                        By signing up, you agree to our{" "}
                                        <span className="text-primary">Terms and Conditions</span>.
                                    </p>

                                    {/* Submit Button */}
                                    <button className="sign-button w-100 px-5 py-2 mt-2" >
                                        Sign up <i className="bi bi-arrow-right"></i>
                                    </button>
                                    <p className="text-center mt-4 text-muted">
                                        Already registered?
                                        <span
                                            className="text-primary fw-bold"
                                            style={{ cursor: "pointer" }}
                                        >
                                            {" "}
                                            <NavLink to='/recruit/login'> Login </NavLink>
                                        </span>
                                    </p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <Footer />
        </>
    );
}

export default Register;