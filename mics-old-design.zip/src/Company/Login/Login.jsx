import React, { useContext, useEffect, useState } from 'react';
import './login.css';
import { NavLink, useNavigate } from 'react-router-dom';
import Header1 from "../Header/Header1";
import Footer from "../Footer/Footer";
import axios from 'axios';
import baseUrl from '../../js/api';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';


function Login() {
    const [showPas, setShowPas] = useState(true);
    const [responseMessage, setResponseMessage] = useState('');

    const [login, setLogin] = useState({
        email: '',
        password: ''
    });


    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);


    const navigate = useNavigate();



    function handleInputFeild(e) {
        setLogin({ ...login, [e.target.name]: e.target.value });
    }

    function handleLogin(e) {
        e.preventDefault();
        const endPoint = 'company/log'
        axios.post(baseUrl + endPoint, login).then((response) => {
            const details = response.data
            if (details.status == 200) {
                localStorage.setItem('companyId', details.data._id)
                localStorage.setItem('companyName', details.data.companyName)
                navigate('/Company/HomePage')
            } else if (details.status == 404) {
                setResponseMessage(`We couldn't locate an account associated with the provided email address.
                 Please double-check the email or consider signing up for a new account.`);
            } else if (details.status == 401) {
                setResponseMessage(`
                The password you entered is incorrect. 
                Please double-check your password and try again.
                `)
            }
            setTimeout(() => {
                setResponseMessage('')
            }, 3000);
        }).catch((error) => {
            console.log(error);
        })
    }
    return (
        <>
            <Header1 />
            <div className="container">
                <div className="row">
                    <div className="col-md-12 text-center">
                        <h6 className="sign-heading mt-5">
                            Login and more jobs posting
                        </h6>
                        <p className="text-muted">1,50,000+ companies hiring on MICS</p>
                    </div>
                    <div className="bg-white box-bg mt-4">
                        <div className="col-md-12">
                            <form onSubmit={handleLogin}>
                                <label htmlFor="phone" className="form-label label-heading">
                                    Email
                                </label>

                                <div className="input-group mb-3">
                                    <input
                                        type="text"
                                        className="form-control form-holder"
                                        id="phone"
                                        placeholder='Enter Your Email'
                                        name='email'
                                        value={login.email}
                                        onChange={handleInputFeild}
                                        required
                                    />
                                </div>
                                <label
                                    htmlFor="password"
                                    className="form-label mt-3 label-heading"
                                >
                                    Password
                                </label>
                                <div style={{ position: 'relative' }}>
                                    <input
                                        type={showPas ? 'password' : 'text'}
                                        className="form-control form-holder"
                                        id="password"
                                        placeholder="Enter Your Password"
                                        name='password'
                                        value={login.password}
                                        onChange={handleInputFeild}
                                        required
                                    />
                                    {showPas ? (
                                        <i
                                            className="bi bi-eye-slash-fill"
                                            onClick={() => setShowPas(!showPas)}
                                            style={{
                                                position: 'absolute',
                                                right: '15px',
                                                top: '50%',
                                                transform: 'translateY(-50%)',
                                                cursor: 'pointer',
                                            }}
                                        ></i>
                                    ) : (
                                        <i
                                            className="bi bi-eye-fill"
                                            onClick={() => setShowPas(!showPas)}
                                            style={{
                                                position: 'absolute',
                                                right: '15px',
                                                top: '50%',
                                                transform: 'translateY(-50%)',
                                                cursor: 'pointer',
                                            }}
                                        ></i>
                                    )}
                                </div>
                                <span style={{ color: 'red' }}> 
                                <p style={{ color: 'red',margin:'10px' ,fontFamily:'-moz-initial' }} >{responseMessage?responseMessage:''}</p>
                                </span>
                                <p className="text-primary text-end mt-4 mb-3 modal-forget">
                                    <ForgotPasswordModal />
                                </p>

                                <button type='submit' className="sign-button w-100 px-5 py-2 mt-4">
                                    Login <i className="bi bi-arrow-right"></i>
                                </button>

                                <p className="text-center mt-4 text-muted">
                                    Don't have account? Create Account
                                    <span
                                        className="text-primary"
                                        id="loginmodal"
                                        style={{ cursor: "pointer" }}
                                    >
                                        <NavLink to='/recruit/client-registration-form'>
                                            <span className='ps-1 fw-bold'>Signup</span>
                                        </NavLink>
                                    </span>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Login;

function ForgotPasswordModal() {
    const [show, setShow] = useState(false);
  
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <>
        <span onClick={handleShow}>
        Forgot Password?
        </span>
  
        <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>Forgot Password</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
  
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Enter Your Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="name@example.com"
                  autoFocus
                />
              </Form.Group>
  
            </Form>
  
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button type='submit' variant="success" onClick={handleClose}>
              Send Forgot Password Link
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }