import React from 'react';
import 'blog.css';

function Blog() {
    return ( 
        <>
        
        </>
     );
}

export default Blog;