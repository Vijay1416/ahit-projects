import React, { useEffect, useState } from 'react';
import './profileSecurity.css'
import Header1 from '../Header/Header1';
import Footer from '../Footer/Footer';
import { Link } from 'react-router-dom';

function ProfileSecurity() {

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <>
            <Header1 />

            <Profile />

            <Security />

            <Footer />
        </>
    );
}

export default ProfileSecurity;

function Profile() {

    const profile = {
        path: "https://bootdey.com/img/Content/avatar/avatar1.png",
        name: "Ankit Samant",
        destination: "CEO",
        company: "A2Groups IT Company",
        description: "Driving success through cutting-edge technology, our IT company specializes in delivering tailored solutions for enhanced efficiency and growth in the digital landscape",
        email: "info@a2groups.org",
        mobile: "+91-96640 83783"
    }

    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-xl-12">
                        <div className="card">
                            <div className="card-body pb-0">
                                <div className="row align-items-center">
                                    <div className="col-md-4">
                                        <div className="text-center border-end">
                                            <img src={profile.path} className="img-fluid avatar-xxl rounded-circle" alt="" />
                                            <h4 className="text-primary font-size-20 mt-3 mb-2">{profile.name}</h4>
                                            <h5 className="text-muted font-size-13 mb-0">{profile.destination}</h5>
                                        </div>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="ms-3">
                                            <div>
                                                <h4 className="card-title mb-2">{profile.company}</h4>
                                                <p className="mb-0 text-muted">{profile.description}</p>
                                            </div>
                                            <div className="row my-4">
                                                <div className="col-md-12">
                                                    <div>
                                                        <p className="text-muted mb-2 fw-medium"><i className="mdi mdi-email-outline me-2"></i> {profile.email} </p>
                                                        <p className="text-muted fw-medium mb-0"><i className="mdi mdi-phone-in-talk-outline me-2"></i> {profile.mobile} </p>
                                                    </div>
                                                </div>
                                            </div>

                                            <ul className="nav nav-tabs nav-tabs-custom border-bottom-0 mt-3 nav-justfied" role="tablist">
                                                <li className="nav-item" role="presentation">
                                                    <Link to='/company/profile' className="nav-link px-4">
                                                        <span className="d-sm-block"><i className="bi bi-list-task"></i> Job Posted</span>
                                                    </Link>
                                                </li>
                                                <li className="nav-item" role="presentation">
                                                    <Link className="nav-link active px-4">
                                                        <span className="d-sm-block"><i className="bi bi-gear"></i> Setting</span>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

function Security() {

    const initialValue = {
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
    }

    const [showCurrentPassword, setShowCurrentPassword] = useState(true);
    const [showNewPassword, setShowNewPassword] = useState(true);
    const [showConfirmPassword, setShowConfirmPassword] = useState(true);

    const [security, setSecurity] = useState(initialValue);

    function handleInputField(e) {
        setSecurity({ ...security, [e.target.name]: e.target.value })
    }

    function handleChangePassword(e) {
        e.preventDefault();
        console.log("Password Changed : ", security)
    }


    function handleDeleteAccount() {
        var isConfirmed = confirm('Are you sure you want to permanently delete your account?');

        if (isConfirmed) {
            alert('Account deleted successfully.');
        } else {
            alert('Account deletion canceled.');
        }
    }


    return (
        <>
            <div className="container-xl px-4 mt-4">
                <nav className="nav nav-borders">
                    <Link to='/company/profile/setting' className="nav-link ms-0"><i className="bi bi-person"></i> Profile</Link>
                    <Link className="nav-link active"><i className="bi bi-key"></i> Security</Link>
                </nav>
                <hr className="mt-0 mb-4" />
                <div className="row">
                    <div className="col-lg-8">

                        <div className="card mb-4">
                            <div className="card-header">Change Password</div>
                            <div className="card-body">

                                <form onSubmit={handleChangePassword}>

                                    <div style={{ position: 'relative' }}>
                                        <div className="mb-3">
                                            <label className="fw-bold mb-1" htmlFor="currentPassword">Current Password</label>
                                            <input
                                                className="form-control"
                                                id="currentPassword"
                                                type={showCurrentPassword ? 'password' : 'text'}
                                                placeholder="Enter current password"
                                                name='currentPassword'
                                                value={security.currentPassword}
                                                onChange={handleInputField}
                                            />
                                            {showCurrentPassword ? (
                                                <i
                                                    className="bi bi-eye-slash-fill fs-5"
                                                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            ) : (
                                                <i
                                                    className="bi bi-eye-fill fs-5"
                                                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            )}
                                        </div>
                                    </div>

                                    <div style={{ position: 'relative' }}>
                                        <div className="mb-3">
                                            <label className="fw-bold mb-1" htmlFor="newPassword">New Password</label>
                                            <input
                                                className="form-control"
                                                id="newPassword"
                                                type={showNewPassword ? 'password' : 'text'}
                                                placeholder="Enter new password"
                                                name='newPassword'
                                                value={security.newPassword}
                                                onChange={handleInputField}
                                            />
                                            {showNewPassword ? (
                                                <i
                                                    className="bi bi-eye-slash-fill fs-5"
                                                    onClick={() => setShowNewPassword(!showNewPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            ) : (
                                                <i
                                                    className="bi bi-eye-fill fs-5"
                                                    onClick={() => setShowNewPassword(!showNewPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            )}
                                        </div>
                                    </div>

                                    <div style={{ position: 'relative' }}>
                                        <div className="mb-3">
                                            <label className="fw-bold mb-1" htmlFor="confirmPassword">Confirm Password</label>
                                            <input
                                                className="form-control"
                                                id="confirmPassword"
                                                type={showConfirmPassword ? 'password' : 'text'}
                                                placeholder="Confirm new password"
                                                name='confirmPassword'
                                                value={security.confirmPassword}
                                                onChange={handleInputField}
                                            />
                                            {showConfirmPassword ? (
                                                <i
                                                    className="bi bi-eye-slash-fill fs-5"
                                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            ) : (
                                                <i
                                                    className="bi bi-eye-fill fs-5"
                                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                                    style={{
                                                        position: 'absolute',
                                                        right: '15px',
                                                        top: '50%',
                                                        cursor: 'pointer',
                                                    }}
                                                ></i>
                                            )}
                                        </div>
                                    </div>
                                    <button className="btn btn-primary" type="submit">Update Password</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-4">
                        <div className="card mb-4">
                            <div className="card-header">Delete Account</div>
                            <div className="card-body">
                                <p>Deleting your account is a permanent action and cannot be undone. If you are sure you want to delete your account, select the button below.</p>
                                <button className="btn btn-danger-soft text-danger" onClick={handleDeleteAccount}>I understand, delete my account</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}