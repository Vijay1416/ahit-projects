import React, { useContext, useEffect, useState } from 'react';
import './profileSetting.css';
import Header1 from '../Header/Header1';
import Footer from '../Footer/Footer';
import { Link } from 'react-router-dom';
import MyContext from '../../utile/Context';
import baseUrl from '../../js/api';
import axios from 'axios';


function ProfileSetting() {
    const context = useContext(MyContext)
    const [ profile,setProfile] = useState({})
    const companyId = localStorage.getItem('companyId')
    const endpoint = `company/data/${companyId}`
    const profileApi = ()=>{
        axios.get(baseUrl+endpoint).then((response)=>{
            // console.log(response.data.data);
            setProfile(response.data.data);
        })
    }
    useEffect(()=>{
        profileApi()
    },[])
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <>
            <Header1 />

            <Profile profile={profile[0]}/>

            <ProfileEdit profile={profile[0]} />

            <Footer />
        </>
    );
}

export default ProfileSetting;

function Profile(props) {
    
    const profile = props?.profile || {
        path: "https://bootdey.com/img/Content/avatar/avatar1.png",
        name: "Ankit Samant",
        destination: "CEO",
        company: "A2Groups IT Company",
        description: "Driving success through cutting-edge technology, our IT company specializes in delivering tailored solutions for enhanced efficiency and growth in the digital landscape",
        email: "info@a2groups.org",
        mobile: "+91-96640 83783"
    }

    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-xl-12">
                        <div className="card">
                            <div className="card-body pb-0">
                                <div className="row align-items-center">
                                    <div className="col-md-4">
                                        <div className="text-center border-end">
                                            <img src={profile.profilePic?baseUrl+profile.profilePic:'https://bootdey.com/img/Content/avatar/avatar1.png'} className="img-fluid avatar-xxl rounded-circle" alt="" />
                                            <h4 className="text-primary font-size-20 mt-3 mb-2">{profile?.name}</h4>
                                            <h5 className="text-muted font-size-13 mb-0">{profile?.designation}</h5>
                                        </div>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="ms-3">
                                            <div>
                                                <h4 className="card-title mb-2">{profile?.companyName}</h4>
                                                <p className="mb-0 text-muted">{profile?.description}</p>
                                            </div>
                                            <div className="row my-4">
                                                <div className="col-md-12">
                                                    <div>
                                                        <p className="text-muted mb-2 fw-medium"><i className="mdi mdi-email-outline me-2"></i> {profile?.email} </p>
                                                        <p className="text-muted fw-medium mb-0"><i className="mdi mdi-phone-in-talk-outline me-2"></i> {profile?.number} </p>
                                                    </div>
                                                </div>
                                            </div>

                                            <ul className="nav nav-tabs nav-tabs-custom border-bottom-0 mt-3 nav-justfied" role="tablist">
                                                <li className="nav-item" role="presentation">
                                                    <Link to='/company/profile' className="nav-link px-4">
                                                        <span className="d-sm-block"><i className="bi bi-list-task"></i> Job Posted</span>
                                                    </Link>
                                                </li>
                                                <li className="nav-item" role="presentation">
                                                    <Link className="nav-link active px-4">
                                                        <span className="d-sm-block"><i className="bi bi-gear"></i> Setting</span>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

function ProfileEdit() {

    const [selectedImage, setSelectedImage] = useState(null);

    function handleProfileImageChange(e) {
        const fileInput = e.target;
        const selectedFile = fileInput.files[0];

        if (selectedFile) {
            console.log('Selected file:', selectedFile.name);

            const reader = new FileReader();
            reader.onload = (event) => {
                setSelectedImage(event.target.result);
            };
            reader.readAsDataURL(selectedFile);
        } else {
            console.error('No file selected.');
        }
    }

    const initialValue = {
        fname: "",
        lname: "",
        email: "",
        phone: "",
        organization: "",
        about: "",
        designation: "",
        yearCompany: "",
        address: "",
        pincode: "",
    }

    const [profile, setProfile] = useState(initialValue);

    function handleInputField(e) {
        setProfile({ ...profile, [e.target.name]: e.target.value })
    }

    function handleProfileAccount(e) {
        e.preventDefault();
        console.log("Profile Account data submit : ", profile)
    }

    return (
        <>
            <div className="container-xl px-4 mt-4">

                <nav className="nav nav-borders">
                    <Link className="nav-link active ms-0"><i className="bi bi-person"></i> Profile</Link>
                    <Link to='/company/profile/setting/security' className="nav-link"><i className="bi bi-key"></i> Security</Link>
                </nav>
                <hr className="mt-0 mb-4" />
                <div className="row">
                    <div className="col-xl-4">
                        <div className="card mb-4 mb-xl-0">
                            <div className="card-header">Profile Picture</div>
                            <div className="card-body text-center">
                                {selectedImage ? (
                                    <img
                                        className="mb-2" style={{ width: "150px", height: "150px", borderRadius: "50%" }}
                                        src={selectedImage}
                                        alt="Selected Profile"
                                    />
                                ) : (
                                    <img
                                        className="img-account-profile rounded-circle mb-2"
                                        src="http://bootdey.com/img/Content/avatar/avatar6.png"
                                        alt=""
                                    />
                                )}
                                <input
                                    type="file"
                                    id="profileImageInput"
                                    className="Profile-Image-Change"
                                    // style={{ margin: "10px 0 10px 80px" }}
                                    onChange={handleProfileImageChange}
                                />
                                <div className="small font-italic text-dark fw-bold">JPG or PNG no larger than 5 MB</div>

                                <button type="submit" className="btn btn-primary mt-4">
                                    Update Profile Image
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-8">
                        <div className="card mb-4">
                            <div className="card-header">Account Details</div>
                            <div className="card-body">

                                <form onSubmit={handleProfileAccount}>

                                    <div className="row gx-3 mb-3">
                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputFirstName">First name</label>
                                            <input
                                                className="form-control"
                                                id="inputFirstName"
                                                type="text"
                                                placeholder="Enter your first name"
                                                name='fname'
                                                value={profile.fname}
                                                onChange={handleInputField}
                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputLastName">Last name</label>
                                            <input
                                                className="form-control"
                                                id="inputLastName"
                                                type="text"
                                                placeholder="Enter your last name"
                                                name='lname'
                                                value={profile.lname}
                                                onChange={handleInputField}
                                            />
                                        </div>
                                    </div>



                                    <div className="row gx-3 mb-3">

                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputEmailAddress">Email address</label>
                                            <input
                                                className="form-control"
                                                id="inputEmailAddress"
                                                type="email"
                                                placeholder="Enter your email address"
                                                name='email'
                                                value={profile.email}
                                                onChange={handleInputField}
                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputPhone">Phone number</label>
                                            <input
                                                className="form-control"
                                                id="inputPhone"
                                                type="tel"
                                                placeholder="Enter your phone number"
                                                name='phone'
                                                value={profile.phone}
                                                onChange={handleInputField}
                                            />
                                        </div>
                                    </div>

                                    <div className="mb-3">
                                        <label className="fw-bold mb-1" htmlFor="inputOrganization">Organization Name</label>
                                        <input
                                            className="form-control"
                                            id="inputOrganization"
                                            type="text"
                                            placeholder="Enter your organization"
                                            name='organization'
                                            value={profile.organization}
                                            onChange={handleInputField}
                                        />
                                    </div>

                                    <div className="mb-3">
                                        <label className="fw-bold mb-1" htmlFor="inputAbout">About Company</label>
                                        <textarea
                                            className="form-control"
                                            id="inputAbout"
                                            type="text"
                                            placeholder="Enter your about company"
                                            cols="30" rows="10"
                                            name='about'
                                            value={profile.about}
                                            onChange={handleInputField}
                                        />
                                    </div>


                                    <div className="row gx-3 mb-3">

                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputLocation">Your Designation</label>
                                            <input
                                                className="form-control"
                                                id="inputLocation"
                                                type="text"
                                                placeholder="Enter your designation"
                                                name='designation'
                                                value={profile.designation}
                                                onChange={handleInputField}
                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <label className="fw-bold mb-1" htmlFor="inputYearCompany">No. of Year Company</label>
                                            <input
                                                className="form-control"
                                                id="inputYearCompany"
                                                type="text"
                                                placeholder="Enter your No. of Year Company"
                                                name='yearCompany'
                                                value={profile.yearCompany}
                                                onChange={handleInputField}
                                            />
                                        </div>
                                    </div>

                                    <div className="mb-3">
                                        <label className="fw-bold mb-1" htmlFor="inputFullAddress">Full Address</label>
                                        <textarea
                                            className="form-control"
                                            id="inputFullAddress"
                                            type="text"
                                            placeholder="Enter your Address"
                                            cols="30" rows="10"
                                            name='address'
                                            value={profile.address}
                                            onChange={handleInputField}
                                        />
                                    </div>

                                    <div className="row gx-3 mb-3">

                                        <div className="col-md-12">
                                            <label className="fw-bold mb-1" htmlFor="inputPinCode">Pin Code</label>
                                            <input
                                                className="form-control"
                                                id="inputPinCode"
                                                type="text"
                                                placeholder="Enter your Pincode Number"
                                                maxLength={6}
                                                name='pincode'
                                                value={profile.pincode}
                                                onChange={handleInputField}
                                            />
                                        </div>

                                    </div>

                                    <button className="btn btn-primary" type="submit">Update Profile</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}