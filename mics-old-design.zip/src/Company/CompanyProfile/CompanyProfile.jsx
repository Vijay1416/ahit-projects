import React, { useState, useEffect, useContext } from 'react';
import './companyProfile.css';
import Header1 from '../Header/Header1';
import Footer from '../Footer/Footer';
import { Link } from 'react-router-dom';
import axios from 'axios';
import baseUrl from '../../js/api';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import MyContext from '../../utile/Context';


function CompanyProfile() {
    const [profile, setProfile] = useState({})
    const companyId = localStorage.getItem('companyId')
    const endpoint = `company/data/${companyId}`
    const profileApi = () => {
        axios.get(baseUrl + endpoint).then((response) => {
            // console.log(response.data.data);
            setProfile(response.data.data);
        })
    }
    useEffect(() => {
        profileApi()
    }, [])
    return (
        <>

            <Header1 />

            <Profile profile={profile} />

            <JobPosted jobs={profile[0]?.post} />

            <Footer />
        </>
    );
}

export default CompanyProfile;

function Profile(props) {
    const profileDetails = props.profile[0]
    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-xl-12">
                        <div className="card">
                            <div className="card-body pb-0">
                                <div className="row align-items-center">
                                    <div className="col-md-4">
                                        <div className="text-center border-end">
                                            <img src={profileDetails?.profilePic ? baseUrl + profileDetails?.profilePic : "https://bootdey.com/img/Content/avatar/avatar1.png"} className="img-fluid avatar-xxl rounded-circle" alt="" />
                                            <h4 className="text-primary font-size-20 mt-3 mb-2"> {profileDetails?.name} </h4>
                                            <h5 className="text-muted font-size-13 mb-0">{profileDetails?.designation}</h5>
                                        </div>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="ms-3">
                                            <div>
                                                <h4 className="card-title mb-2">{profileDetails?.companyName}</h4>
                                                <p className="mb-0 text-muted">{profileDetails?.description}</p>
                                            </div>
                                            <div className="row my-4">
                                                <div className="col-md-12">
                                                    <div>
                                                        <p className="text-muted mb-2 fw-medium"><i className="mdi mdi-email-outline me-2"></i> {profileDetails?.email} </p>
                                                        <p className="text-muted fw-medium mb-0"><i className="mdi mdi-phone-in-talk-outline me-2"></i> {profileDetails?.number} </p>
                                                    </div>
                                                </div>
                                            </div>

                                            <ul className="nav nav-tabs nav-tabs-custom border-bottom-0 mt-3 nav-justfied">
                                                <li className="nav-item" role="presentation">
                                                    <Link to='#' className="nav-link active">
                                                        <span className="d-sm-block"><i className="bi bi-list-task"></i> Job Posted</span>
                                                    </Link>
                                                </li>
                                                <li className="nav-item" role="presentation">
                                                    <Link to='/company/profile/setting' className="nav-link">
                                                        <span className="d-sm-block"><i className="bi bi-gear"></i> Setting</span>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

function JobPosted(props) {
    const JobPost = props?.jobs
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-xl-12">
                        <div className="card">
                            <div className="tab-content p-4">
                                <div className="tab-pane active show" id="projects-tab" role="tabpanel">
                                    <div className="d-flex justify-content-between">
                                        <div className="flex-1">
                                            <h4 className="card-title mb-4">Job Posted</h4>
                                        </div>
                                        <div className="">
                                            <Link to='/recruit/hire-page'> <button className=" btn btn-primary mb-4">New Job Post</button> </Link>
                                        </div>
                                    </div>

                                    <div className="row" id="all-projects">

                                        {JobPost?.map((posted, index) => (
                                            <div className="col-md-6" id="project-items-1" key={index}>
                                                <div className="card">
                                                    <div className="card-body">
                                                        <div className="d-flex mb-3">
                                                            <div className="flex-grow-1 align-items-start">
                                                                <div>
                                                                    <h6 className="mb-0 text-muted">
                                                                        <span className='fw-bold'>Posted Date : </span>
                                                                        {/* <i className="mdi mdi-circle-medium text-danger fs-3 align-middle"></i> */}
                                                                        <span className="team-date">{posted.createdAt}</span>
                                                                    </h6>
                                                                </div>
                                                            </div>

                                                            <div className="dropdown ms-2" style={{ cursor: "pointer" }}>
                                                                <span className="dropdown-toggle font-size-16 text-muted" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i className="mdi mdi-dots-horizontal"></i>
                                                                </span>

                                                                <div className="dropdown-menu dropdown-menu-end">
                                                                    <Link className="dropdown-item text-primary"><i className="bi bi-person-lines-fill me-2"></i> <AppliedUserList id={posted?._id} /></Link>
                                                                    <Link className="dropdown-item text-info"><i className="bi bi-pencil-square me-2"></i> Edit</Link>
                                                                    <Link className="dropdown-item text-success"><i className="bi bi-share me-2"></i> Share</Link>
                                                                    <div className="dropdown-divider"></div>
                                                                    <Link className="dropdown-item delete-item text-danger"><i className="bi bi-trash me-2"></i> Delete</Link>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="mb-4">
                                                            <h5 className="mb-1 font-size-17 team-title">{posted.titel}</h5>
                                                            <p className="text-muted mb-0 team-description">{posted?.experience}</p>
                                                        </div>

                                                        <div className="d-flex">
                                                            <div className="avatar-group float-start flex-grow-1 task-assigne" >
                                                                <div className="avatar-group-item">
                                                                    <img src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="" className="rounded-circle avatar-sm" />
                                                                </div>
                                                                <div className="avatar-group-item">
                                                                    <img src="https://bootdey.com/img/Content/avatar/avatar5.png" alt="" className="rounded-circle avatar-sm" />
                                                                </div>
                                                                <div className="avatar-group-item">
                                                                    <img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="" className="rounded-circle avatar-sm" />
                                                                </div>
                                                            </div>
                                                            <div className="align-self-end">
                                                                <Link> <span className="badge badge-soft-primary p-2 team-status"><JobPostedViewDetailModal postId={posted?._id} upload={posted?.createdAt} /></span></Link>                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

import profileImage from '../../assets/images/parttime.png'

function AppliedUserList(props) {
    const [selectedUser, setSelectedUser] = useState(null);
    const [show, setShow] = useState(false);
    const [UserList, setUserList] = useState([])
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const postId = `find/apply/${props.id}`
    const applyUserApi = () => {
        axios.get(baseUrl + postId).then((response) => {
            // console.log(response.data.data)
            setUserList(response.data.data)
        })
    }
    useEffect(() => {
        applyUserApi()
    }, [])

    const handleUserClick = (user) => {
        setSelectedUser((prevUser) => (prevUser === user ? null : user));
    };

    return (
        <>
            <span onClick={handleShow}>
                Applied Users List
            </span>

            <Modal show={show} onHide={handleClose} dialogClassName="modal-xl">
                <Modal.Header closeButton>
                    <Modal.Title>Applied Users List</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    <div className="container">
                        <div className="row align-items-center">
                        </div>
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="">
                                    <div className="table-responsive">
                                        <table className="table project-list-table table-nowrap align-middle table-borderless">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Position</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Mobile</th>
                                                    <th scope="col">Resume View</th>
                                                    {/* <th scope="col" style={{ width: "200px" }}>Action</th> */}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {UserList.map((user, index) => (
                                                    <tr key={index}>
                                                        <td><img src={user.user.profilePic ? baseUrl + user.user.profilePic : profileImage} alt="" className="avatar-sm rounded-circle me-2" /><a href="#" className="text-body">{user?.user?.name}</a></td>
                                                        <td><span className="badge badge-soft-primary mb-0">{user?.user?.experience}</span></td>
                                                        <td>{user?.user?.email}</td>
                                                        <td>{user?.user?.number}</td>
                                                        <td className='text-center'>
                                                            {/* <i
                                                                className="bi bi-file-earmark-pdf text-danger fs-3"
                                                                style={{ cursor: "pointer" }}
                                                            // onClick={() => handleUserClick(user)}

                                                            /> */}
                                                            <ResumePdfModal resume={user?.user?.resume} />
                                                        </td>
                                                        {/* <td>
                                                    <ul className="list-inline mb-0">
                                                        <li className="list-inline-item">
                                                            <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit" className="px-2 text-primary"><i className="bi bi-pencil font-size-18"></i></a>
                                                        </li>
                                                        <li className="list-inline-item">
                                                            <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" className="px-2 text-danger"><i className="bi bi-trash font-size-18"></i></a>
                                                        </li>
                                                        <li className="list-inline-item dropdown">
                                                            <a className="text-muted dropdown-toggle font-size-18 px-2" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true"><i className="bi bi-three-dots-vertical"></i></a>
                                                            <div className="dropdown-menu dropdown-menu-end">
                                                                <a className="dropdown-item" href="#">Action</a><a className="dropdown-item" href="#">Another action</a><a className="dropdown-item" href="#">Something else here</a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </td> */}
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <div className="row g-0 align-items-center pb-4">
                            <div className="col-sm-6">
                                <div><p className="mb-sm-0">Showing 1 to 10 of 57 entries</p></div>
                            </div>
                            <div className="col-sm-6">
                                <div className="float-sm-end">
                                    <ul className="pagination mb-sm-0">
                                        <li className="page-item disabled">
                                            <a href="#" className="page-link"><i className="mdi mdi-chevron-left"></i></a>
                                        </li>
                                        <li className="page-item active"><a href="#" className="page-link">1</a></li>
                                        <li className="page-item"><a href="#" className="page-link">2</a></li>
                                        <li className="page-item"><a href="#" className="page-link">3</a></li>
                                        <li className="page-item"><a href="#" className="page-link">4</a></li>
                                        <li className="page-item"><a href="#" className="page-link">5</a></li>
                                        <li className="page-item">
                                            <a href="#" className="page-link"><i className="mdi mdi-chevron-right"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div> */}
                    </div>

                </Modal.Body>
            </Modal>
        </>
    );
}

function JobPostedViewDetailModal(props) {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [jobData, setjobData] = useState({})
    const singleJobs = () => {
        const endPoint = `get/job/by-jobId/${props.postId}`
        axios.get(baseUrl + endPoint).then((response) => {
            setjobData(response?.data?.data);
        })
    }
    useEffect(() => {
        singleJobs()
    }, [])

    return (
        <>
            <span onClick={handleShow}>
                View Detail
            </span>

            <Modal show={show} onHide={handleClose} dialogClassName="modal-xl">
                <Modal.Header closeButton>
                    <Modal.Title className='text-primary fw-bold'>Job Posted Details</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="container-fluid p-0">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card bg-white shadow-sm rounded border-0">
                                    <div className="card-body">
                                        <div className="d-flex justify-content-between">
                                            <div>
                                                <h5 className="card-title intern-title">{jobData?.titel}</h5>
                                                <p className="text-muted cmpy-name">{jobData?.who_post?.companyName}</p>
                                                {/* add review and rating */}
                                                <p className="text-muted rate-text">4.5 <span><i className="bi bi-star-fill text-warning"></i></span> (1000 reviews)</p>
                                            </div>
                                            <img src="/src/assets/images/milogo.png" alt="company logo" className="img-fluid intern-logo-img" />
                                        </div>

                                        <p className="text-muted work-text"><i className="bi bi-house-door-fill fs-5"></i>{jobData?.job_type}</p>
                                        <div className="display-tag">
                                            <div>
                                                <p className="display-font"><i className="bi bi-briefcase-fill"></i> Experience</p>
                                                <p className="text-muted para-intern"> {jobData?.experience}</p>
                                            </div>

                                            <div className="tag-side">
                                                <p className="display-font"><i className="bi bi-geo-alt-fill"></i> Location</p>
                                                <p className="text-muted para-intern">{jobData?.who_post?.address}</p>
                                            </div>

                                            <div className="tag-side">
                                                <p className="display-font"><i className="bi bi-cash-coin"></i> Salary</p>
                                                <p className="text-muted para-intern">{jobData?.salary}</p>
                                            </div>
                                        </div>
                                        {/* <hr />
                                            <div className="share-post">
                                                <div className="d-flex"><p className="text-muted para-intern mt-0">2 days ago</p>
                                                    <p className="ms-3" style={{ cursor: "pointer" }}><i className="bi bi-share fs-5 text-primary"></i></p></div>
                                                <a href="#"><button className="text-white bg-primary px-5 py-2 shadow rounded border-0">Apply</button></a>
                                            </div> */}
                                    </div>
                                </div>

                                <div className="card mt-4 border-0 shadow-sm rounded">
                                    <div className="card-body">
                                        <h5 className="card-title des-title">Job Description</h5>
                                        <p>{jobData?.description}</p>
                                        <h6 className="card-subtitle mt-2 skill-des">Required skill:</h6>
                                        <ul className="mt-2">
                                            <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                                            <li className="skill-list mt-1">Candidate should have 3+ Years of experience in Java.</li>
                                            <li className="skill-list mt-1">Should have experience in Angular.</li>
                                            <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                                            <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                                            <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                                        </ul>
                                        <h6 className="card-subtitle mt-4 skill-des">Roles & Responsibility:</h6>
                                        <ul className="mt-2">
                                            <li className="skill-list mt-1">To create work plans, monitor and track the work schedule for on time delivery as per the defined quality standards.</li>
                                            <li className="skill-list mt-1">To develop and guide the team members in enhancing their technical capabilities and increasing productivity.</li>
                                            <li className="skill-list mt-1">To ensure process improvement and compliance in the assigned module, and participate in technical discussions or review.</li>
                                            <li className="skill-list mt-1">To prepare and submit status reports for minimizing exposure and risks on the project or closure of escalations.</li>

                                        </ul>

                                        <p className="mt-5 text-muted">Role :</p>
                                        <p className="role-job">{jobData?.role}</p>
                                        <p className="text-muted">Industry Type :</p>
                                        <p className="role-job">{jobData?.who_post?.industry}</p>
                                        {/* <p className="text-muted">Department :</p>
                                            <p className="role-job">Engineering - Software & QA</p> */} 
                                        <p className="text-muted">Employment Type :</p>
                                        <p className="role-job">{jobData?.duration}</p>
                                        {/* <p className="text-muted">Role Category :</p>
                                            <p className="role-job">Software Development</p> */}
                                        <p className="text-muted">Education :</p>
                                        <p className="role-job">{jobData.graduation ? jobData?.graduation : 'Not Fill'}</p>
                                        <p className="text-muted">Key skill :</p>
                                        <div className="row">
                                            {
                                                jobData?.skill?.map((skill) => (
                                                    <div className="col-md-3">
                                                    <p className="role-job key-skill mt-1 ms-2"> {skill}</p>
                                               </div>
                                                ))
                                            }
                                        </div>
                                        <p className="text-muted">Number of openings :</p>
                                        <p className="role-job">{jobData?.vacancy}</p>
                                        <p className="text-muted">Job activity :</p>
                                        <p className="role-job">{props?.upload}</p>

                                    </div>
                                </div>

                                <div className="card mt-4 border-0 rounded shadow-sm">
                                    <div className="card-body">
                                        <h5 className="card-title des-title">About MICS</h5>
                                        <a href={jobData?.url} className="text-decoration-none"><p className="web-share">website <i className="bi bi-box-arrow-up-right"></i></p></a>
                                        <p className="cmp-about">{jobData?.who_post?.description}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
            </Modal >
        </>
    );
}

function ResumePdfModal(resume) {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [fullscreen, setFullscreen] = useState(true);


    return (
        <>
            <span onClick={handleShow}>
                <i
                    className="bi bi-file-earmark-pdf text-danger fs-3"
                    style={{ cursor: "pointer" }}
                // onClick={() => handleUserClick(user)}

                />
            </span>
            <Modal show={show} onHide={handleClose} fullscreen={fullscreen} dialogClassName="modal-true">
                <Modal.Header closeButton>
                    <Modal.Title>Resume View</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    {/* Additional details or content you want to show when the user is clicked */}
                    <iframe
                        title="Resume"
                        width="100%"
                        height="100%"
                        src={baseUrl + resume.resume}
                        style={{ border: "none" }}
                    />

                </Modal.Body>
            </Modal>
        </>
    );
}