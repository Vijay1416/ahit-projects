import React, { useEffect, useState } from 'react';
import './companyHome.css';
import Carousel from 'react-bootstrap/Carousel';
import jobImage from '/src/assets/images/job.png';
import { NavLink } from 'react-router-dom';
import Header1 from "../Header/Header1";
import Footer from "../Footer/Footer";
import img1 from './homePage1.png';
import img2 from './homePage2.png';
import axios from 'axios';
import baseUrl from '../../js/api';


function CompanyHome() {
    // const [blogList, setBlogList] = useState([])
    // function blog() {
    //     const blogeEndPoint = 'blog'
    //     axios.get(baseUrl + blogeEndPoint).then((response) => {
    //         setBlogList(response.data.data);
    //     })
    // }

    useEffect(() => {
        // blog()
        window.scrollTo(0, 0);
    }, []);

    return (
        <>
            <Header1 />

            <Banner />

            {/* <HiringNow /> */}

            <MidContent />

            <Blogs />

            <BrandLogoSlider />

            <Footer />
        </>
    );
}

export default CompanyHome;

function Banner() {
    const [index, setIndex] = useState(0);

    const handleSelect = (selectedIndex) => {
        setIndex(selectedIndex);
    };

    const banners = [
        { path: "/src/assets/images1/banner_lg1.jpg" },
        { path: "/src/assets/images1/banner_lg2.jpg" },
        { path: "/src/assets/images1/banner_lg3.jpg" },
        { path: "/src/assets/images1/4.jpg" },
        { path: "/src/assets/images1/5.jpg" },
    ]

    return (
        <>

            <Carousel activeIndex={index} onSelect={handleSelect}>
                {banners.map((item, index) => (
                    <Carousel.Item key={index}>
                        <img src={item.path} alt="" style={{ width: "100%" }} />
                    </Carousel.Item>
                ))}

            </Carousel>
        </>
    );
}

function HiringNow() {
    return (
        <>
            <div className="portal-bg mt-5">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 text-center mb-3">
                            <h3 className="heading-text">India’s Largest Job Portal</h3>
                            <p className="text-muted">WorkIndia helps you hire staff in 2 days</p>

                            <img src={jobImage} alt="Job Portal" className="img-fluid" />

                            <div className="d-btn mt-4">
                                <NavLink to='/recruit/hire-page'>
                                    <button className="px-5 py-2 rounded shadow border-0 text-white port-btn">Hire Now</button>
                                </NavLink>

                                {/* <NavLink to='/hire-page'>
                                    <button className="px-5 py-2 rounded shadow border-0 text-white jb-btn port-btn">Get a Job</button>
                                </NavLink> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

function MidContent() {
    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <h1 className='content-main-title'>Naukri is India’s No.1 Job Posting </h1>
                    <h1 className='content-main-title1'>& Recruitment Platform</h1>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <img className="w-100 shadow mid-content-img" src={img1} />
                    </div>
                    <div className="col-md-6">
                        <div className="p-3">
                            <p className="mid-content-title">Naukri Job Posting Services - Get Quality Applies</p>
                            <p className="lead">Reach out to millions of jobseekers and hire quickly with our fast and easy job posting services. </p>
                            <a href="#" className="btn btn-outline-dark">Read More</a>
                        </div>
                    </div>
                </div>

                <div className="row mt-5">
                    <div className="col-md-6">
                        <div className="p-3 mt-4">
                            <p className="mid-content-title1">Search Best Talent with Naukri’s Resume Database Access</p>
                            <p className="lead">Source candidates from Resdex − India’s largest Talent Pool and find the perfect talent for your organisation. </p>
                            <a href="#" className="btn btn-outline-dark">Read More</a>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <img className="w-100 shadow mid-content-img1" src={img2} />
                    </div>
                </div>
            </div>
        </>
    );
}

function Blogs() {

    const [blogList, setBlogList] = useState([])
    function blog() {
        const blogeEndPoint = 'blog'
        axios.get(baseUrl + blogeEndPoint).then((response) => {
            setBlogList(response.data.data);
        })
    }

    useEffect(() => {
        blog()
    }, []);
    // const handleImageError = (event) => {
    //     event.target.src = 'https://yt3.ggpht.com/a/AGF-l7-0J1G0Ue0mcZMw-99kMeVuBmRxiPjyvIYONg=s900-c-k-c0xffffffff-no-rj-mo';
    // };
    function truncateDescription(description) {
        const words = description.split(' ');
        if (words.length <= 30) {
            return description;
        } else {
            return words.slice(0, 20).join(' ') + '...';
        }
    }
    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <h3 className='text-primary fw-bold'>NAUKRI BLOG POST</h3>
                    <h4>What's New</h4>
                    <div className='blogs'>
                        {
                            blogList && blogList.map((blogs, index) => (
                                <div className="col-md-3" key={index}>
                                    <div className="card-blog">
                                        <div className="card-header-bolg">
                                            <img
                                                src={blogs?.blogImg && `${baseUrl}${blogs?.blogImg}`}
                                                alt="Blog Image"
                                            />
                                        </div>
                                        <div className="card-body-blog">
                                            <span className="tag-blog tag-teal">{blogs?.field}</span>
                                            <h4>
                                                {blogs?.titel}
                                            </h4>
                                            <p>
                                                {truncateDescription(blogs?.description)}
                                            </p>
                                            <div className="user-blog">
                                                <img src={blogs?.bloggerImg && baseUrl + blogs?.bloggerImg} alt="blogger" />
                                                <div className="user-info">
                                                    <h5>{blogs.blogger}</h5>
                                                    <small>{blogs.createdAt}</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                </div>
            </div>
        </>
    );
}

function BrandLogoSlider() {
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="logo-slider">
                            <h3 className='our-brand'><span>OUR TOP BRANDS</span></h3><br />
                            <div className="logo-slide-track">
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/american_bio-science.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/neocell-logo_1.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/now.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/jarrow_formulas.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/HealthyOrigins.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/garden-of-life.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/nutricology_1.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/naturally_vitamins_logo.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/north_american_herb_and_spice_logo_1.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/new-chapter.jpg?v=1610924603" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/life-extension.jpg?v=1610924647" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/doctors-best.jpg?v=1610924675" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/Inholtra_logo_1.jpg?v=1610973367" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/Emertia_logo.jpg?v=1610973367" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/bio-nutrition.jpg?v=1610973295" alt="" />
                                </div>
                                <div className="slide">
                                    <img src="https://cdn.shopify.com/s/files/1/0525/8536/5658/files/BHI_Logo_aea9535c-2101-4a79-bcdf-1e46f555f124.jpg?v=1610973295" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    );
}