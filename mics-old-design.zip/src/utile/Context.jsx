import React, { createContext } from 'react';

const MyContext = createContext();

export default MyContext;