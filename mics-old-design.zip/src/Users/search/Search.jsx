import React from 'react';
import './search.css';
import { useNavigate } from 'react-router-dom';

function Search() {

    const navigate = useNavigate();

    function handleSearch(e){
        e.preventDefault()
        navigate('/job-search')
    }

    return (
        <>
            <div className="mt-5 mb-5">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <form className="dis-form" onSubmit={handleSearch}>
                                <input
                                    className="form-control input-box"
                                    type="search" 
                                    placeholder="What are you looking for?" 
                                    aria-label="Search" 
                                    />
                                    
                                <button className="search-btn px-5 py-2" type="submit">Search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Search;