import React, { useEffect, useState } from "react";
import "./signup.css";
import Header from "../header/Header";
import Footer from "../footer/Footer";
import { NavLink, useNavigate } from 'react-router-dom';
import experience from './experience.png';
import fresher from './fresher.png';
import axios from "axios";
import baseUrl from "../../js/api";

function Signup() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const initialValues = {
    fullname: "",
    email: "",
    phone: "",
    password: "",
    workStatus: "",
    resume: null,
  };

  const [signup, setSignup] = useState(initialValues);
  const [showPassword, setShowPassword] = useState(true);
  const [errors, setErrors] = useState({});
  const [ResponseError, setResponseError] = useState('');
  const navigate = useNavigate()

  function handleInputField(e) {
    const { name, value, type, files } = e.target;
    let error = "";

    if (type !== "file") {
      switch (name) {
        case "fullname":
          error = value.trim() === "" ? "Full Name is required" : "";
          break;
        case "email":
          error = /^\S+@\S+\.\S+$/.test(value) ? "" : "Invalid email address";
          break;
        case "phone":
          error = /^[0-9]{10}$/.test(value) ? "" : "Invalid phone number";
          break;
        case "password":
          error = value.length < 6 ? "Password must be at least 6 characters" : "";
          break;
        case "workStatus":
          error = value === "" ? "Work Status is required" : "";
          break;
        default: 
          break;
      }+

      setErrors({ ...errors, [name]: error });
      setSignup({ ...signup, [name]: value });
    } else {
      setSignup({ ...signup, [name]: files[0] });
    }
  }

  function handleSignup(e) {
    e.preventDefault();
    const signupEndPoint = 'registration'
    const formData = new FormData()
    formData.append('name', signup.fullname)
    formData.append('number', signup.phone)
    formData.append('email', signup.email)
    formData.append('password', signup.password)
    formData.append('experience', signup.workStatus)
    formData.append('resume', signup.resume)
    axios
      .post(baseUrl + signupEndPoint, formData)
      .then((response) => {
        const responseData = response.data.data
        localStorage.setItem('userId',responseData._id) 
        localStorage.setItem('userToken', responseData.token)
        navigate('/')
      }).catch((error) => {
        if (error.response.data.msg) {
          const responseError = error.response.data.status
          if (responseError == 409) {
            setResponseError('This Account Already Existe')
          }
          setTimeout(()=>{
            setResponseError('')
          },3000)
        }
        console.log(error);
      })
  }

  return (
    <>
      <Header />
      <div className="container">
        <div className="row">
          <div className="col-md-12 text-center">
            <h6 className="sign-heading mt-5">
              Sign-up and apply in less than 2 minutes
            </h6>
            <p className="text-muted">1,50,000+ companies hiring on MICS</p>
          </div>

          <div className="bg-white box-bg mt-4">
            <div className="col-md-12">
              <form onSubmit={(e) => handleSignup(e)}>

                {/* FullName */}
                <label className="form-label label-heading mt-3">
                  Full Name <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  name="fullname"
                  className={`form-control form-holder ${errors.fullname ? "is-invalid" : ""}`}
                  placeholder="What is your name?"
                  required
                  value={signup.fullname}
                  onChange={handleInputField}
                />
                <div className="invalid-feedback">{errors.fullname}</div>

                {/* Email */}
                <label className="form-label label-heading mt-3">
                  Email <span className="text-danger">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  className={`form-control form-holder ${errors.email ? "is-invalid" : ""}`}
                  placeholder="Tell us your Email ID"
                  required
                  value={signup.email}
                  onChange={handleInputField}
                />
                <div className="invalid-feedback">{errors.email}</div>

                {/* Mobile Number */}
                <label className="form-label label-heading mt-3">
                  Mobile number <span className="text-danger">*</span>
                </label>
                <div className="input-group mb-3">
                  <span className="input-group-text" id="basic-addon1">+91</span>
                  <input
                    type="tel"
                    name="phone"
                    className={`form-control form-holder ${errors.phone ? "is-invalid" : ""}`}
                    placeholder="Mobile Number"
                    required
                    maxLength={10}
                    value={signup.phone}
                    onChange={handleInputField}
                  />
                </div>
                <div className="invalid-feedback">{errors.phone}</div>

                {/* Create Password */}
                <label className="form-label mt-3 label-heading">
                  Password <span className="text-danger">*</span>
                </label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showPassword ? 'password' : 'text'}
                    name="password"
                    className={`form-control form-holder ${errors.password ? "is-invalid" : ""}`}
                    placeholder="Create a password"
                    required
                    value={signup.password}
                    onChange={handleInputField}
                  />
                  {showPassword ? (
                  <div
                    className="bi bi-eye-slash-fill"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute',
                      right: '30px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      cursor: 'pointer',
                    }}
                  ></div>
                  ):(
                    <div
                    className="bi bi-eye-fill"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute',
                      right: '30px',
                      top: '50%',
                      transform: 'translateY(-50%)',
                      cursor: 'pointer',
                    }}
                  ></div>
                  )}
                </div>
                <div className="invalid-feedback">{errors.password}</div>

                {/* Work Status */}
                <div className="row">
                  <label className="form-label mt-3 label-heading">
                    Work Status <span className="text-danger">*</span>
                  </label>
                  <div className="col-md-6 d-flex justify-content-start">
                    <input
                      type="radio"
                      className="btn-check"
                      name="workStatus"
                      id="option5"
                      value="experienced"
                      onChange={handleInputField}
                      checked={signup.workStatus === "experienced"}
                      required
                    />

                    <label className="btn work-status" htmlFor="option5" >
                      I'm experienced. <img src={experience} alt="" />
                    </label>
                  </div>
                  <div className="col-md-6 d-flex justify-content-around">
                    <input
                      type="radio"
                      className="btn-check"
                      name="workStatus"
                      id="option6"
                      value="fresher"
                      onChange={handleInputField}
                      checked={signup.workStatus === "fresher"}
                      required
                    />

                    <label className="btn work-status" htmlFor="option6">
                      I'm a fresher. <img src={fresher} alt="" />
                    </label>
                  </div>
                </div>

                {/* Resumem uploading */}
                <label className="form-label mt-3 label-heading">
                  Resume
                </label>
                <input
                  type="file"
                  name="resume"
                  className="form-control form-holder"
                  onChange={handleInputField}
                />
                <p className="term-text text-muted">
                  <span className="text-dark">Recruiters give first preference to candidates who have a resume</span> <br />
                  <span className="text-primary">DOC, DOCx, PDF, RTF | Max: 2 MB</span>
                </p>
                <p style={{color:'red'}}>
                  {ResponseError?ResponseError:''}
                </p>
                {/* Term & Conditions */}
                <p className="term-text mt-4 text-muted">
                  <input className="form-check-input me-2 fs-6" type="checkbox" id="flexCheckChecked" required />
                  By signing up, you agree to our{" "}
                  <span className="text-primary">Terms and Conditions</span>.
                </p>

                {/* Submit Button */}
                <button className="sign-button w-100 px-5 py-2 mt-2" >
                  Sign up <i className="bi bi-arrow-right"></i>
                </button>
                <p className="text-center mt-4 text-muted">
                  Already registered?
                  <span
                    className="text-primary fw-bold"
                    style={{ cursor: "pointer" }}
                  >
                    {" "}
                    <NavLink to='/login'> Login </NavLink>
                  </span>
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Signup;
