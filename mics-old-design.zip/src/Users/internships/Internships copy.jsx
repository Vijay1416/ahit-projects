import React from 'react';
import './internships.css';
import {NavLink} from 'react-router-dom';

function Internships() {
    return ( 
        <>
        <div className="container mt-5">
  <div className="row">
    <div className="col-md-12">
      <h3 className="heading-text">Internships</h3>
      <div className="d-flex justify-content-between">
      <p className="text-muted inter-text">Apply to 10,000+ internships for free</p>
      <NavLink to="#" className="text-decoration-none tag-text">View all internships <i className="bi bi-arrow-right"></i></NavLink>
    </div>
    </div>

    <h5 className="mt-3">Popular cities</h5>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/wfh.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Work From Home</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/indiagate.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Delhi/NCR</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/mosque.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Hyderabad</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/bangalore.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Bangalore</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/mumbai.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Mumbai</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/chennai.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Chennai</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/kolkata.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Kolkata</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/tower.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">International</p>
    </div>
  </div>

  <h5 className="mt-3">Popular Categories</h5>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/parttime.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Part Time</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/engineering.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Engineering</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/ngo.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">NGO</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/mba.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Business/MBA</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/design.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Design</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/science.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Science</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/camera.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Media</p>
  </div>
</div>
  <div className="col text-center">
    <div className="city-box">
    <img src="/src/assets/images/reading.png" alt="Work From Home" className="img-fluid city-img mt-3" />
    <p className="mt-2 city-font">Humanities</p>
  </div>
</div>
  </div>
</div>


<div className="container mt-5">
  <div className="row">
    <div className="col-md-12">
      <h3 className="heading-text">Trainings</h3>
      <div className="d-flex justify-content-between">
      <p className="text-muted inter-text">Learn new-age skills on the go</p>
      <NavLink to="#" className="text-decoration-none tag-text">View all internships <i className="bi bi-arrow-right"></i></NavLink>
    </div>
    </div>

    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/web.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Web Development</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/py.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Programming with Python</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/dm.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Digital Marketing</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/c++.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Programming with C and C++</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/learning.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Machine Learning</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/excel.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Advanced Excel</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/cad.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Auto CAD</p>
    </div>
  </div>
    <div className="col text-center">
      <div className="city-box">
      <img src="/src/assets/images/science.png" alt="Work From Home" className="img-fluid city-img mt-3" />
      <p className="mt-2 city-font">Data Science</p>
    </div>
  </div>


  </div>
</div>
        </>
     );
}

export default Internships;