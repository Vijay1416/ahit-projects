import React from 'react';
import './internships.css';
import { NavLink } from 'react-router-dom';

function Internships() {
  return (
    <>
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-12">
            <h3 className="heading-text">Internships</h3>
            <div className="d-flex justify-content-between">
              <p className="text-muted inter-text">Apply to 10,000+ internships for free</p>
              <NavLink to="#" className="text-decoration-none tag-text">View all internships <i className="bi bi-arrow-right"></i></NavLink>
            </div>
          </div>

          <PopularCity />

          <Categories />

        </div>
      </div>

      <Training />

    </>
  );
}

export default Internships;

function PopularCity() {

  const cities = [
    { image: '../../src/assets/images/wfh.png', title: 'Work From Home' },
    { image: '../../src/assets/images/indiagate.png', title: 'Delhi/NCR' },
    { image: '../../src/assets/images/mosque.png', title: 'Hyderabad' },
    { image: '../../src/assets/images/bangalore.png', title: 'Bangalore' },
    { image: '../../src/assets/images/mumbai.png', title: 'Mumbai' },
    { image: '../../src/assets/images/chennai.png', title: 'Chennai' },
    { image: '../../src/assets/images/kolkata.png', title: 'Kolkata' },
    { image: '../../src/assets/images/tower.png', title: 'International' },
  ]

  return (
    <>
      <h5 className="mt-3">Popular cities</h5>
      {cities.map((city, index) => (
        <div className="col text-center" key={index}>
          <div className="city-box">
            <img src={city.image} alt="Work From Home" className="img-fluid city-img mt-3" />
            <p className="mt-2 city-font"> {city.title}</p>
          </div>
        </div>
      ))}
    </>
  );
}

function Categories() {

  const categories = [
    { image: '../../src/assets/images/parttime.png', title: 'Part Time' },
    { image: '../../src/assets/images/engineering.png', title: 'Engineering' },
    { image: '../../src/assets/images/ngo.png', title: 'NGO' },
    { image: '../../src/assets/images/mba.png', title: 'MBA' },
    { image: '../../src/assets/images/design.png', title: 'Design' },
    { image: '../../src/assets/images/science.png', title: 'Science' },
    { image: '../../src/assets/images/camera.png', title: 'Media' },
    { image: '../../src/assets/images/reading.png', title: 'Humanities' },
  ]

  return (
    <>
      <h5 className="mt-3">Popular Categories</h5>

      {categories.map((category, index) => (
        <div className="col text-center" key={index}>
          <div className="city-box">
            <img src={category.image} alt="Work From Home" className="img-fluid city-img mt-3" />
            <p className="mt-2 city-font">{category.title}</p>
          </div>
        </div>
      ))}
      
    </>
  );
}


function Training() {

  const training = [
    { image: '../../src/assets/images/web.png', title: 'Web Development' },
    { image: '../../src/assets/images/py.png', title: 'Programming with Python' },
    { image: '../../src/assets/images/dm.png', title: 'Digital Marketing' },
    { image: '../../src/assets/images/c++.png', title: 'Programming with C and C++' },
    { image: '../../src/assets/images/learning.png', title: 'Machine Learning' },
    { image: '../../src/assets/images/excel.png', title: 'Advanced Excel' },
    { image: '../../src/assets/images/cad.png', title: 'Auto CAD' },
    { image: '../../src/assets/images/science.png', title: 'Data Science' },
    
  ]

  return (
    <>
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-12">
            <h3 className="heading-text">Trainings</h3>
            <div className="d-flex justify-content-between">
              <p className="text-muted inter-text">Learn new-age skills on the go</p>
              <NavLink to="#" className="text-decoration-none tag-text">View all internships <i className="bi bi-arrow-right"></i></NavLink>
            </div>
          </div>

          {training.map((data, index) => (
            <div className="col text-center" key={index}>
              <div className="city-box">
                <img src={data.image} alt="Work From Home" className="img-fluid city-img mt-3" />
                <p className="mt-2 city-font">{data.title}</p>
              </div>
            </div>
          ))}

        </div>
      </div>

    </>
  );
}