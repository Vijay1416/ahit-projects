import React from 'react';
import './hiringComapnies.css'
import { NavLink } from 'react-router-dom';
import img1 from '/src/assets/images/milogo.png';
import img2 from '/src/assets/images/Wplogo.png';

function HiringCompanies() {


    return (
        <>
            <div className="container mt-5">
                <h3 className="heading-text text-center">Actively Hiring Companies</h3>
                <div className="row">
                    <Component name='MICS' img={img1} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='Wipro' img={img2} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='MICS' img={img1} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='Wipro' img={img2} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='MICS' img={img1} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='Wipro' img={img2} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='MICS' img={img1} links={'View jobs'} title={'Global leader in technology services.'} />
                    <Component name='Wipro' img={img2} links={'View jobs'} title={'Global leader in technology services.'} />
                </div>
                <NavLink to="#">
                    <div className="mt-4 text-center">
                        <button className="px-5 py-2 job-btn">View Companies <i className="bi bi-arrow-right"></i></button>
                    </div>
                </NavLink>
            </div>
        </>
    )
}

export default HiringCompanies


function Component(props) {
    return (
        <>
            <div className="col-md-3 mt-3 dis-col">
                <NavLink to="#" className="text-decoration-none">
                    <div className="card text-center cmpy-card">
                        <img src={props.img} className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                        <div className="card-body text-center">
                            <h5 className="card-title cmpy-text mt-2">{props.name}</h5>
                            <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>
                            <p className="rv-text">{props.title}</p>
                            <p className="vw-btn">{props.links} <i className="bi bi-arrow-right"></i></p>
                        </div>
                    </div>
                </NavLink>
            </div>
        </>
    )
}