import React from 'react';
import './hiringComapnies.css'
import { NavLink } from 'react-router-dom';

function HiringCompanies() {

    
    return (
        <>
            <div className="container mt-5">
                <h3 className="heading-text text-center">Actively Hiring Companies</h3>
                <div className="row">
                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/milogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">MICS</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>


                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                
                                <img src="/src/assets/images/wplogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">Wipro</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>


                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/milogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">MICS</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>


                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/wplogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">Wipro</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>
                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/milogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">MICS</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>

                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/wplogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">Wipro</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>

                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>
                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/milogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">MICS</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>

                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>

                    <div className="col-md-3 mt-3 dis-col">
                        <NavLink to="#" className="text-decoration-none">
                            <div className="card text-center cmpy-card">
                                <img src="/src/assets/images/wplogo.png" className="card-img-top img-fluid wp-logo mt-4" alt="Company" />
                                <div className="card-body text-center">
                                    <h5 className="card-title cmpy-text mt-2">Wipro</h5>
                                    <p className="card-text rv-text mt-3"><i className="bi bi-star-fill text-warning"></i> 3.9 | 23.8K+<br />Reviews</p>

                                    <p className="rv-text">Global leader in technology services.</p>
                                    <p className="vw-btn">View jobs <i className="bi bi-arrow-right"></i></p>
                                </div>
                            </div>
                        </NavLink>
                    </div>
                </div>
                <NavLink to="#">
                    <div className="mt-4 text-center">
                        <button className="px-5 py-2 job-btn">View Companies <i className="bi bi-arrow-right"></i></button>
                    </div>
                </NavLink>
            </div>
        </>
    )
}

export default HiringCompanies
