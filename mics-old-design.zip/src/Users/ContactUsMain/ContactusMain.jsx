import React from 'react';
import './contactusMain.css';
import Header from '../header/Header';
import Footer from '../footer/Footer';



function ContactusMain() {
    return (
        <>
            <Header />
            <div className="container-fuild contact">
                <h2 className='Contactu-us-title'>Contact us</h2>

                <div className="content">
                    <div className="left-side">
                        <div className="address details">
                            <i className="fas fa-map-marker-alt"></i>
                            <div className="topic">Address</div>
                            <div className="text-one">Gurukripa Enclave, Near IndusInd Bank, </div>
                            <div className="text-one">Besides Raas Mahal Hotel, </div>
                            <div className="text-one">Old Ramgadhmod Bus stand, </div>
                            <div className="text-two">Jaipur (302002).</div>
                        </div>
                        <div className="phone details">
                            <i className="fas fa-phone-alt"></i>
                            <div className="topic">Phone</div>
                           <a href="tel:+91-96640 83783"> <div className="text-one">+91-96640 83783</div> </a>
                           <a href="tel:+91-80057 79031"> <div className="text-two">+91-80057 79031</div> </a>
                        </div>
                        <div className="email details">
                            <i className="fas fa-envelope"></i>
                            <div className="topic">Email</div>
                            <a href="mailto:"><div className="text-one">info@a2groups.org</div></a>
                            {/* <div className="text-two">info.codinglab@gmail.com</div> */}
                        </div>
                    </div>
                    <div className="right-side">
                        <div className="topic-text">Send us a message</div>
                        <p>If you have any work from me or any types of quries related to my tutorial, you can send me message from here. It's my pleasure to help you.</p>
                        <form action="#">
                            <div className="input-box">
                                <input type="text" placeholder="Enter your name" />
                            </div>
                            <div className="input-box">
                                <input type="text" placeholder="Enter your email" />
                            </div>
                            <div className="input-box message-box">
                                <textarea name="" id="" placeholder="Enter your message" />
                            </div>
                            <div className="button">
                                <input type="button" value="Send Now" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default ContactusMain;