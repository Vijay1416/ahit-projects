import React, { useEffect, useState } from 'react';
import './jobRoles.css';
import axios from 'axios';
import baseUrl from '../../js/api';

function JobRoles() {
  const [popularData,setPopularData] = useState([])
  const [currentSlide, setCurrentSlide] = useState(0);

  function handelGetAai() {
    const endPoint = 'unique/post/get/job'
    axios.get(baseUrl+endPoint).then((response)=>{
      setPopularData(response.data.data)
    }).catch((error)=>{
      console.error(error)
    })
  }
useEffect(()=>{
  handelGetAai()
},[])
  const itemsPerPage = 4;
  const totalSlides = Math.ceil(popularData.length / itemsPerPage);

  const handleNextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const handlePrevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  return (
    <>
      <div className="container mt-5">
        <h3 className="heading-text text-center">Discover Jobs Across Popular Roles</h3>
        <div className="role-bg mt-4 testimonial-area">
          <div className="row dis-row">
            <div className="col-md-8">
              <div className="testimonial-content">
                <div className="row">
                {popularData.slice(currentSlide * itemsPerPage, (currentSlide + 1) * itemsPerPage).map((job, index) => (
                  <div key={index} className="col-6 mt-3">
                    <div className="card role-card">
                      <div className="card-body">
                        <h5 className="card-title role-card-text">{job?._id}</h5>
                        <p className="text-muted cd-text">{job?.count} <i className="bi bi-chevron-right role-i"></i></p>
                      </div>
                    </div>
                  </div>
                ))}
                </div>
              </div>
              
              <div className='d-flex justify-content-center mt-5'>
              <i className="bi bi-arrow-left-circle fs-1 me-5" style={{cursor : "pointer"}} onClick={handlePrevSlide} disabled={currentSlide === 0}></i>
              <i className="bi bi-arrow-right-circle fs-1" style={{cursor : "pointer"}} onClick={handleNextSlide} disabled={currentSlide === totalSlides - 1}></i>
              </div>

            </div>
            <div className="col-md-4 mt-3">
              <img src="/src/assets/images/hiring.gif" alt="Job" className="img-fluid cover-img" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default JobRoles;









// import React from 'react';
// import './jobRoles.css';


// function JobRoles() {
//     return (
//         <>
//             <div className="container mt-5">
//                 <h3 className="heading-text text-center">Discover Jobs Accross Popular Roles</h3>
//                 <div className="role-bg mt-4 testimonial-area">
//                     <div className="row dis-row"></div>

//             <div className="col-md-8">
            
//                 <div className="testimonial-content owl-carousel">

//                     <div className="single-testimonial">
                    
//                         <div className="row row-cols-2">

//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Full Stack Developer</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>

//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Mobile/App Development</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>

//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Front End Developer</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>

//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Cyber Security</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>


//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Business Analyst</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>


//                             <div className="col  mt-3">
//                                 <div className="card role-card">
//                                     <div className="card-body">
//                                         <h5 className="card-title role-card-text">Data Scientist</h5>
//                                         <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
                        
//                     </div>                   
//                 </div>                
//             </div>
            
//             <div className="col-md-4 mt-3">
//                             <img src="/src/assets/images/hiring.gif" alt="Job" className="img-fluid cover-img" />
//                         </div>
//                     </div>
//                 </div>
//         </>
//     );
// }

// export default JobRoles;