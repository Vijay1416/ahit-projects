import React from 'react';
import './jobRoles.css'

function JobRoles() {
    return (
        <>
            <div className="container mt-5">
                <h3 className="heading-text text-center">Discover Jobs Accross Popular Roles</h3>
                <div className="role-bg mt-4 testimonial-area">
                    <div className="row dis-row">


                        <div className="col-md-8">
                            <div className="testimonial-content owl-carousel">
                                {/* -- Single Testimonial -- */}
                                <div className="single-testimonial">
                                    <div className="row row-cols-2">
                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Mobile/App Development</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Front End Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Cyber Security</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Business Analyst</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Data Scientist</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div className="col single-testimonial">
                                    <div className="row row-cols-2">
                                        <div className="col mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div className="single-testimonial">
                                    <div className="row row-cols-2">
                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div className="single-testimonial">
                                    <div className="row row-cols-2">
                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div className="col  mt-3">
                                            <div className="card role-card">
                                                <div className="card-body">
                                                    <h5 className="card-title role-card-text">Full Stack Developer</h5>
                                                    <p className="text-muted cd-text">23.3K+ Jobs <i className="bi bi-chevron-right role-i"></i></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                        <div className="col-md-4 mt-3">
                            <img src="/src/assets/images/hiring.gif" alt="Job" className="img-fluid cover-img" />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default JobRoles;