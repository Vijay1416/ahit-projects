import React, { useState, useEffect, useContext } from 'react';
import './header.css';
import micsLogo from '/src/assets/images/milogo.png';
import { NavLink, useNavigate } from 'react-router-dom';
import { LoginContext } from '../ContextApi/ContextApi';
import axios from 'axios';
import baseUrl from '../../js/api';
import { useLocation } from 'react-router-dom/dist';



function Header() {
    const userGetAndPoint = 'user/findBy/'
    const [loginName, setLoginName] = useState('')
    const [menuOpen, setMenuOpen] = useState(false);
    const location = useLocation();
    const navigate = useNavigate();

    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };

    const closeMenu = () => {
        setMenuOpen(false);
    };

    function loginCheck() {
        const userIdCheck = localStorage.getItem('userId')
        if (userIdCheck) {
            axios.get(baseUrl + userGetAndPoint + userIdCheck).then((response) => {
                setLoginName(response.data.data)
            }).catch((error => console.log(error)))
        }
    }
    function handleLogOut() {
        localStorage.clear()
        console.log(location.pathname);
        if (location.pathname === '/') {
            window.location.reload()
        }
        navigate('/')
    }
    function profilePage() {
        navigate('/profile')
    }

    useEffect(() => {
        const handleScroll = () => {
            const header = document.querySelector('.navbar');
            if (window.scrollY > 0) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }
        };

        window.addEventListener('scroll', handleScroll);
        loginCheck()
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);



    return (
        <>
            <header className={`navbar ${menuOpen ? 'open' : ''}`}>
                <NavLink to="/" className="logo">
                    <img src={micsLogo} alt="logo" className="img-fluid logo-img" />
                </NavLink>
                <div className="menu-btn" onClick={toggleMenu}>
                    {menuOpen ? (
                        <div className="fs-1 text-danger fw-bold"><i className="bi bi-x-lg"></i></div>
                    ) : (
                        <div className="menu-btn__lines"></div>
                    )}
                </div>

                <ul className={`menu-items ${menuOpen ? 'open' : ''}`}>

                    <li>
                        <NavLink to="/" className="menu-item first-item" onClick={closeMenu}>
                            Home
                        </NavLink>
                    </li>

                    <li>
                        <NavLink to="#" className="menu-item first-item expand-btn">Jobs</NavLink>
                        <div className="mega-menu sample" style={{ background: 'white' }}>
                            <div className="content">
                                <div className="col pb-4">
                                    <section >
                                        <div className="menu-title">Popular categories</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="/job-search" className="menu-item">IT Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Sales Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">HR Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Marketing Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Engineering</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title">Jobs in demand</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="/job-search" className="menu-item">Freshers Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">MNC Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Remote Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Work from home Jobs</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Part time Jobs</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title">Jobs by location</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="/job-search" className="menu-item">Jobs in Delhi</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs in Jaipur</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs in Chennai</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs in Mumbai</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs in Hydrabad</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title">Explore more jobs</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="/job-search" className="menu-item">Jobs by category</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs by skill</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs by location</NavLink></li>
                                            <li><NavLink to="/job-search" className="menu-item">Jobs by designation</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li>
                        <NavLink to="#" className="menu-item first-item expand-btn">Companies</NavLink>
                        <div className="mega-menu sample">
                            <div className="content" style={{ background: 'white' }}>
                                <div className="col pb-4">
                                    <section>
                                        <div className="menu-title p-2">Explore Categories</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="#" className="menu-item">Unicorn</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">MNC</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Startup</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Internet</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Product based</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title p-2">Explore collections</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="#" className="menu-item">Top Companies</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">IT Companies</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Fintech Companies</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Sponsored Companies</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Featured Companies</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title p-2">Category 3</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="#" className="menu-item">Item 1</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 2</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 3</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 4</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 5</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                                <div className="col">
                                    <section>
                                        <div className="menu-title p-2">Category 4</div>
                                        <ul className="mega-links">
                                            <li><NavLink to="#" className="menu-item">Item 1</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 2</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 3</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 4</NavLink></li>
                                            <li><NavLink to="#" className="menu-item">Item 5</NavLink></li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li>
                        <NavLink to="/contact-us" className="menu-item first-item">
                            Contact Us
                        </NavLink>
                    </li>

                    {
                        loginName ? ('')
                            : (
                                <li>
                                    <div className="dropdown">
                                        <button className="dropbtn">For employers <i className="bi bi-chevron-down"></i> </button>
                                        <div className="dropdown-content">
                                            <NavLink to="/Company/HomePage" target='_blank'>Employer Job Hiring</NavLink>
                                            <NavLink to="/recruit/client-registration-form" target='_blank'>Employer Register</NavLink>
                                        </div>
                                    </div>
                                </li>
                            )
                    }
                    <li>
                        <div className="dropdown-profile">
                            <i className="bi bi-person-circle user-profile"></i>
                            {loginName ? (
                                <>
                                    <span className='user-title'>Hi,  {loginName.name.split(" ", 1)}</span>
                                    <div className="dropdown-options">
                                        <span onClick={() => profilePage()} className='option-title'>Profile</span>
                                        <span className='option-title' onClick={() => handleLogOut()} style={{ cursor: "pointer" }}>Logout</span>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <span className='user-title'>Hi, Hello</span>
                                    <div className="dropdown-options">
                                        <NavLink to='/login'> <span className='option-title'>Login</span> </NavLink>
                                        <NavLink to='/signup'> <span className='option-title'>Signup</span> </NavLink>
                                    </div>
                                </>
                            )}
                        </div>
                    </li>
                </ul>
            </header>

        </>
    );
}

export default Header;