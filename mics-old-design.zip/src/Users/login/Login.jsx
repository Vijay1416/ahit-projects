import React, { useContext, useEffect, useState } from 'react';
import './login.css';
import Header from "../header/Header";
import Footer from "../footer/Footer";
import { NavLink, useNavigate } from 'react-router-dom';
import { LoginContext } from '../ContextApi/ContextApi';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import baseUrl from '../../js/api';
import axios from 'axios';

function Login() {
    const [showPas, setShowPas] = useState(true);
    const [MSG, setMSG] = useState()
    const [login, setLogin] = useState({
        email: "",
        password: ''
    });

    const endPoint = 'login'
    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);


    const navigate = useNavigate();



    function handleInputFeild(e) {
        setLogin({ ...login, [e.target.name]: e.target.value });
    }

    function handleLogin(e) {
        e.preventDefault();
        axios.post(baseUrl + endPoint, login).then((response) => {
            const data = response.data.data
            localStorage.setItem('userToken', data.token)
            localStorage.setItem('userId', data._id)
            navigate('/')
        }).catch(error => {
            const responseError = error.response.data.msg
            if (responseError === 'user not found') {
                setMSG('Please use a valid number')
            } else if (responseError === 'Wrong password') {
                setMSG("That's an invalid password")
            }
            setTimeout(() => {
                setMSG('')
            }, 5000);
            console.log(error)
        })
    }
    return (
        <>
            <Header />
            <div className="container">
                <div className="row">
                    <div className="col-md-12 text-center">
                        <h6 className="sign-heading mt-5">
                            Login and find more jobs and apply
                        </h6>
                        <p className="text-muted">1,50,000+ companies hiring on MICS</p>
                    </div>
                    <div className="bg-white box-bg mt-4">
                        <div className="col-md-12">
                            <form method='POST' className="mt-4" onSubmit={handleLogin}>

                                {/* <label htmlFor="phone" className="form-label label-heading">
                                    Mobile Number
                                </label>

                                <div className="input-group mb-3">
                                    <span className="input-group-text" id="basic-addon1">+91</span>
                                    <input
                                        type="tel"
                                        className="form-control form-holder"
                                        id="phone"
                                        placeholder='Enter Your Number'
                                        name='number'
                                        value={login.number}
                                        onChange={handleInputFeild}
                                        required
                                        maxLength={10}
                                    />
                                </div> */}

                                <label htmlFor="email" className="form-label label-heading">
                                    Email
                                </label>

                                <div className="input-group mb-3">
                                    <input
                                        type="email"
                                        className="form-control form-holder"
                                        id="email"
                                        placeholder='Enter Your email'
                                        name='email'
                                        value={login.email}
                                        onChange={handleInputFeild}
                                        required
                                    />
                                </div>

                                <label
                                    htmlFor="password"
                                    className="form-label mt-3 label-heading"
                                >
                                    Password
                                </label>
                                <div style={{ position: 'relative' }}>
                                    <input
                                        type={showPas ? 'password' : 'text'}
                                        className="form-control form-holder"
                                        id="password"
                                        placeholder="Enter Your Password"
                                        name='password'
                                        value={login.password}
                                        onChange={handleInputFeild}
                                        required
                                    />
                                    {showPas ? (
                                        <i
                                            className="bi bi-eye-slash-fill"
                                            onClick={() => setShowPas(!showPas)}
                                            style={{
                                                position: 'absolute',
                                                right: '15px',
                                                top: '50%',
                                                transform: 'translateY(-50%)',
                                                cursor: 'pointer',
                                            }}
                                        ></i>
                                    ) : (
                                        <i
                                            className="bi bi-eye-fill"
                                            onClick={() => setShowPas(!showPas)}
                                            style={{
                                                position: 'absolute',
                                                right: '15px',
                                                top: '50%',
                                                transform: 'translateY(-50%)',
                                                cursor: 'pointer',
                                            }}
                                        ></i>
                                    )}

                                </div>
                                <span style={{ color: 'red' }}>{MSG ? MSG : ''}</span>
                                <p className="text-primary text-end mt-4 mb-3 modal-forget">
                                    <ForgotPasswordModal />
                                </p>

                                <button type='submit' className="sign-button w-100 px-5 py-2 mt-4">
                                    Login <i className="bi bi-arrow-right"></i>
                                </button>

                                <p className="text-center mt-4 text-muted">
                                    Don't have account? Create Account
                                    <span
                                        className="text-primary"
                                        id="loginmodal"
                                        style={{ cursor: "pointer" }}
                                    >
                                        <NavLink to='/signup'>
                                            <span className='ps-1 fw-bold'>Signup</span>
                                        </NavLink>
                                    </span>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default Login;

function ForgotPasswordModal() {
    const [show, setShow] = useState(false);
  
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <>
        <span onClick={handleShow}>
        Forgot Password?
        </span>
  
        <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>Forgot Password</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
  
              <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                <Form.Label>Enter Your Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="name@example.com"
                  autoFocus
                />
              </Form.Group>
  
            </Form>
  
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button type='submit' variant="success" onClick={handleClose}>
              Send Forgot Password Link
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }