import React, { useEffect } from 'react';
import Header from '../header/Header';
import Search from '../search/Search';
import HireJob from '../jobportal/JobPortal';
import Internships from '../internships/Internships';
import DreamJob from '../dreamJob/DreamJob';
import JobRoles from '../jobRoles/JobRoles';
import HiringCompanies from '../hiringCompanies/HiringCompanies';
import Footer from '../footer/Footer';

function Home() {

    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);

    return (
        <>
            <Header />
            <Search />
            <HireJob />
            <Internships />
            <DreamJob />
            <JobRoles />
            <HiringCompanies />
            <Footer />
        </>
    );
}

export default Home;