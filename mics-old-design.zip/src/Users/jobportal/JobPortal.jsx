import React from 'react';
import './jobportal.css';
import jobImage from '/src/assets/images/job.png';
import { NavLink } from 'react-router-dom';
import { companyAuth, userAuh } from '../../js/checkAuth';

function JobPortal() {
    return (
        <>
            <div className="portal-bg">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12 text-center mb-3">
                            <h3 className="heading-text">India’s Largest Job Portal</h3>
                            <p className="text-muted">WorkIndia helps you hire staff in 2 days</p>

                            <img src={jobImage} alt="Job Portal" className="img-fluid" />

                            {
                                !companyAuth & !userAuh ?
                                    (<div className="d-btn mt-4">
                                        <NavLink to='/Company/HomePage' target='_blank'>
                                            <button className="px-5 py-2 rounded shadow border-0 text-white port-btn">Hire Now</button>
                                        </NavLink>

                                        <NavLink to='/job-search'>
                                            <button className="px-5 py-2 rounded shadow border-0 text-white jb-btn port-btn">Get a Job</button>
                                        </NavLink>
                                    </div>)
                                    :
                                    ("")
                            }
                            {
                                !userAuh ?
                                ('')
                                :
                                    (
                                        <>
                                            <div className="d-btn mt-4">
                                                <NavLink to='/job-search'>
                                                    <button className="px-5 py-2 rounded shadow border-0 text-white jb-btn port-btn">Get a Job</button>
                                                </NavLink>
                                            </div>
                                        </>
                                    )
                            }

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default JobPortal;