import React from 'react';
import './dreamJob.css';
import { NavLink } from 'react-router-dom';

function DreamJob() {

    const dreamJob = [
        { image: '../../src/assets/images/home.png', title: 'Work From Home' },
        { image: '../../src/assets/images/mnc.png', title: 'MNC' },
        { image: '../../src/assets/images/startup.png', title: 'StartUp' },
        { image: '../../src/assets/images/graph.png', title: 'Data Sci..' },
        { image: '../../src/assets/images/project.png', title: 'Project M' },
        { image: '../../src/assets/images/analytic.png', title: 'Analytic' },
        { image: '../../src/assets/images/cloud.png', title: 'Fortune' },
        { image: '../../src/assets/images/setting.png', title: 'Software' },
        { image: '../../src/assets/images/degree.png', title: 'Freshers' },
        { image: '../../src/assets/images/hr.png', title: 'Human' },
        { image: '../../src/assets/images/home.png', title: 'Temp WFH' },
        { image: '../../src/assets/images/startup.png', title: 'StartUp' },
    ]

    return (
        <>
            <div className="dm-bg  mt-5">
                <div className="container">
                    <div className="row">

                        <div className="col-md-12 text-center mt-3 mb-3">
                            <h3 className="heading-text">Find Your Dream Job</h3>
                            <p className="text-muted">5 lakh+ jobs for you to explore</p>
                        </div>

                        {dreamJob.map((job, index) => (
                            <div className="col-md-2 col mt-3" key={index}>
                                <NavLink to="#" className="text-decoration-none">
                                    <div className="dm-job">
                                        <img src={job.image} alt="wfh" className="img-fluid icon-img" />
                                        <h6 className="ms-2  text-muted text-size">{job.title}<i className="bi bi-chevron-double-right icon"></i></h6>
                                    </div>
                                </NavLink>
                            </div>
                        ))}

                    </div>
                </div>
            </div>
        </>
    );
}

export default DreamJob;