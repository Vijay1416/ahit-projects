import React, { createElement, useEffect, useRef, useState } from 'react'
import Header from "../header/Header";
import './profile.css';
import Footer from '../footer/Footer'
import { Link } from 'react-router-dom';
import axios from 'axios';
import baseUrl from '../../js/api';
import { useNavigate } from 'react-router-dom/dist';
import Modal from "react-bootstrap/Modal";
import Select from 'react-select';
import makeAnimated from 'react-select/animated';



function profile() {
    const [profileDetails, setProfileDetails] = useState({})
    const navigate = useNavigate()
    const userId = localStorage.getItem('userId')
    const userFindEndPoint = 'user/findBy/'
    function getProfileDetails() {
        axios.get(baseUrl + userFindEndPoint + userId).then((response) => {
            setProfileDetails(response.data.data)
        }).catch((error) => {
            console.log(error);
        })
    }
    useEffect(() => {
        if (!userId) {
            navigate('/')
        }
        getProfileDetails()
    }, [])
    const scrollToResume = () => {
        if (resumeRef.current) {
            resumeRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToHeadline = () => {
        if (headlineRef.current) {
            headlineRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToKeySkill = () => {
        if (keyskillRef.current) {
            keyskillRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToEducation = () => {
        if (educationRef.current) {
            educationRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToITSkill = () => {
        if (itskillRef.current) {
            itskillRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToProjects = () => {
        if (projectsRef.current) {
            projectsRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToSummary = () => {
        if (summaryRef.current) {
            summaryRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToAccomplish = () => {
        if (accomplishRef.current) {
            accomplishRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToCareerProfile = () => {
        if (careerprofileRef.current) {
            careerprofileRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const scrollToPersonal = () => {
        if (personalRef.current) {
            personalRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };
    return (
        <>
            <Header />
            <TopSection user={profileDetails} />
            <div className="container">
                <div className="row">
                    <div className="col-md-3 mt-3">
                        <div className="quick-link-box links-box-dply">
                            <h5 className="qk-heading">Quick Links</h5>
                            <Link to="#resume" className="text-decoration-none" onClick={scrollToResume}>
                                <QuickLinks mainheading="Resume" update="Update" />
                            </Link>
                            <Link to="#handle" className="text-decoration-none" onClick={scrollToHeadline}>
                                <QuickLinks mainheading="Resume headline" />
                            </Link>
                            <Link to="#keyskill" className="text-decoration-none" onClick={scrollToKeySkill}>
                                <QuickLinks mainheading="Key skills" />
                            </Link>
                            <Link to="#education" className="text-decoration-none" onClick={scrollToEducation}>
                                <QuickLinks mainheading="Education" update="Add" />
                            </Link>
                            <Link to="#itskill" className="text-decoration-none" onClick={scrollToITSkill}>
                                <QuickLinks mainheading="IT skills" update="Add" action="" />
                            </Link>
                            <Link to="#projects" className="text-decoration-none" onClick={scrollToProjects}>
                                <QuickLinks mainheading="Projects" update="Add" />
                            </Link>
                            <Link to="#summary" className="text-decoration-none" onClick={scrollToSummary}>
                                <QuickLinks mainheading="Profile summary" update="Add" />
                            </Link>
                            <Link to="#accomplish" className="text-decoration-none" onClick={scrollToAccomplish}>
                                <QuickLinks mainheading="Accomplishments" />
                            </Link>
                            <Link to="#careerprofile" className="text-decoration-none" onClick={scrollToCareerProfile}>
                                <QuickLinks mainheading="Career profile" />
                            </Link>
                            <Link to="#personal" className="text-decoration-none" onClick={scrollToPersonal}>
                                <QuickLinks mainheading="Personal details" />
                            </Link>

                        </div>
                    </div>

                    <div className="col-md-9 mt-3">
                        <ResumeBox resume={profileDetails.resume} />
                        <ResumeHeadline />
                        <KeySkills keySkill={profileDetails?.skill} />
                        <Employement />
                        <Education />
                        <Skills />
                        <Projects />
                        <ProileSummery />
                        <div className="quick-link-box">
                            <Accomplishments
                                head="Accomplishments"
                                title="Online profile"
                                content="Add link to your projects (e.g. Github links etc.)."
                            />{" "}
                            <hr style={{ marginBottom: "30px" }} />
                            <Accomplishments
                                title="Work sample"
                                content="Add link to your projects (e.g. Github links etc.)."
                            />{" "}
                            <hr style={{ marginBottom: "30px" }} />
                            <Accomplishments
                                title="White paper / Research publication / Journal entry"
                                content="Add links to your online publications."
                            />{" "}
                            <hr style={{ marginBottom: "30px" }} />
                            <Accomplishments
                                title="Presentation"
                                content="Add links to your online presentations (e.g. Slideshare presentation links etc.)."
                            />{" "}
                            <hr style={{ marginBottom: "30px" }} />
                            <Accomplishments
                                title="Patent"
                                content="Add details of patents you have filed."
                            />{" "}
                            <hr style={{ marginBottom: "30px" }} />
                            <Accomplishments
                                title="Certification"
                                content="Add details of certifications you have achieved/completed"
                            />
                        </div>
                        <Careerprofile />
                        <Personaldetails />
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default profile


function TopSection(props) {
    const [modalShow, setModalShow] = useState(false);
    const user = props?.user
    const { resume, profilePic } = props.user
    const formattedProfilePic = profilePic ? baseUrl + profilePic.replace(/\\/g, '/') : '';
    return (
        <>
            <div className="container top_section">
                <div className="row">
                    <div className="col-md-3 text-center">
                        <div className="top_left">
                            {/* <form action="upload.php" method="post" encType="multipart/form-data"> */}
                            <label htmlFor="fileToUpload">
                                <div className="profile-pic" style={{ backgroundImage: `url(${user.profilePic ? formattedProfilePic : '//static.naukimg.com/s/5/105/i/displayProfilePlaceholder.png'})` }}>
                                    <span className="glyphicon glyphicon-camera"></span>

                                </div>
                            </label>
                            {/* <input type="File" name="fileToUpload" id="fileToUpload" /> */}
                            {/* </form> */}
                        </div>
                    </div>
                    <div className="col-md-7">
                        <div className="middle_section">
                            <p className='profile_name'>{user ? user?.name : 'Mr'}<span
                                className="bi bi-pencil"
                                onClick={() => setModalShow(true)}
                            ></span></p>
                        </div>
                        <hr />
                        <div className='aslads'>
                            <div className="middle_down_sec">
                                <p className='profile_loc'> <span className='bi bi-geo-alt'></span> {user.location ? user?.location : 'India'} </p>
                                <p className='profile_loc'> <span className="bi bi-briefcase"></span> {user.experience ? user?.experience : "Fresher"}</p>
                                <p className='profile_loc'> <span className='bi bi-handbag'></span> {user.availability ? user.availability : "Add availability to join"}</p>
                            </div>
                            <div className="line" />
                            <div className="middle_down_sec">
                                <p className='profile_loc'> <span className="bi bi-telephone"></span> {user?.number} <span className='icon tick'></span></p>
                                <p className='profile_loc'> <span className="bi bi-envelope"></span> {user?.email} {user.isVerify ? <span>&#10003;</span> : ''}</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        {/* <h1>hello</h1> */}
                    </div>
                </div>
            </div>
            <ProfileEditModal show={modalShow} onHide={() => setModalShow(false)} title="Basic Details" />
        </>
    )
}




const QuickLinks = (props) => {
    return (
        <>

            <div className='qk-links-display' style={{ marginBottom: '10px' }} id='quick' >

                <p className='main-heading'>{props.mainheading}</p>
                <p className='up-fnt-sz'>{props.update}</p>

            </div>

        </>
    );
}

const ResumeBox = (props) => {
    const resumeRef = useRef(null);
    const handleDownload = () => {
        const resumeUrl = baseUrl + props.resume
        const linkDownload = document.createElement('a')
        linkDownload.href = resumeUrl
        linkDownload.target = '__blanck'
        linkDownload.download = resumeUrl;
        document.body.appendChild(linkDownload)
        linkDownload.click();
        document.body.removeChild(linkDownload)
    }
    return (
        <>
            <div className='quick-link-box' id="resume" ref={resumeRef}>
                <h5 className='qk-heading'>Resume</h5>
                <p className='res-para-fnt'>Resume is the most important document recruiters look for. Recruiters generally do not look at profiles without resumes.</p>
                <div className='up-state-main-box'>
                    <div>
                        <p className='static-para-fnt'>{props ? props.resume : ''}</p>
                        <p className='upload-date-sz'>Uploaded on Jan 16, 2024</p>
                    </div>

                    <div>
                        <i className="bi bi-download res-icon-box" onClick={() => handleDownload()}></i>
                        <i className="bi bi-trash-fill res-icon-box ms-2"></i>
                    </div>
                </div>

                {
                    resumeRef ? (
                        ''
                    ) : (
                        <div className='resume-upbox-vw'>
                            <div className='text-center'>
                                <input type="file" className='up-resbtn-vw' />
                                <p className='up-resm-fntsz'>Supported Formats: doc, docx, rtf, pdf, upto 2 MB</p>
                            </div>
                        </div>
                    )
                }
            </div>
        </>
    )
}

const ResumeHeadline = () => {
    const headlineRef = useRef(null);
    const [headlineModal, setHeadlineModal] = React.useState(false);

    return (
        <>
            <div className="quick-link-box" id="handle" ref={headlineRef}>
                <div className="d-flex">
                    <h5 className="qk-heading">Resume headline</h5>
                    <i
                        className="bi bi-pencil-square ms-2"
                        style={{ cursor: "pointer" }}
                        onClick={() => setHeadlineModal(true)}
                    ></i>
                </div>
                <div>
                    <p className="res-para-fnt">
                        Looking for jobs requiring following skills: Web
                        Development,Html,Css,Javascript,React Js,Node Js,Express
                        Js,Mongodb,Git,Sql,Json,Github
                    </p>
                </div>
            </div>

            <ProfileEditModal
                show={headlineModal}
                onHide={() => setHeadlineModal(false)}
                title="Resume Headline"
            />
        </>
    );
}

const KeySkills = (props) => {
    const { keySkill } = props
    const keyskillRef = useRef(null);
    const [keyskillModal, setKeyskillModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box" id="keyskill" ref={keyskillRef}>
                <div className="d-flex">
                    <h5 className="qk-heading">Key skills</h5>
                    <i
                        className="bi bi-pencil-square ms-2"
                        style={{ cursor: "pointer" }}
                        onClick={() => setKeyskillModal(true)}
                    ></i>
                </div>
                <div className="headline-dtl mt-3">
                    {
                        keySkill ? (
                            keySkill?.map((sk) => (
                                <p className="key-skill-box ms-2">{sk}</p>
                            ))
                        ) : (
                            <>
                                <p className="key-skill-box ms-2">Web Development</p>
                                <p className="key-skill-box ms-2">HTML</p>
                                <p className="key-skill-box ms-2">CSS</p>
                                <p className="key-skill-box ms-2">JavaScript</p>
                                <p className="key-skill-box ms-2">React JS</p>
                                <p className="key-skill-box ms-2">Node JS</p>
                                <p className="key-skill-box ms-2">Express JS</p>
                                <p className="key-skill-box ms-2">Mongodb</p>
                                <p className="key-skill-box ms-2">Git</p>
                                <p className="key-skill-box ms-2">Sql</p>
                            </>
                        )
                    }
                </div>
            </div>

            <ProfileEditModal
                show={keyskillModal}
                onHide={() => setKeyskillModal(false)}
                title="Key Skills"
            />
        </>
    );
}

const Employement = () => {

    const [employmentModal, setEmployementModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box">
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">Employment</h5>
                    <p className="up-fnt-sz" onClick={() => setEmployementModal(true)}>
                        Add employment
                    </p>
                </div>
                <p className="res-para-fnt">
                    Mention your employment details including your current and previous
                    company work experience.
                </p>
            </div>

            <ProfileEditModal
                show={employmentModal}
                onHide={() => setEmployementModal(false)}
                title="Employement"
            />
        </>
    );
}

const Education = () => {
    const educationRef = useRef(null);
    const [educationModal, setEducationModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box" id="education" ref={educationRef}>
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">Education</h5>
                    <p className="up-fnt-sz" onClick={() => setEducationModal(true)}>
                        Add education
                    </p>
                </div>
                <div>
                    <h6 className="qk-heading">
                        BCA Computers <span className="bi bi-pencil"></span>
                    </h6>
                    <h3 className="clg_name"> Agarwal P.G. College</h3>
                    <p className="clg_year">2019-2022 : Full Time</p>
                </div>
                <p className="up-fnt-sz">Add doctorate/PhD</p>
                <p className="up-fnt-sz">Add master/post-graduction</p>
                <p className="up-fnt-sz">Add class XII</p>
                <p className="up-fnt-sz">Add class X</p>
            </div>

            <ProfileEditModal
                show={educationModal}
                onHide={() => setEducationModal(false)}
                title="Education"
            />
        </>
    );
}
const Skills = () => {
    const itskillRef = useRef(null);
    const [itskillModal, setITSkillModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box" id="itskill" ref={itskillRef}>
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">IT skills</h5>
                    <p className="up-fnt-sz" onClick={() => setITSkillModal(true)}>
                        Add details
                    </p>
                </div>
                <p className="res-para-fnt">
                    Specify details about programming languages (such as Java, Python,
                    C/C++, Oracle, SQL etc), softwares (Microsoft Word, Excel, Tally etc)
                    or any other software related knowledge.
                </p>
            </div>

            <ProfileEditModal show={itskillModal} onHide={() => setITSkillModal(false)} title="IT Skills" />
        </>
    );
}
const Projects = () => {
    const projectsRef = useRef(null);
    const [addprojectModal, setAddProjectModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box" ref={projectsRef} id="projects">
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">
                        Project <span style={{ color: "green" }}>Add 8%</span>
                    </h5>
                    <p className="up-fnt-sz" onClick={() => setAddProjectModal(true)}>
                        Add project
                    </p>
                </div>
                <p className="res-para-fnt">
                    Add details about projects you have done in college, internship or at
                    work.
                </p>
            </div>

            <ProfileEditModal
                show={addprojectModal}
                onHide={() => setAddProjectModal(false)}
                title="Add Projects"
            />
        </>
    );
}
const ProileSummery = () => {
    const summaryRef = useRef(null);
    const [profileSumModal, setProfileSumModal] = React.useState(false);
    return (
        <>
            <div className="quick-link-box" ref={summaryRef} id="summary">
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">Profile summary</h5>
                    <p className="up-fnt-sz" onClick={() => setProfileSumModal(true)}>Add profile summary</p>
                </div>
                <p className="res-para-fnt">
                    Your Profile Summary should mention the highlights of your career and
                    education, what your professional interests are, and what kind of a
                    career you are looking for. Write a meaningful summary of more than 50
                    characters.
                </p>
            </div>

            <ProfileEditModal
                show={profileSumModal}
                onHide={() => setProfileSumModal(false)}
                title="Add Profile Summery"
            />
        </>
    );
}
const Accomplishments = (props) => {
    const accomplishRef = useRef(null);
    const [addaccomplishModal, setAddAccomplishModal] = React.useState(false);
    return (
        <>
            <div className='' id="accomplish" ref={accomplishRef}>
                <h5 className="qk-heading">{props.head}</h5>
                <div className="headline-dtl justify-content-between">
                    <h5 className="qk-heading">{props.title}</h5>
                    <p className="up-fnt-sz" onClick={() => setAddAccomplishModal(true)}>Add</p>
                </div>
                <p className="res-para-cntt">{props.content} </p>
            </div>

            <ProfileEditModal
                show={addaccomplishModal}
                onHide={() => setAddAccomplishModal(false)}
                title="Add Accomplishments"
            />
        </>
    );
}
const Careerprofile = () => {
    const careerprofileRef = useRef(null);
    const [careerModal, setCareerModal] = React.useState(false);
    return (
        <>
            <div className="container quick-link-box" id="careerprofile" ref={careerprofileRef}>
                <div className="row">
                    <h5 className="qk-heading">
                        Career profile <span className="bi bi-pencil" onClick={() => setCareerModal(true)} />
                    </h5>
                    <div className="col-md-6">
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Current industry</p>
                            <p className="res-para-cnpp">Miscellaneous</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Role category</p>
                            <p className="res-para-cnpp">Software Development</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Desired job type</p>
                            <p className="up-fnt-sz">Add desired job type</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Preferred shift</p>
                            <p className="up-fnt-sz">Add preferred shift</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Expected salary</p>
                            <p className="res-para-cnpp">₹18,00,000</p>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Department</p>
                            <p className="res-para-cnpp">Engineering - Software & QA</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Job role</p>
                            <p className="res-para-cnpp">Full Stack Developer</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Desired employment type</p>
                            <p className="up-fnt-sz">Add desired employment type</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Preferred work location</p>
                            <p className="res-para-cnpp">
                                Bangalore/Bengaluru, Mumbai, Pune, Chennai,
                                Hyderabad/Secunderabad, Gurgaon/Gurugram, Noida, Ahmedabad,
                                Kolkata, Delhi / NCR
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <ProfileEditModal
                show={careerModal}
                onHide={() => setCareerModal(false)}
                title="Career profile"
            />
        </>
    );
}
const Personaldetails = () => {
    const personalRef = useRef(null);
    const [personaldetailsModal, setPersonalDetailsModal] = React.useState(false);
    return (
        <>
            <div className="container quick-link-box" id="personal" ref={personalRef}>
                <div className="row">
                    <h5 className="qk-heading">
                        Personal details <span className="bi bi-pencil" onClick={() => setPersonalDetailsModal(true)} />
                    </h5>
                    <div className="col-md-6">
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Personal</p>
                            <p className="up-fnt-sz">male, Add marital status, more info</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Date of birth</p>
                            <p className="up-fnt-sz">Add Date of birth</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Category</p>
                            <p className="up-fnt-sz">Add Category</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Differently abled</p>
                            <p className="up-fnt-sz">Add Differently abled</p>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Career break</p>
                            <p className="up-fnt-sz">Add Career break</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Work permit</p>
                            <p className="up-fnt-sz">Add Work permit</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Address</p>
                            <p className="up-fnt-sz">Add Address</p>
                        </div>
                        <div className="cp-cp-cp">
                            <p className="up-fnt-wq">Languages</p>
                            <p className="up-fnt-sz">Add languages</p>
                        </div>
                    </div>
                </div>
            </div>

            <ProfileEditModal
                show={personaldetailsModal}
                onHide={() => setPersonalDetailsModal(false)}
                title="Personal Details"
            />
        </>
    );
}

function ProfileEditModal(props) {
    const [user, setUser] = useState({})
    const userId = localStorage.getItem('userId')
    const userFindEndPoint = 'user/findBy/'
    function getProfileDetails() {
        axios.get(baseUrl + userFindEndPoint + userId).then((response) => {
            setUser(response.data.data)
        }).catch((error) => {
            console.log(error);
        })
    }
    useEffect(() => {
        setTimeout(() => {
            getProfileDetails()
        }, 1000)
    }, [])

    function HandelInput(e) {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        });
    }

    function handelFrom(e) {
        e.preventDefault();
        const UpdateEndPoint = `update/${user._id}`
        axios.put(baseUrl + UpdateEndPoint, user).then((response) => {
            window.location.reload()
        })
    }

    if (props.title === 'Basic Details') {
        return (
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                style={{ paddingLeft: "0" }}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        <h5>{props.title}</h5>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form onSubmit={handelFrom}>
                        <label htmlFor="" className="edit-main-heading mt-4">
                            Name<span className="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            className="input-box-hldr"
                            name="name"
                            value={user.name}
                            onChange={HandelInput}
                        />
                        <p className="edit-main-heading mt-4">BCA at Agrawal p.g. college</p>
                        <p className="edit-para-fnt-sz">To edit go to education section.</p>

                        <div className="d-flex mt-4">
                            <div className="form-check">
                                <input
                                    className="form-check-input"
                                    type="radio"
                                    name="experience"
                                    id="flexRadioDefaultFresher"
                                    value="Fresher"
                                    checked={user.experience === 'Fresher'}
                                    onChange={HandelInput}
                                />
                                <label className="edit-main-heading" htmlFor="flexRadioDefaultFresher">
                                    Fresher
                                </label>
                            </div>
                            <div className="form-check ms-5">
                                <input
                                    className="form-check-input"
                                    type="radio"
                                    name="experience"
                                    id="flexRadioDefaultExperienced"
                                    value="Experienced"
                                    checked={user.experience === 'Experienced'}
                                    onChange={HandelInput}
                                />
                                <label className="edit-main-heading" htmlFor="flexRadioDefaultExperienced">
                                    Experienced
                                </label>
                            </div>
                        </div>

                        <label htmlFor="" className="edit-main-heading mt-4">
                            Current location<span className="text-danger">*</span>
                        </label>

                        <div className="d-flex mt-4">
                            <div className="form-check">
                                <input
                                    className="form-check-input"
                                    type="radio"
                                    name="location"
                                    id="flexRadio1"
                                    value="India"
                                    checked={user.location === 'India'}
                                    onChange={HandelInput}
                                />
                                <label className="edit-main-heading" htmlFor="flexRadio1">
                                    India
                                </label>
                            </div>
                            <div className="form-check ms-5">
                                <input
                                    className="form-check-input"
                                    type="radio"
                                    name="location"
                                    id="flexRadio2"
                                    value="Outside India"
                                    checked={user.location === 'Outside India'}
                                    onChange={HandelInput}
                                />
                                <label className="edit-main-heading" htmlFor="flexRadio2">
                                    Outside India
                                </label>
                            </div>
                        </div>

                        <input type="text" className="input-box-hldr" value="Jaipur" />

                        <label htmlFor="" className="edit-main-heading mt-4">
                            Mobile number<span className="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            className="input-box-hldr"
                            value={user?.number}
                            disabled
                        />

                        <label htmlFor="" className="edit-main-heading mt-4">
                            Email address<span className="text-danger">*</span>
                        </label>
                        <div className="d-flex flex-wrap">
                            <p className="text-muted edit-mail-vw">
                                {user?.email}
                            </p>
                            <p
                                className="text-primary ms-2 edit-mail-vw"
                                style={{ cursor: "pointer" }}
                            >
                                Change Email
                            </p>
                        </div>

                        <label htmlFor="" className="edit-main-heading mt-4">
                            Availability to join
                        </label>
                        <div className="avil-edit-tab">
                            <p className="edit-tab-box-vw">15 Days or less</p>
                            <p className="edit-tab-box-vw ms-2">1 Month</p>
                            <p className="edit-tab-box-vw ms-2">2 Months</p>
                            <p className="edit-tab-box-vw ms-2">3 Months</p>
                            <p className="edit-tab-box-vw ms-2">More than 3 Months</p>
                        </div>

                        <div className="d-flex justify-content-end mt-2">
                            <p
                                className="text-primary ms-2 edit-mail-vw mt-1"
                                style={{ cursor: "pointer" }}
                                onClick={props.onHide}
                            >
                                Cancel
                            </p>
                            <button className="edit-save-btn-vw-box">Save</button>
                        </div>
                    </form>
                </Modal.Body>
            </Modal>
        );
    } else
        if (props.title === 'Key Skills') {

            // array skill ko filter karna hai node js or react js me
            const [selectedSkills, setSelectedSkills] = useState([]);
            useEffect(() => {
                if (user.skill) {
                    user.skill.map((sk) => (
                        { 'label': sk }
                    ))
                    setSelectedSkills(user.skill.map((sk) => (
                        { value: sk, 'label': sk }
                    )))
                    
                }
            }, [user?.skill]);

            function handelFrom(e) {
                e.preventDefault();
                const keySkillArray = selectedSkills.map(skill => skill.value)
                console.log(keySkillArray);
                const UpdateEndPoint = `update/${user._id}`
                axios.put(baseUrl + UpdateEndPoint, {skill:keySkillArray}).then((response) => {
                    window.location.reload()
                })
            }
            const animatedComponents = makeAnimated();
            const keySkillOptions = [
                { value: 'React JS', label: 'React JS' },
                { value: 'Node JS', label: 'Node JS' },
                { value: 'Express JS', label: 'Express JS' },
                { value: 'Mongodb', label: 'Mongodb' },
                { value: 'HTML', label: 'HTML' },
                { value: 'CSS3', label: 'CSS3' },
                { value: 'Boostrap', label: 'Boostrap' },
                { value: 'RestAPI', label: 'RestAPI' },
                { value: 'SQL', label: 'SQL' },
                { value: 'MYSQL', label: 'MYSQL' },
                { value: 'Oracle', label: 'Oracle' }
            ];
            return (
                <Modal
                    {...props}
                    size="lg"
                    aria-labelledby="contained-modal-title-vcenter"
                    style={{ paddingLeft: "0" }}
                >
                    <Modal.Header closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                            <h5>{props.title}</h5>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <form onSubmit={handelFrom}>
                            <label htmlFor="keySkill" className="edit-main-heading mt-4">
                                Skill<span className="text-danger">*</span>
                            </label>
                            <Select
                                id='keySkill'
                                name='skill'
                                closeMenuOnSelect={false}
                                components={animatedComponents}
                                isMulti
                                options={keySkillOptions}
                                value={selectedSkills}
                                onChange={(selectedOptions) => setSelectedSkills(selectedOptions)}
                            />
                            <div className="d-flex justify-content-end mt-2">
                                <p
                                    className="text-primary ms-2 edit-mail-vw mt-1"
                                    style={{ cursor: "pointer" }}
                                    onClick={props.onHide}
                                >
                                    Cancel
                                </p>
                                <button className="edit-save-btn-vw-box">Save</button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
            )
        }

}