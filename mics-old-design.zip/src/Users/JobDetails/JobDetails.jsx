import React, { useEffect, useState } from 'react';
import './jobDetails.css';
import Slider from 'react-slick';
import Header from "../header/Header";
import Footer from "../footer/Footer";
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import baseUrl from '../../js/api';

function JobDetails() {
  const [job,setJob] = useState({})
  const [jobTime,setJobTime] = useState()
  const jobId = localStorage.getItem('jobId')
  const endpoint = `get/job/by-jobId/${jobId}`
  function jobGetApi() {
    axios.get(baseUrl+endpoint).then(response=>{
      console.log(response.data.data);
      setJob(response.data.data);
      setJobTime(response.data.time)
  })
  }
  useEffect(() => {
    jobGetApi()
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Header />
      <div className="jb-del-bg">
        <div className="container-fluid">
          <p className="pt-2 text-primary">
            <span> <b> Home / </b> </span>
            <span><b> Job / </b> </span>
            <span> <b> Job Details </b> </span>
          </p>

          <div className="row">
            <div className="col-md-8">
              <div className="card bg-white shadow-sm rounded border-0 mt-3">
                <div className="card-body">
                  <div className="d-flex justify-content-between">
                    <div>
                      <h5 className="card-title intern-title">{job?.titel}</h5>
                      <p className="text-muted cmpy-name">{job?.who_post?.companyName}</p>
                      <p className="text-muted rate-text">4.5 <span><i className="bi bi-star-fill text-warning"></i></span> (1000 reviews)</p>
                    </div>
                    <img src="/src/assets/images/milogo.png" alt="company logo" className="img-fluid intern-logo-img" />
                  </div>

                  <p className="text-muted work-text"><i className="bi bi-house-door-fill fs-5"></i> {job?.job_type}</p>
                  <div className="display-tag">
                    <div>
                      <p className="display-font"><i className="bi bi-briefcase-fill"></i> Experience</p>
                      <p className="text-muted para-intern">{job?.experience}</p>
                    </div>

                    <div className="tag-side">
                      <p className="display-font"><i className="bi bi-geo-alt-fill"></i> Location</p>
                      <p className="text-muted para-intern">{job?.location}</p>
                    </div>

                    <div className="tag-side">
                      <p className="display-font"><i className="bi bi-cash-coin"></i> Salary</p>
                      <p className="text-muted para-intern">{job.salary?job?.salary:'Not disclosed'}</p>
                    </div>
                  </div>
                  <hr />
                  <div className="share-post">
                    <div className="d-flex"><p className="text-muted para-intern mt-0">{jobTime}</p>
                      <p className="ms-3" style={{ cursor: "pointer" }}><i className="bi bi-share fs-5 text-primary"></i></p></div>
                    <a href="#"><button className="text-white bg-primary px-5 py-2 shadow rounded border-0"><ApplyModal /></button></a>
                  </div>
                </div>
              </div>

              <div className="card mt-4 border-0 shadow-sm rounded">
                <div className="card-body">
                  <h5 className="card-title des-title">Job Description</h5>
                  <p>{job?.description}</p>
                  <h6 className="card-subtitle mt-2 skill-des">Required skill:</h6>
                  <ul className="mt-2">

                    {/* bade me add karna kai */}
                    <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                    <li className="skill-list mt-1">Candidate should have 3+ Years of experience in Java.</li>
                    <li className="skill-list mt-1">Should have experience in Angular.</li>
                    <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                    <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                    <li className="skill-list mt-1">Candidate should have 5+ Years of experience.</li>
                  </ul>
                  {/*  Bad me add karna  */}
                  <h6 className="card-subtitle mt-4 skill-des">Roles & Responsibility:</h6>
                  <ul className="mt-2">
                    <li className="skill-list mt-1">To create work plans, monitor and track the work schedule for on time delivery as per the defined quality standards.</li>
                    <li className="skill-list mt-1">To develop and guide the team members in enhancing their technical capabilities and increasing productivity.</li>
                    <li className="skill-list mt-1">To ensure process improvement and compliance in the assigned module, and participate in technical discussions or review.</li>
                    <li className="skill-list mt-1">To prepare and submit status reports for minimizing exposure and risks on the project or closure of escalations.</li>

                  </ul>

                  <p className="mt-5 text-muted">Role :</p>
                  <p className="role-job">{job.role?job?.role:'Not Defined'}</p>
                  <p className="text-muted">Industry Type :</p>
                  <p className="role-job">{job?.who_post?.industry}</p>
                  <p className="text-muted">Employment Type :</p>
                  <p className="role-job">{job?.duration}</p>
                  <p className="text-muted">Role Category :</p>
                  <p className="role-job">{job?.role}</p>
                  <p className="text-muted">Education :</p>
                  <p className="role-job">{job?.graduation}</p>
                  <p className="text-muted">Key skill :</p>
                  <div className="row">
                  {
                    job?.skill?.map((sk)=>(
                      <div className="col-md-3 ">
                      <p className="role-job key-skill ms-2 mt-1"> {sk}</p>
                      </div>
                    ))
                   }
                  </div>
                  <p className="text-muted">Number of openings :</p>
                  <p className="role-job">{job?.employe}</p>
                  <p className="text-muted">Job activity :</p>
                  <p className="role-job">{jobTime}</p>

                </div>
              </div>

              <div className="card mt-4 border-0 rounded shadow-sm">
                <div className="card-body">
                  <h5 className="card-title des-title">About {job?.who_post?.companyName}</h5>
                  <a href={job?.who_post?.browser_link} className="text-decoration-none"><p className="web-share">website <i className="bi bi-box-arrow-up-right"></i></p></a>
                  <p className="cmp-about">{job?.who_post?.description}</p>
                </div>
              </div>
            </div>

            <div className="col-md-4 mt-3 mb-3">
              <div className="bg-white p-2 rounded shadow-sm">
                <h5 className="intern-title">Jobs you might be interested in</h5>

                <a href="#" className="text-decoration-none"><div className="d-flex mt-4 justify-content-between">
                  <div>
                    <h6 className="text-dark">Java Fullstack</h6>
                    <p className="text-muted cmpy-name">Tata Consultancy Services</p>
                    <p className="text-muted rate-text">3.9 <i className="bi bi-star-fill text-warning"></i> <span className="text-primary">(5000 reviews)</span></p>
                    <p className="text-muted cmpy-name"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                  </div>
                  <div>
                    <img src="/src/assets/images/milogo.png" alt="Logo" className="img-fluid intern-logo-img" />
                    <p className="text-muted post-day">Posted 2 days ago</p>
                  </div>
                </div>
                </a>

                <hr />
                <a href="#" className="text-decoration-none"><div className="d-flex mt-4 justify-content-between">
                  <div>
                    <h6 className="text-dark">Java Fullstack</h6>
                    <p className="text-muted cmpy-name">Tata Consultancy Services</p>
                    <p className="text-muted rate-text">3.9 <i className="bi bi-star-fill text-warning"></i> <span className="text-primary">(5000 reviews)</span></p>
                    <p className="text-muted cmpy-name"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                  </div>
                  <div>
                    <img src="/src/assets/images/milogo.png" alt="Logo" className="img-fluid intern-logo-img" />
                    <p className="text-muted post-day">Posted 2 days ago</p>
                  </div>
                </div>
                </a>
                <hr />
                <a href="#" className="text-decoration-none"><div className="d-flex mt-4 justify-content-between">
                  <div>
                    <h6 className="text-dark">Java Fullstack</h6>
                    <p className="text-muted cmpy-name">Tata Consultancy Services</p>
                    <p className="text-muted rate-text">3.9 <i className="bi bi-star-fill text-warning"></i> <span className="text-primary">(5000 reviews)</span></p>
                    <p className="text-muted cmpy-name"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                  </div>
                  <div>
                    <img src="/src/assets/images/milogo.png" alt="Logo" className="img-fluid intern-logo-img" />
                    <p className="text-muted post-day">Posted 2 days ago</p>
                  </div>
                </div>
                </a>
                <hr />
                <a href="#" className="text-decoration-none"><div className="d-flex mt-4 justify-content-between">
                  <div>
                    <h6 className="text-dark">Java Fullstack</h6>
                    <p className="text-muted cmpy-name">Tata Consultancy Services</p>
                    <p className="text-muted rate-text">3.9 <i className="bi bi-star-fill text-warning"></i> <span className="text-primary">(5000 reviews)</span></p>
                    <p className="text-muted cmpy-name"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                  </div>
                  <div>
                    <img src="/src/assets/images/milogo.png" alt="Logo" className="img-fluid intern-logo-img" />
                    <p className="text-muted post-day">Posted 2 days ago</p>
                  </div>
                </div>
                </a>
                <hr />
                <a href="#" className="text-decoration-none"><div className="d-flex mt-4 justify-content-between">
                  <div>
                    <h6 className="text-dark">Java Fullstack</h6>
                    <p className="text-muted cmpy-name">Tata Consultancy Services</p>
                    <p className="text-muted rate-text">3.9 <i className="bi bi-star-fill text-warning"></i> <span className="text-primary">(5000 reviews)</span></p>
                    <p className="text-muted cmpy-name"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                  </div>
                  <div>
                    <img src="/src/assets/images/milogo.png" alt="Logo" className="img-fluid intern-logo-img" />
                    <p className="text-muted post-day">Posted 2 days ago</p>
                  </div>
                </div>
                </a>
                <hr />
                <a href="#" className="text-decoration-none">View more <i className="bi bi-arrow-right"></i></a>
              </div>
            </div>

            <SimilarJobs />
          </div>
        </div>
      </div>

      {/* </div>
        </div>

      </div> */}

      <Footer />

    </>
  )
}

export default JobDetails


function SimilarJobs() {

  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  return (
    <>
      <div>
        <h5 className="mt-4">Similar Jobs</h5>
        <Slider {...settings}>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>
          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>
          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

          <div className="carousel-item active">
            <div className="mb-4 mt-3">
              <div className="card border-0 shadow-sm rounded m-1">
                <div className="card-body">
                  <p className="text-end post-date">2 Months ago</p>
                  <h5 className="card-title intern-title">HC & Insurance Operations Senior Rep.</h5>
                  <p className="card-subtitle show-more-card text-muted mt-2">Mount Infosolutions & Consultancies Pvt.Ltd</p>
                  <div className="d-flex justify-content-between mt-3">
                    <p className="more-icon"><i className="bi bi-geo-alt-fill"></i> Jaipur</p>
                    <p className="more-icon"><i className="bi bi-briefcase-fill"></i> 0-5yrs</p>
                  </div>
                  <a href="#" className="text-decoration-none text-primary"><div className="text-end mt-4"><b>Apply</b></div></a>
                </div>
              </div>
            </div>
          </div>

        </Slider>
      </div>

    </>
  );
}



function ApplyModal() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  function handleJobApply(e){
    e.preventDefault()
  }

  return (
    <>
      <span onClick={handleShow}>
        Apply Now
      </span>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Apply Form</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleJobApply}>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Your Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Full Name"
                autoFocus
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                autoFocus
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Mobile Number</Form.Label>
              <Form.Control
                type="tel"
                placeholder="Enter Your Mobile No."
                autoFocus
                maxLength={10}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Resume</Form.Label>
              <Form.Control
                type="file"
                autoFocus
              />
            </Form.Group>

          </Form>

        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button type='submit' variant="primary" onClick={handleClose}>
            Apply Now
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}