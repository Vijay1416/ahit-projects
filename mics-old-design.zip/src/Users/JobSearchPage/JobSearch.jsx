import React, { useEffect, useState } from 'react';
import './jobsearch.css';
import Header from "../header/Header";
import Footer from "../footer/Footer";
import { Link, NavLink, Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import baseUrl from '../../js/api';

function JobSearch() {
  const [searchQuery, setsearchQuery] = useState({ search: '' })
  const [data, setData] = useState([])
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [maxPagesToShow, setMaxPagesToShow] = useState(4);
  const [halfMaxPages, setHalfMaxPages] = useState(Math.floor(maxPagesToShow / 2));
  const navigat = useNavigate()


  const allDataApiEndPoint = 'post/get/job'
  const handelOnchangeInput = (e) => {
    const { value } = e.target
    setsearchQuery({ search: value })
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    const restrictedChars = /[:;,\'"]/;
    if (searchQuery.search.trim().length < 1 || restrictedChars.test(searchQuery.search)) {
      return;
    }
    const query = new Array()
    query.push(searchQuery.search.split(' '))
    axios.get(baseUrl + `search/job?search=${query}`).then((response) => {
      const dataArray = response.data.data
      // if (dataArray.length == 0) {
      //   axios.get(baseUrl + allDataApiEndPoint).then((response) => {
      //     setData(response.data.data)
      //     return
      //   }).catch((error) => {
      //     console.log(error);
      //   })
      //   return
      // }
      setData(dataArray)
    });
  };
  function alljobGets(page) {
    axios.get(`${baseUrl + allDataApiEndPoint}?page=${page}&limit=3`).then((response) => {
      setData(response.data.data)
      setCurrentPage(response.data.pagination.currentPage);
      setTotalPages(response.data.pagination.totalPages);
    }).catch((error) => {
      console.log(error);
    })
  }
  useEffect(() => {
    window.scrollTo(0, 0);
    alljobGets(1)
  }, []);

  function handelRedirect(titel, id) {
    localStorage.setItem('jobId', id)
    const formattedTitle = titel.replace(/[^\w\s]/gi, '').replace(/\s+/g, '-').toLowerCase();
    navigat(`/job-details/${formattedTitle}`)
  }
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
      alljobGets(newPage);
    }
  };

  useEffect(() => {
    setHalfMaxPages(Math.floor(maxPagesToShow / 2));
  }, [maxPagesToShow]);

  const calculatePaginationRange = () => {
    let startPage = Math.max(1, currentPage - halfMaxPages);
    let endPage = Math.min(startPage + maxPagesToShow - 1, totalPages);

    if (endPage === totalPages) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    } else if (startPage === 1) {
      endPage = Math.min(maxPagesToShow, totalPages);
    }

    return { startPage, endPage };
  };

  const { startPage, endPage } = calculatePaginationRange();


  return (
    <>
      <Header />
      <div className="intern-bg">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-4 mt-3 mb-3">
              <div className="bg-white flow-y shadow-sm p-3 rounded">

                <form className="article" onSubmit={handleSubmit}>
                  <p className="text-muted"><b><i className="bi bi-funnel text-primary fs-5 pt-2"></i> Filters</b></p>
                  <label className="form-check-label cate-font mt-4"><b>Keyword search</b></label>
                  <div className="search-box mt-1">
                    <input onChange={handelOnchangeInput} value={searchQuery.search} type="search" className="search-input" placeholder="e.g. Design, Delhi, MICS" />

                    <button type='submit' className="search-button" >
                      <i className="bi bi-search"></i>
                    </button>
                  </div>
                  <div className="mobile-vw mt-3">

                    <label htmlFor="" className="cate-font mt-3">Category</label>
                    <input type="text" placeholder="e.g. Marketing" className="form-control mt-1" />
                    <label htmlFor="" className="cate-font mt-3">Location</label>
                    <input type="text" placeholder="e.g. Jaipur" className="form-control mt-1" />
                    <div className="mt-3 mb-2 form-check">
                      <input type="checkbox" className="form-check-input" id="Check1" />
                      <label className="form-check-label cate-font" htmlFor="Check1">Work from home</label>
                    </div>

                    <div className="mb-3 form-check">
                      <input type="checkbox" className="form-check-input" id="Check2" />
                      <label className="form-check-label cate-font" htmlFor="Check2">Part-time</label>
                    </div>

                    <label htmlFor="" className="cate-font">Desired minimum monthly stipend (₹)</label>
                    <div className="mt-2 mb-2 form-check">
                      <input type="checkbox" className="form-check-input" id="Check3" />
                      <label className="form-check-label cate-font" htmlFor="Check3">0-2k</label>
                    </div>
                    <div className="mt-2 mb-2 form-check">
                      <input type="checkbox" className="form-check-input" id="Check4" />
                      <label className="form-check-label cate-font" htmlFor="Check4">2k-5k</label>
                    </div>
                    <div className="mt-2 mb-2 form-check">
                      <input type="checkbox" className="form-check-input" id="Check5" />
                      <label className="form-check-label cate-font" htmlFor="Check5">5k-7k</label>
                    </div>
                    <div className="mt-2 mb-2 form-check">
                      <input type="checkbox" className="form-check-input" id="Check6" />
                      <label className="form-check-label cate-font" htmlFor="Check6">7k-10k</label>
                    </div>
                    <a className="moreless-button text-decoration-none mt-5" href="#">View more filters <i className="bi bi-arrow-right"></i></a>
                    <div className="moretext">
                      <label htmlFor="" className="cate-font mt-3">Starting from (or after)</label>
                      <input type="date" placeholder="Choose date" className="form-control mt-1" />

                      <label htmlFor="" className="cate-font mt-3">Max. duration (months)</label>
                      <select className="form-control mt-1">
                        <option value="" className="text-muted">Choose duration</option>
                        <option value="1" className="text-muted">1 Month</option>
                        <option value="2" className="text-muted">3 Months</option>
                        <option value="3" className="text-muted">6 Months</option>
                        <option value="4" className="text-muted">12 Months</option>
                        <option value="5" className="text-muted">24 Months</option>
                        <option value="6" className="text-muted">36 Months</option>
                      </select>

                      <div className="mt-3 mb-2 form-check">
                        <input type="checkbox" className="form-check-input" id="Check7" />
                        <label className="form-check-label cate-font" htmlFor="Check7">Internships with job offer</label>
                      </div>

                      <div className="mt-2 mb-2 form-check">
                        <input type="checkbox" className="form-check-input" id="Check8" />
                        <label className="form-check-label cate-font" htmlFor="Check8">Fast response</label>
                      </div>

                      <div className="mt-2 mb-2 form-check">
                        <input type="checkbox" className="form-check-input" id="Check9" />
                        <label className="form-check-label cate-font" htmlFor="Check9">Early applicant</label>
                      </div>

                      <div className="mt-2 mb-2 form-check">
                        <input type="checkbox" className="form-check-input" id="Check10" />
                        <label className="form-check-label cate-font" htmlFor="Check10">Internships for women</label>
                      </div>
                    </div>
                    <div className="text-end"><a href="#" className="text-decoration-none">Clear all</a></div>


                  </div>
                </form>
              </div>
            </div>
            <div className="col-md-8 mt-3 mb-3">
              <div className="">

                {data?.map((jobs, index) => (
                  <div key={index} className="card bg-white shadow-sm rounded border-0 mb-4">
                    <div className="card-body">
                      <div className="d-flex justify-content-between">
                        <div>
                          <h5 className="card-title intern-title">{jobs?.titel}</h5>
                          <p className="text-muted cmpy-name">{jobs?.who_post?.companyName}</p>
                        </div>
                        <img src={jobs ? baseUrl + jobs.who_post.profilePic : "/src/assets/images/milogo.png"} alt="company logo" className="img-fluid intern-logo-img" />
                      </div>

                      <p className="text-muted work-text"><i className="bi bi-house-door-fill fs-5"></i> {jobs?.job_type} </p>
                      <div className="display-tag">
                        <div>
                          <p className="badge badge-info display-font"><i className="bi bi-play-circle-fill"></i> Start Date</p>
                          <p className="text-muted para-intern">{jobs?.stating_Date}</p>
                        </div>

                        <div className="tag-side">
                          <p className="display-font"><i className="bi bi-calendar-check-fill"></i> Duration</p>
                          <p className="text-muted para-intern">{jobs?.duration}</p>
                        </div>

                        <div className="tag-side">
                          <p className="display-font"><i className="bi bi-cash-coin"></i> Stipend</p>
                          <p className="text-muted para-intern">{jobs ? jobs.salary : 'Not disclosed'}</p>
                        </div>
                      </div>
                      <hr />
                      <div className="d-flex justify-content-between">
                        <p className="text-muted para-intern">{jobs?.createdAt}</p>
                        <span onClick={() => handelRedirect(jobs?.titel, jobs?._id)}>  <p className="del-tag">View details <i className="bi bi-arrow-right fs-5"></i></p></span>
                      </div>
                    </div>
                  </div>



                ))}


                <div aria-label="Page navigation example" className="mt-4">
                  <ul className="pagination">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                      <span className="page-link" aria-label="Previous" onClick={() => handlePageChange(currentPage - 1)}>&laquo;</span>
                    </li>
                    {startPage > 1 && <li className="page-item disabled"><span className="page-link">...</span></li>}
                    {Array.from({ length: endPage - startPage + 1 }, (_, index) => (
                      <li key={startPage + index} className={`page-item ${currentPage === startPage + index ? 'active' : ''}`}>
                        <span className="page-link" onClick={() => handlePageChange(startPage + index)}>
                          {startPage + index}
                        </span>
                      </li>
                    ))}
                    {endPage < totalPages && <li className="page-item disabled"><span className="page-link">...</span></li>}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                      <span className="page-link" aria-label="Next" onClick={() => handlePageChange(currentPage + 1)}>&raquo;</span>
                    </li>
                  </ul>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <div className="container mt-5" >
        <div className="row">
          <div className="col-md-12">
            <h5 className="text-primary text-center">Frequently asked questions?</h5>

            <div className="accordion accordion-flush" id="accordionFlushExample">
              <div className="accordion-item mt-3">
                <h2 className="accordion-header" id="flush-headingOne">
                  <button className="accordion-button collapsed accor-border" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                    Accordion Item #1
                  </button>
                </h2>
                <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                  <div className="accordion-body accor-border">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the first item's accordion body.</div>
                </div>
              </div>
              <div className="accordion-item mt-4">
                <h2 className="accordion-header" id="flush-headingTwo">
                  <button className="accordion-button collapsed accor-border" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                    How can  I apply for an internship on Intershala?
                  </button>
                </h2>
                <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                  <div className="accordion-body accor-border">You can apply for a internship using the following steps-
                    1. Click on "View Details" to get details about the company and the profile.
                    2. Go through the details thoroughly and apply if your profile matches the requirements of the company.
                    3. Click on "Apply Now" and follow the steps to submit your application.
                    4. If not registered on Internshala, first register yourself and then click on "Apply Now".</div>
                </div>
              </div>
              <div className="accordion-item mt-4">
                <h2 className="accordion-header" id="flush-headingThree">
                  <button className="accordion-button collapsed accor-border" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                    Accordion Item #3
                  </button>
                </h2>
                <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                  <div className="accordion-body accor-border">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      <Footer />

    </>
  )
}

export default JobSearch;