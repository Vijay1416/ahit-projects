import React from 'react';
import './footer.css';
import {NavLink} from 'react-router-dom';

function Footer() {
    return (
        <>
            {/* ------------------------Footer------------------------------- */}

            <div className="footer-bg">
                <div className="container mt-4">
                    <footer className="row py-5  border-top">
                        <div className="row">
                        <div className="col-md-3">
                            <NavLink to="/" className="d-flex align-items-center mb-3 link-dark text-decoration-none">
                                <img src="/src/assets/images/milogo.png" alt="Footer logo" className="img-fluid footer-logo" />
                                {/* <svg className="bi me-2" width="40" height="32"><use xlink:to="#bootstrap"/></svg> */}
                            </NavLink>
                            <p className="text-muted mt-3"><b>Connect with us</b></p>
                            <div>
                                <NavLink to="#"><i className="bi bi-facebook footer-icon fs-5"></i></NavLink>
                                <NavLink to="#"><i className="bi bi-instagram footer-icon fs-5 ms-2"></i></NavLink>
                                <NavLink to="#"><i className="bi bi-twitter-x footer-icon fs-5 ms-2"></i></NavLink>
                                <NavLink to="#"><i className="bi bi-linkedin footer-icon fs-5 ms-2"></i></NavLink>
                            </div>
                        </div>

                        <div className="col-md-3 mt-3">
                            <h5 className="footer-tab">Job by Roles</h5>
                            <ul className="nav flex-column">
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Full Stack Developer</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Web Developer</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Accountant</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> TeleCaller</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Mobile/App Developer</NavLink></li>
                            </ul>
                        </div>

                        <div className="col-md-3 mt-3">
                            <h5 className="footer-tab">Job by Cities</h5>
                            <ul className="nav flex-column">
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Jaipur</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Delhi</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Bangalore</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Hydrabad</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Chennai</NavLink></li>
                            </ul>
                        </div>

                        <div className="col-md-3 mt-3">
                            <h5 className="footer-tab">Top Hiring Companies</h5>
                            <ul className="nav flex-column">
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Wipro</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> TCS</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Just Dial</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> HCL</NavLink></li>
                                <li className="nav-item mb-2 mt-2"><NavLink to="#" className="nav-link p-0 footer-text"><i className="bi bi-arrow-right"></i> Accenture</NavLink></li>
                            </ul>
                        </div>
                        </div>
                    </footer>
                </div>
            </div>
        </>
    )
}

export default Footer
