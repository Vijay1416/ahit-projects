import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Home from '../Users/home/Home';
import Signup from '../Users/signup/Signup';
import Login from '../Users/login/Login';
import HirePage from '../Company/hirepage/HirePage';
import JobDetails from '../Users/JobDetails/JobDetails';
import JobSearch from '../Users/JobSearchPage/JobSearch';
import Profile from '../Users/profile/profile';
import { LoginContext } from '../Users/ContextApi/ContextApi';
import Register from '../Company/Login/Register';
import LoginCompany from '../Company/Login/Login';
import CompanyHome from '../Company/Home/CompanyHome';
import Contactus from '../Company/Contactus/Contactus';
import ContactusMain from '../Users/ContactUsMain/ContactusMain';
import CompanyProfile from '../Company/CompanyProfile/CompanyProfile';
import ProfileSetting from '../Company/CompanyProfile/ProfileSetting';
import ProfileSecurity from '../Company/CompanyProfile/ProfileSecurity';
import PageNotFound from '../404/PageNotFound';




function SetRoutes() {
    const checkCompany = localStorage.getItem('companyId')
    const checkUser = localStorage.getItem('userId')
    const comapanyRouters = (
        <>
            <Route path='/Company/HomePage' element={<CompanyHome />}></Route>
            <Route path='/recruit/client-registration-form' element={<Register />}></Route>
            <Route path='/recruit/login' element={<LoginCompany />}></Route>
            <Route path='/recruit/hire-page' element={<HirePage />}></Route>
            <Route path='/company/contact-us' element={<Contactus />}></Route>
            <Route path='/company/profile' element={<CompanyProfile />}></Route>
            <Route path='/company/profile/setting' element={<ProfileSetting />}></Route>
            <Route path='/company/profile/setting/security' element={<ProfileSecurity />}></Route>
            <Route path='*' element={<PageNotFound />}></Route>
        </>
    )
    const userRoutes = (
        <>
            <Route path='/' element={<Home />}></Route>
            <Route path='/signup' element={<Signup />}></Route>
            <Route path='/login' element={<Login />}></Route>
            <Route path='/job-search' element={<JobSearch />}></Route>
            <Route path='/job-details/:titel' element={<JobDetails />}></Route>
            <Route path='/Profile' element={<Profile />}></Route>
            <Route path='/contact-us' element={<ContactusMain />}></Route>
            <Route path='*' element={<PageNotFound />}></Route>
        </>
    )
    if (checkCompany) {
        return (
            <Routes>
                <Route path='/' element={< Navigate to='/Company/HomePage' replace />}></Route>
                <Route path='/recruit/login' element={< Navigate to='/Company/HomePage' replace />}></Route>
                <Route path='/recruit/client-registration-form' element={< Navigate to='/Company/HomePage' replace />}></Route>
                {comapanyRouters}
            </Routes>
        )
    } else if (checkUser) {
        return (
            <Routes>
                <Route path='/login' element={< Navigate to='/' replace />}></Route>
                <Route path='/signup' element={< Navigate to='/' replace />}></Route>
                {userRoutes}
            </Routes>
        )
    } else {
        return (
            <>
                <Routes>

                    {comapanyRouters}
                    {userRoutes}
                </Routes>

            </>

        );
    }
}

export default SetRoutes;