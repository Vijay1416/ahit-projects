import React from 'react'
import errorimg from '../assets/images/error.gif';
import './pagenotfound.css';
import { useNavigate } from 'react-router-dom';

function PageNotFound() {
  const navigate = useNavigate()
  const checkAuth = localStorage.getItem('companyId')
  function redirectHome() {
    checkAuth ?
      (navigate('/Company/HomePage')) :
      (navigate('/'))
  }
  return (
    <>
      <div className='error-page-div'>
        <div className='error-img-box text-center'>
          <img src={errorimg} alt="error img" className='img-fluid' />
        </div>

        <h5 className='text-center error-main-heading'>Oops...404 error</h5>
        <h6 className='text-center'>Look like you're lost
          the page you are looking for not available!</h6>

        <div className='text-center'><button onClick={() => redirectHome()} className='err-main-btnvw'>Go back to homepage</button></div>
      </div>
    </>
  )
}

export default PageNotFound
