export const userAuh = localStorage.getItem('userId')
export const companyAuth = localStorage.getItem('companyId')
export const companyName = localStorage.getItem('companyName')