const baseUrl = "https://mics-xhnt6.ondigitalocean.app/"
export default baseUrl