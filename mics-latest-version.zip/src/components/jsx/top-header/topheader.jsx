import React from 'react'

function Topheader() {
    return (
        <>
            <div className="top-head">
                <div className="container">
                    <div className="row">
                        <div className="col-xl-12 mx-auto">
                            <div className="top-scroll">
                                <div className="top-scroll-inner">
                                    <span>Urgent Hiring: Business Development Executive In Jaipur ,Urgent Hiring: Business Development Executive In Jaipur</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Topheader